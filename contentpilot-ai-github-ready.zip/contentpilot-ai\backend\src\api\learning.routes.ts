import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '../database/client.js';
import { learningAgent } from '../services/learning/learningAgent.js';

const router = Router();
const param = (p: string | string[]): string => (Array.isArray(p) ? p[0] : p);

// POST trigger learning analysis for channel
router.post('/analyze/:channelId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const insights = await learningAgent.analyzeChannel(param(req.params.channelId));
    res.json({ success: true, count: insights.length, data: insights });
  } catch (err) {
    next(err);
  }
});

// GET learning insights for channel
router.get('/insights/:channelId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const insights = await prisma.learningInsight.findMany({
      where: { channelId: param(req.params.channelId) },
      orderBy: { confidence: 'desc' },
    });
    res.json({ success: true, count: insights.length, data: insights });
  } catch (err) {
    next(err);
  }
});

export default router;
