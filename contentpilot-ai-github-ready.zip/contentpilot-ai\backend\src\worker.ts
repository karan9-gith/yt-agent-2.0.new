import dotenv from 'dotenv';
dotenv.config();

import { jobWorkerManager } from './jobs/jobWorker.js';
import { persistentScheduler } from './services/scheduler/schedulerEngine.js';
import { initializeDatabasePragmas } from './database/client.js';
import { logger } from './utils/logger.js';
import { config } from './config/index.js';

async function bootstrap() {
  logger.info({
    msg: 'Starting ContentPilot Standalone Background Worker & Scheduler',
    env: config.NODE_ENV,
    storageDir: config.STORAGE_DIR,
  });

  await initializeDatabasePragmas();
  await jobWorkerManager.start();
  await persistentScheduler.start();

  logger.info('Standalone Worker & Scheduler successfully initialized and polling.');

  const shutdown = async (signal: string) => {
    logger.info({ msg: `Received ${signal}, shutting down background systems gracefully...` });
    await jobWorkerManager.stop();
    await persistentScheduler.stop();
    process.exit(0);
  };

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

bootstrap().catch((err) => {
  logger.error({ msg: 'Worker daemon crash on boot', error: err });
  process.exit(1);
});
