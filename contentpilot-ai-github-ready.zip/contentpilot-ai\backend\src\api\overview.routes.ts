import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '../database/client.js';
import { config } from '../config/index.js';
import { persistentScheduler } from '../services/scheduler/schedulerEngine.js';
import { jobWorkerManager } from '../jobs/jobWorker.js';

const router = Router();
const param = (p: string | string[] | undefined): string | undefined => (Array.isArray(p) ? p[0] : p);

// GET /api/overview - Aggregated live telemetry
router.get('/', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = param(req.query.channelId as string);

    // Active & failed jobs
    const [activeJobsCount, failedJobsCount, queuedJobsCount] = await Promise.all([
      prisma.job.count({ where: { status: 'RUNNING' } }),
      prisma.job.count({ where: { status: 'FAILED' } }),
      prisma.job.count({ where: { status: 'QUEUED' } }),
    ]);

    // Video pipeline state distribution
    const projects = await prisma.videoProject.findMany({
      where: channelId ? { channelId } : undefined,
      select: { id: true, status: true, currentStage: true, title: true, updatedAt: true },
      orderBy: { updatedAt: 'desc' },
      take: 10,
    });

    const awaitingApprovalCount = await prisma.approvalRequest.count({
      where: {
        status: 'WAITING_APPROVAL',
        ...(channelId ? { channelId } : {}),
      },
    });

    const scheduledVideosCount = await prisma.publishingQueue.count({
      where: {
        status: 'QUEUED',
        scheduledPublishTime: { not: null },
        ...(channelId ? { channelId } : {}),
      },
    });

    const publishedVideosCount = await prisma.youTubeVideo.count({
      where: channelId ? { channelId } : undefined,
    });

    // Channel analytics summary (from lifetime snapshots)
    const latestSnapshots = await prisma.analyticsSnapshot.findMany({
      where: {
        measurementWindow: 'lifetime',
        ...(channelId ? { channelId } : {}),
      },
      orderBy: { capturedAt: 'desc' },
      take: 20,
    });

    const totalViews = latestSnapshots.reduce((acc, s) => acc + s.views, 0);
    const totalWatchTime = latestSnapshots.reduce((acc, s) => acc + s.watchTimeMinutes, 0);
    const totalLikes = latestSnapshots.reduce((acc, s) => acc + s.likes, 0);
    const totalComments = latestSnapshots.reduce((acc, s) => acc + s.comments, 0);

    // Channel settings for automation status
    let channelSettings = null;
    if (channelId) {
      channelSettings = await prisma.channelSetting.findUnique({
        where: { channelId },
      });
    }

    // Credentials status (YouTube connection check)
    const ytCredential = channelId
      ? await prisma.credential.findFirst({
          where: { channelId, provider: 'youtube', status: 'active' },
        })
      : null;

    res.json({
      success: true,
      data: {
        activeJobsCount,
        failedJobsCount,
        queuedJobsCount,
        awaitingApprovalCount,
        scheduledVideosCount,
        publishedVideosCount,
        recentProjects: projects,
        analytics: {
          hasData: latestSnapshots.length > 0,
          totalViews,
          totalWatchTimeMinutes: Math.round(totalWatchTime * 10) / 10,
          totalLikes,
          totalComments,
          videoCount: latestSnapshots.length,
        },
        automation: {
          autoPublish: config.AUTO_PUBLISH,
          requireHumanApproval: config.REQUIRE_HUMAN_APPROVAL,
          defaultPrivacy: config.DEFAULT_YOUTUBE_PRIVACY,
          schedulerRunning: persistentScheduler.getIsRunning(),
          workerRunning: jobWorkerManager.isWorkerRunning(),
          channelAutomationEnabled: channelSettings?.automationEnabled ?? false,
          publishingCadence: channelSettings?.publishingCadence ?? 'weekly',
        },
        systemStatus: {
          geminiConfigured: !!config.GEMINI_API_KEY && config.GEMINI_API_KEY.length > 5,
          youtubeConnected: !!ytCredential,
          databaseConnected: true,
          storageConfigured: !!config.STORAGE_DIR,
        },
      },
    });
  } catch (err) {
    next(err);
  }
});

export default router;
