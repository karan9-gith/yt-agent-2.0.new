import { describe, it, expect, beforeEach, vi } from 'vitest';
import fs from 'node:fs/promises';
import path from 'node:path';
import { prisma } from '../../src/database/client.js';
import { youtubeUploadEngine } from '../../src/services/youtube/youtubeUploadEngine.js';
import { youtubeAuthService } from '../../src/services/youtube/youtubeAuth.js';
import { storageManager } from '../../src/storage/storageManager.js';

describe('YouTube Upload Engine & Duplicate Prevention', () => {
  let channelId: string;
  let projectId: string;
  let mockYoutubeClient: any;

  beforeEach(async () => {
    // Mock YouTube client
    mockYoutubeClient = {
      videos: {
        insert: vi.fn().mockImplementation((params: any, options: any) => {
          // Simulate progress
          options?.onUploadProgress?.({ bytesRead: 1024 });
          return Promise.resolve({
            data: { id: `mock_yt_vid_${Date.now()}_${Math.random().toString(36).slice(2, 6)}` },
          });
        }),
        list: vi.fn().mockResolvedValue({
          data: {
            items: [
              {
                id: 'mock_yt_vid_12345',
                snippet: { title: 'Test Video', description: 'Test Desc' },
                status: { uploadStatus: 'processed', privacyStatus: 'private' },
                statistics: { viewCount: '100' },
              },
            ],
          },
        }),
        update: vi.fn().mockResolvedValue({
          data: { id: 'mock_yt_vid_12345', snippet: { title: 'Updated Title' } },
        }),
      },
      thumbnails: {
        set: vi.fn().mockResolvedValue({ data: {} }),
      },
      playlistItems: {
        insert: vi.fn().mockResolvedValue({ data: {} }),
      },
    };

    vi.spyOn(youtubeAuthService, 'getAuthenticatedClient').mockResolvedValue({
      oauth2Client: {} as any,
      youtube: mockYoutubeClient as any,
    });

    const user = await prisma.user.upsert({
      where: { email: 'upload_test_user@contentpilot.ai' },
      update: {},
      create: { email: 'upload_test_user@contentpilot.ai', name: 'Upload User' },
    });

    const channel = await prisma.channel.create({
      data: {
        userId: user.id,
        name: 'Upload Test Channel',
        niche: 'AI Tech',
        targetAudience: 'Devs',
        brandVoice: 'Clear',
        visualStyle: 'Dark',
      },
    });
    channelId = channel.id;

    // Full valid pipeline artifacts
    const strategy = await prisma.contentStrategy.create({
      data: {
        channelId,
        titleConcept: 'Safe Uploading In Production',
        hook: 'Never risk duplicate uploads.',
        angle: 'Resilience',
        targetAudience: 'Devs',
        primaryKeyword: 'upload',
        cta: 'Sub',
        thumbnailConcept: 'Network icon',
        reasonForSelection: 'Testing',
      },
    });

    const script = await prisma.script.create({
      data: {
        strategyId: strategy.id,
        channelId,
        title: 'Safe Uploading Screenplay',
        hookText: 'Hook text',
        hookVisualCue: 'Hook cue',
        sectionsJson: '[]',
        ctaText: 'Cta',
        ctaVisualCue: 'Cue',
        outroText: 'Outro',
        outroVisualCue: 'Cue',
      },
    });

    const project = await prisma.videoProject.create({
      data: {
        channelId,
        title: 'Safe Upload Video',
        scriptId: script.id,
        status: 'APPROVED',
      },
    });
    projectId = project.id;

    const videoDir = storageManager.getVideoDir(projectId);
    const mp4Path = path.join(videoDir, 'master.mp4');
    await fs.writeFile(mp4Path, Buffer.from('ftypmp42video'));

    const audioDir = storageManager.getAudioDir(projectId);
    const audioPath = path.join(audioDir, 'audio.wav');
    await fs.writeFile(audioPath, Buffer.from('RIFFwav'));

    await prisma.approvalRequest.create({
      data: {
        projectId,
        channelId,
        status: 'APPROVED',
        approvedBy: 'super_admin@contentpilot.ai',
        approvedAt: new Date(),
      },
    });

    await prisma.qualityCheck.create({
      data: {
        projectId,
        passed: true,
        status: 'PASS',
        overallScore: 99.0,
        loudnessLufs: -14.0,
      },
    });

    await prisma.videoRender.create({
      data: {
        projectId,
        outputPath: mp4Path,
        durationSec: 10.0,
        fileSize: 1024,
        status: 'completed',
        renderTimeSec: 1.0,
      },
    });

    const narration = await prisma.narration.create({
      data: {
        scriptId: script.id,
        channelId,
        voiceId: 'narrator_1',
        audioPath,
        durationSec: 10.0,
        status: 'validated',
      },
    });

    const seo = await prisma.seoPackage.create({
      data: {
        scriptId: script.id,
        channelId,
        recommendedTitle: 'Safe Resumable YouTube Upload Pipeline',
        titleCandidatesJson: '[]',
        description: 'Detailed description for safe resumable upload pipeline testing.',
        chaptersJson: '[]',
        tagsJson: '["resumable", "upload"]',
        hashtagsJson: '["#upload"]',
        primaryKeyword: 'upload',
      },
    });

    await prisma.videoProject.update({
      where: { id: projectId },
      data: {
        narrationId: narration.id,
        seoPackageId: seo.id,
      },
    });
  });

  it('should successfully execute upload and persist YouTubeVideo record', async () => {
    let progressReported = false;
    const result = await youtubeUploadEngine.upload(
      {
        projectId,
        channelId,
        privacyStatus: 'private',
      },
      (p) => {
        if (p.percentage > 0) progressReported = true;
      }
    );

    expect(result.youtubeVideoId).toContain('mock_yt_vid_');
    expect(result.youtubeUrl).toContain(result.youtubeVideoId);
    expect(mockYoutubeClient.videos.insert).toHaveBeenCalledTimes(1);

    const saved = await prisma.youTubeVideo.findUnique({
      where: { youtubeVideoId: result.youtubeVideoId },
    });
    expect(saved).not.toBeNull();
    expect(saved?.projectId).toBe(projectId);
  });

  it('should NEVER create a duplicate upload on retry (idempotency guarantee)', async () => {
    // First upload
    const result1 = await youtubeUploadEngine.upload({
      projectId,
      channelId,
      privacyStatus: 'private',
    });

    expect(mockYoutubeClient.videos.insert).toHaveBeenCalledTimes(1);

    // Immediate retry on the same project
    const result2 = await youtubeUploadEngine.upload({
      projectId,
      channelId,
      privacyStatus: 'private',
    });

    // YouTube API MUST NOT be called a second time!
    expect(mockYoutubeClient.videos.insert).toHaveBeenCalledTimes(1);
    expect(result2.youtubeVideoId).toBe(result1.youtubeVideoId);

    // Only 1 record in youTubeVideo table
    const records = await prisma.youTubeVideo.findMany({ where: { projectId } });
    expect(records).toHaveLength(1);
  });

  it('should classify and handle YouTube quota exceeded errors', async () => {
    mockYoutubeClient.videos.insert.mockRejectedValueOnce(
      new Error('quotaExceeded: YouTube API quota limit reached for today')
    );

    // Create a new un-uploaded project
    const unuploadedProject = await prisma.videoProject.create({
      data: {
        channelId,
        title: 'Quota Project',
        status: 'APPROVED',
      },
    });

    // Setup approval, QC, render, narration, seo for it
    await prisma.approvalRequest.create({
      data: {
        projectId: unuploadedProject.id,
        channelId,
        status: 'APPROVED',
        approvedBy: 'admin',
        approvedAt: new Date(),
      },
    });
    await prisma.qualityCheck.create({
      data: {
        projectId: unuploadedProject.id,
        passed: true,
        status: 'PASS',
        overallScore: 90,
        loudnessLufs: -14,
      },
    });

    const videoDir = storageManager.getVideoDir(unuploadedProject.id);
    const mp4Path = path.join(videoDir, 'quota.mp4');
    await fs.writeFile(mp4Path, Buffer.from('ftypmp42data'));

    await prisma.videoRender.create({
      data: {
        projectId: unuploadedProject.id,
        outputPath: mp4Path,
        durationSec: 5,
        fileSize: 100,
        status: 'completed',
        renderTimeSec: 1,
      },
    });

    const quotaStrategy = await prisma.contentStrategy.create({
      data: {
        channelId,
        titleConcept: 'Quota Strategy',
        hook: 'Quota hook',
        angle: 'Testing',
        targetAudience: 'Devs',
        primaryKeyword: 'quota',
        cta: 'Sub',
        thumbnailConcept: 'Icon',
        reasonForSelection: 'Testing',
      },
    });

    const quotaScript = await prisma.script.create({
      data: {
        strategyId: quotaStrategy.id,
        channelId,
        title: 'Quota Script',
        hookText: 'Hook',
        hookVisualCue: 'Cue',
        sectionsJson: '[]',
        ctaText: 'Cta',
        ctaVisualCue: 'Cue',
        outroText: 'Outro',
        outroVisualCue: 'Cue',
      },
    });

    const narration = await prisma.narration.create({
      data: {
        scriptId: quotaScript.id,
        channelId,
        voiceId: 'v1',
        audioPath: mp4Path,
        durationSec: 5,
        status: 'validated',
      },
    });

    const seo = await prisma.seoPackage.create({
      data: {
        scriptId: narration.scriptId,
        channelId,
        recommendedTitle: 'Quota Test Title',
        titleCandidatesJson: '[]',
        description: 'Quota Test Description Long Enough',
        chaptersJson: '[]',
        tagsJson: '[]',
        hashtagsJson: '[]',
        primaryKeyword: 'quota',
      },
    });

    await prisma.videoProject.update({
      where: { id: unuploadedProject.id },
      data: { narrationId: narration.id, seoPackageId: seo.id },
    });

    await expect(
      youtubeUploadEngine.upload({
        projectId: unuploadedProject.id,
        channelId,
      })
    ).rejects.toThrow(/quota/i);

    const queue = await prisma.publishingQueue.findUnique({
      where: { projectId: unuploadedProject.id },
    });
    expect(queue?.status).toBe('FAILED');
    expect(queue?.lastError).toContain('quota');
  });

  it('should inspect video status from YouTube API', async () => {
    const status = await youtubeUploadEngine.getVideoStatus(channelId, 'mock_yt_vid_12345');
    expect(status.uploadStatus).toBe('processed');
    expect(status.viewCount).toBe(100);
  });
});
