import { describe, it, expect, beforeEach, vi } from 'vitest';
import { prisma } from '../../src/database/client.js';
import { youtubeAnalyticsService } from '../../src/services/analytics/youtubeAnalyticsService.js';
import { learningAgent } from '../../src/services/learning/learningAgent.js';
import { experimentService } from '../../src/services/experiments/experimentService.js';
import { youtubeAuthService } from '../../src/services/youtube/youtubeAuth.js';

describe('Analytics, Learning Agent & Experiment System', () => {
  let channelId: string;
  let youtubeVideoId: string;

  beforeEach(async () => {
    const user = await prisma.user.upsert({
      where: { email: 'analytics_test@contentpilot.ai' },
      update: {},
      create: { email: 'analytics_test@contentpilot.ai', name: 'Analytics User' },
    });

    const channel = await prisma.channel.create({
      data: {
        userId: user.id,
        name: 'Analytics Channel',
        niche: 'AI Engineering',
        targetAudience: 'Software Developers',
        brandVoice: 'Rigorous',
        visualStyle: 'Dark Minimal',
        settings: {
          create: {
            defaultFormat: 'explainer',
            preferredPublishTime: '14:00',
          },
        },
      },
      include: { settings: true },
    });
    channelId = channel.id;

    // Mock youtube client for analytics
    const mockYoutube = {
      videos: {
        list: vi.fn().mockResolvedValue({
          data: {
            items: [
              {
                id: 'yt_mock_vid_777',
                snippet: {
                  title: 'How Autonomous AI Agents Work in Production',
                  publishedAt: new Date(Date.now() - 48 * 3600 * 1000).toISOString(),
                  thumbnails: { high: { url: 'https://example.com/thumb.jpg' } },
                },
                contentDetails: { duration: 'PT8M24S' },
                statistics: {
                  viewCount: '15400',
                  likeCount: '1240',
                  commentCount: '185',
                },
              },
            ],
          },
        }),
      },
    };

    vi.spyOn(youtubeAuthService, 'getAuthenticatedClient').mockResolvedValue({
      oauth2Client: {} as any,
      youtube: mockYoutube as any,
    });

    const project = await prisma.videoProject.create({
      data: {
        channelId,
        title: 'How Autonomous AI Agents Work in Production',
        status: 'PUBLISHED',
      },
    });

    const ytVideo = await prisma.youTubeVideo.create({
      data: {
        projectId: project.id,
        channelId,
        youtubeVideoId: `yt_vid_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        youtubeUrl: 'https://youtube.com/watch?v=mock',
        title: 'How Autonomous AI Agents Work in Production',
        description: 'Deep dive into multi-agent systems without mocks.',
        publishedAt: new Date(Date.now() - 48 * 3600 * 1000),
      },
    });
    youtubeVideoId = ytVideo.youtubeVideoId;
  });

  describe('YouTube Analytics Ingestion (Zero-Fabrication)', () => {
    it('should parse ISO 8601 duration string accurately', () => {
      expect(youtubeAnalyticsService.parseIsoDuration('PT4M13S')).toBe(253);
      expect(youtubeAnalyticsService.parseIsoDuration('PT1H2M10S')).toBe(3730);
      expect(youtubeAnalyticsService.parseIsoDuration('PT45S')).toBe(45);
    });

    it('should capture authentic telemetry without fabricating missing fields', async () => {
      const telemetry = await youtubeAnalyticsService.fetchRealTelemetry(channelId, youtubeVideoId);
      expect(telemetry.views).toBe(15400);
      expect(telemetry.likes).toBe(1240);
      expect(telemetry.comments).toBe(185);
      expect(telemetry.averageViewDurationSec).toBeGreaterThan(0);
      expect(telemetry.retentionCurve).toEqual([]); // Zero fabrication guarantee!
    });

    it('should create and persist analytics snapshot', async () => {
      const snap = await youtubeAnalyticsService.captureSnapshot(channelId, youtubeVideoId, '24h');
      expect(snap.views).toBe(15400);
      expect(snap.measurementWindow).toBe('24h');

      const snapshots = await youtubeAnalyticsService.getSnapshots(youtubeVideoId);
      expect(snapshots.length).toBeGreaterThanOrEqual(1);
    });
  });

  describe('Learning Agent & Evidence Confidence Rules', () => {
    it('should scale confidence strictly according to observation sample size', () => {
      // < 3 observations: capped at 0.20
      expect(learningAgent.calculateConfidence(1, 1)).toBeLessThanOrEqual(0.20);
      expect(learningAgent.calculateConfidence(2, 2)).toBeLessThanOrEqual(0.20);

      // 3 - 5 observations: moderate confidence (0.3 - 0.55)
      expect(learningAgent.calculateConfidence(4, 3)).toBeGreaterThan(0.25);
      expect(learningAgent.calculateConfidence(4, 3)).toBeLessThanOrEqual(0.55);

      // >= 6 observations: strong confidence
      expect(learningAgent.calculateConfidence(10, 8)).toBeGreaterThan(0.60);
    });

    it('should analyze channel and format insights with INSIGHT, EVIDENCE, CONFIDENCE, RECOMMENDATION', async () => {
      // Ingest a snapshot first
      await youtubeAnalyticsService.captureSnapshot(channelId, youtubeVideoId, 'lifetime');

      const insights = await learningAgent.analyzeChannel(channelId);
      expect(insights.length).toBeGreaterThanOrEqual(1);

      for (const item of insights) {
        expect(item.insight).toBeTruthy();
        expect(item.evidence).toBeTruthy();
        expect(typeof item.confidence).toBe('number');
        expect(item.confidence).toBeGreaterThanOrEqual(0.0);
        expect(item.confidence).toBeLessThanOrEqual(1.0);
        expect(item.recommendation).toBeTruthy();
      }
    });
  });

  describe('Experiment System & Human Approval Gate', () => {
    it('should create and conclude an A/B experiment', async () => {
      const exp = await experimentService.createExperiment({
        channelId,
        title: 'Title Format Test: Question vs Direct Statement',
        hypothesis: 'Question titles yield higher retention than statements',
        baseline: 'How AI Agents Work in Production',
        variant: 'Can AI Agents Replace Autonomous Engineers?',
        experimentType: 'titles',
        metric: 'views',
      });

      expect(exp.status).toBe('draft');
      expect(exp.humanApproved).toBe(false);

      const concluded = await experimentService.concludeExperiment(exp.id, {
        baselineMetricValue: 12000,
        variantMetricValue: 16500,
        sampleSizeA: 15,
        sampleSizeB: 15,
      });

      expect(concluded.status).toBe('concluded');
      expect(concluded.winnerVariant).toBe('Can AI Agents Replace Autonomous Engineers?');
    });

    it('should strictly BLOCK applying experiment winner to channel without explicit human approval', async () => {
      const exp = await experimentService.createExperiment({
        channelId,
        title: 'Default Video Format Test',
        hypothesis: 'Documentary format outperforms Explainer format',
        baseline: 'explainer',
        variant: 'documentary',
        experimentType: 'formats',
      });

      await experimentService.concludeExperiment(exp.id, {
        baselineMetricValue: 10000,
        variantMetricValue: 18000,
        sampleSizeA: 10,
        sampleSizeB: 10,
      });

      // Attempt to apply WITHOUT approval -> MUST THROW!
      await expect(experimentService.applyExperimentWinner(exp.id)).rejects.toThrow(/approval/i);
    });

    it('should apply winner to channel settings once human approval is explicitly granted', async () => {
      const exp = await experimentService.createExperiment({
        channelId,
        title: 'Publish Timing Test',
        hypothesis: '18:00 UTC achieves higher velocity than 14:00 UTC',
        baseline: '14:00',
        variant: '18:00',
        experimentType: 'publish_timing',
      });

      await experimentService.concludeExperiment(exp.id, {
        baselineMetricValue: 8000,
        variantMetricValue: 14000,
        sampleSizeA: 8,
        sampleSizeB: 8,
      });

      // Explicit human approval
      await experimentService.approveExperimentWinner(exp.id, 'channel_lead@contentpilot.ai');

      // Now apply should succeed
      await experimentService.applyExperimentWinner(exp.id);

      const updatedExp = await prisma.experiment.findUnique({ where: { id: exp.id } });
      expect(updatedExp?.status).toBe('applied');

      const setting = await prisma.channelSetting.findUnique({ where: { channelId } });
      expect(setting?.preferredPublishTime).toBe('18:00');
    });
  });
});
