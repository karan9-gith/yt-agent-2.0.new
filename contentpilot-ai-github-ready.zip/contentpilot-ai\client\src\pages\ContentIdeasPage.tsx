import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { EmptyState } from '../components/EmptyState';
import { Lightbulb, Plus, Check, Trash2, ArrowRight } from 'lucide-react';

interface ContentIdeasPageProps {
  channelId: string;
  onNavigate: (page: any) => void;
}

export const ContentIdeasPage: React.FC<ContentIdeasPageProps> = ({ channelId, onNavigate }) => {
  const [ideas, setIdeas] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [showModal, setShowModal] = useState(false);
  const [newTopic, setNewTopic] = useState('');
  const [newAngle, setNewAngle] = useState('');
  const [newAudience, setNewAudience] = useState('Engineers & Tech Enthusiasts');

  useEffect(() => {
    loadIdeas();
  }, [channelId, filter]);

  const loadIdeas = async () => {
    try {
      setLoading(true);
      const statusParam = filter === 'all' ? undefined : filter;
      const data = await api.getContentIdeas(channelId, statusParam);
      setIdeas(data);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (id: string, status: string) => {
    try {
      await api.updateIdeaStatus(id, status);
      await loadIdeas();
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreateCustom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTopic || !newAngle) return;
    try {
      await api.createIdea({
        channelId,
        topic: newTopic,
        angle: newAngle,
        targetAudience: newAudience,
      });
      setShowModal(false);
      setNewTopic('');
      setNewAngle('');
      await loadIdeas();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Content Ideas Backlog</h1>
          <p className="page-description">
            Ranked video topics evaluated on search intent, novelty, competition, and evergreen shelf life.
          </p>
        </div>
        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <select className="select" value={filter} onChange={(e) => setFilter(e.target.value)} style={{ width: '150px' }}>
            <option value="all">All Statuses</option>
            <option value="selected">Selected</option>
            <option value="backlog">Backlog</option>
            <option value="planned">Planned</option>
            <option value="discarded">Discarded</option>
          </select>
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>
            <Plus size={16} /> New Idea
          </button>
        </div>
      </div>

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Loading ideas...</p>
      ) : ideas.length === 0 ? (
        <EmptyState
          title="No content ideas found."
          message="Run market research or click 'New Idea' to manually add high-conviction video concepts."
          actionText="Create Custom Idea"
          onAction={() => setShowModal(true)}
        />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '1rem' }}>
          {ideas.map((idea) => (
            <div key={idea.id} className="glass-card" style={{ padding: '1.25rem', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
                  <span
                    className={`badge ${
                      idea.status === 'selected'
                        ? 'badge-success'
                        : idea.status === 'planned'
                        ? 'badge-info'
                        : idea.status === 'discarded'
                        ? 'badge-danger'
                        : 'badge-warning'
                    }`}
                  >
                    {idea.status}
                  </span>
                  <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#34d399' }}>
                    Score: {idea.trendScore}
                  </div>
                </div>

                <h3 style={{ fontSize: '1.05rem', fontWeight: 700, lineHeight: 1.3, marginBottom: '6px' }}>{idea.topic}</h3>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '12px', lineHeight: 1.4 }}>
                  {idea.angle}
                </p>

                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '1fr 1fr',
                    gap: '6px',
                    fontSize: '0.75rem',
                    background: 'var(--bg-surface-elevated)',
                    padding: '8px',
                    borderRadius: '6px',
                    marginBottom: '1rem',
                  }}
                >
                  <div>Novelty: <strong>{idea.noveltyScore}%</strong></div>
                  <div>Competition: <strong>{idea.competitionScore}%</strong></div>
                  <div>Evergreen: <strong>{idea.evergreenScore}%</strong></div>
                  <div>Risk: <strong>{idea.riskScore}%</strong></div>
                </div>
              </div>

              {/* Status Action Buttons */}
              <div style={{ display: 'flex', gap: '0.5rem', borderTop: '1px solid var(--border-subtle)', paddingTop: '10px' }}>
                {idea.status !== 'selected' && (
                  <button
                    className="btn btn-secondary"
                    style={{ flex: 1, padding: '6px', fontSize: '0.75rem' }}
                    onClick={() => handleUpdateStatus(idea.id, 'selected')}
                  >
                    <Check size={14} /> Select
                  </button>
                )}
                {idea.status !== 'discarded' && (
                  <button
                    className="btn btn-danger"
                    style={{ padding: '6px', fontSize: '0.75rem' }}
                    onClick={() => handleUpdateStatus(idea.id, 'discarded')}
                    title="Discard idea"
                  >
                    <Trash2 size={14} />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal for Custom Idea */}
      {showModal && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.7)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 100,
          }}
        >
          <div className="glass-panel" style={{ width: '480px', padding: '1.75rem', background: 'var(--bg-surface)' }}>
            <h2 style={{ fontSize: '1.2rem', fontWeight: 800, marginBottom: '1rem' }}>Create Content Idea</h2>
            <form onSubmit={handleCreateCustom} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Topic Headline</label>
                <input
                  className="input"
                  style={{ marginTop: '4px' }}
                  value={newTopic}
                  onChange={(e) => setNewTopic(e.target.value)}
                  placeholder="e.g. How Transformers Revolutionized Reasoning"
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Narrative Angle</label>
                <textarea
                  className="textarea"
                  style={{ marginTop: '4px', minHeight: '80px' }}
                  value={newAngle}
                  onChange={(e) => setNewAngle(e.target.value)}
                  placeholder="e.g. A deep technical breakdown contrasting pure autoregression with chain-of-thought..."
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Target Audience</label>
                <input
                  className="input"
                  style={{ marginTop: '4px' }}
                  value={newAudience}
                  onChange={(e) => setNewAudience(e.target.value)}
                />
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem' }}>
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Save Idea
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
