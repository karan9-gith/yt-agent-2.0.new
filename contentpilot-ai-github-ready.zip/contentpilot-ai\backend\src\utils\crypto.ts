import crypto from 'node:crypto';
import { config } from '../config/index.js';
import { SecurityError } from './errors.js';

/**
 * Derive 32-byte encryption key from application secret
 */
function getMasterKey(): Buffer {
  return crypto.createHash('sha256').update(config.APP_SECRET_KEY).digest();
}

/**
 * Encrypt plaintext using authenticated AES-256-GCM
 */
export function encryptSecret(plainText: string): string {
  try {
    const key = getMasterKey();
    const iv = crypto.randomBytes(12); // 96-bit IV recommended for GCM
    const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);

    const encrypted = Buffer.concat([cipher.update(plainText, 'utf8'), cipher.final()]);
    const tag = cipher.getAuthTag();

    // Format: ivHex:tagHex:cipherHex
    return `${iv.toString('hex')}:${tag.toString('hex')}:${encrypted.toString('hex')}`;
  } catch (error) {
    throw new SecurityError(`Encryption failed: ${(error as Error).message}`);
  }
}

/**
 * Decrypt ciphertext using authenticated AES-256-GCM
 */
export function decryptSecret(cipherString: string): string {
  try {
    const parts = cipherString.split(':');
    if (parts.length !== 3) {
      throw new SecurityError('Malformed encrypted payload format');
    }

    const [ivHex, tagHex, encryptedHex] = parts;
    const iv = Buffer.from(ivHex, 'hex');
    const tag = Buffer.from(tagHex, 'hex');
    const encrypted = Buffer.from(encryptedHex, 'hex');

    const key = getMasterKey();
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAuthTag(tag);

    const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
    return decrypted.toString('utf8');
  } catch (error) {
    throw new SecurityError(`Decryption failed or invalid auth tag: ${(error as Error).message}`);
  }
}
