import express, { Express, Request, Response, NextFunction } from 'express';
import cors from 'cors';
import path from 'node:path';
import fsSync from 'node:fs';
import { config } from './config/index.js';
import reviewStudioRoutes from './api/reviewStudio.routes.js';
import youtubeRoutes from './api/youtube.routes.js';
import schedulerRoutes from './api/scheduler.routes.js';
import analyticsRoutes from './api/analytics.routes.js';
import learningRoutes from './api/learning.routes.js';
import experimentsRoutes from './api/experiments.routes.js';
import operatorRoutes from './api/operator.routes.js';
import overviewRoutes from './api/overview.routes.js';
import healthRoutes from './api/health.routes.js';
import productionRoutes from './api/production.routes.js';
import researchRoutes from './api/research.routes.js';
import ideasRoutes from './api/ideas.routes.js';
import strategyRoutes from './api/strategy.routes.js';
import scriptsRoutes from './api/scripts.routes.js';
import thumbnailsRoutes from './api/thumbnails.routes.js';
import publishingQueueRoutes from './api/publishingQueue.routes.js';
import providersRoutes from './api/providers.routes.js';
import settingsRoutes from './api/settings.routes.js';
import logsRoutes from './api/logs.routes.js';
import mediaRoutes from './api/media.routes.js';
import { persistentScheduler } from './services/scheduler/schedulerEngine.js';
import { jobWorkerManager } from './jobs/jobWorker.js';

const app: Express = express();

// Security and utility middleware
const allowedOrigins = config.CORS_ORIGIN.split(',')
  .map((o) => o.trim().replace(/\/+$/, ''))
  .filter(Boolean);

app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin) return callback(null, true);
      const normalizedOrigin = origin.trim().replace(/\/+$/, '');
      if (allowedOrigins.includes('*') || allowedOrigins.includes(normalizedOrigin)) {
        return callback(null, true);
      }
      return callback(new Error(`CORS policy blocked access from origin: ${origin}`));
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'Range'],
    exposedHeaders: ['Content-Range', 'Accept-Ranges', 'Content-Length'],
  })
);
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Health and Readiness Checks
app.get('/health', (_req: Request, res: Response) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    platform: 'ContentPilot AI',
    governance: {
      autoPublish: config.AUTO_PUBLISH,
      requireHumanApproval: config.REQUIRE_HUMAN_APPROVAL,
    },
  });
});

// Mount modular sub-systems
app.use('/health/detailed', healthRoutes);
app.use('/api/health', healthRoutes);
app.use('/api/overview', overviewRoutes);
app.use('/api/approval', reviewStudioRoutes);
app.use('/api/review', reviewStudioRoutes);
app.use('/api/youtube', youtubeRoutes);
app.use('/api/auth/youtube', youtubeRoutes);
app.use('/api/scheduler', schedulerRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/learning', learningRoutes);
app.use('/api/experiments', experimentsRoutes);
app.use('/api/operator', operatorRoutes);
app.use('/api/production', productionRoutes);
app.use('/api/research', researchRoutes);
app.use('/api/ideas', ideasRoutes);
app.use('/api/strategy', strategyRoutes);
app.use('/api/scripts', scriptsRoutes);
app.use('/api/thumbnails', thumbnailsRoutes);
app.use('/api/publishing-queue', publishingQueueRoutes);
app.use('/api/providers', providersRoutes);
app.use('/api/settings', settingsRoutes);
app.use('/api/logs', logsRoutes);
app.use('/api/media', mediaRoutes);

// API Root Info
app.get('/api', (_req: Request, res: Response) => {
  res.json({
    name: 'ContentPilot AI Core API',
    description: 'Autonomous YouTube operations platform with multi-agent orchestration',
    endpoints: {
      health: '/health',
      healthDetailed: '/api/health',
      overview: '/api/overview',
      review: '/api/review',
      approval: '/api/approval',
      youtube: '/api/youtube',
      scheduler: '/api/scheduler',
      analytics: '/api/analytics',
      learning: '/api/learning',
      experiments: '/api/experiments',
      operator: '/api/operator',
      production: '/api/production',
      research: '/api/research',
      ideas: '/api/ideas',
      strategy: '/api/strategy',
      scripts: '/api/scripts',
      thumbnails: '/api/thumbnails',
      publishingQueue: '/api/publishing-queue',
      providers: '/api/providers',
      settings: '/api/settings',
      logs: '/api/logs',
      media: '/api/media',
    },
  });
});

// Optional static frontend hosting for single-port fullstack deployments
if (config.SERVE_STATIC_CLIENT) {
  const clientDist = config.CLIENT_DIST_PATH
    ? path.resolve(config.CLIENT_DIST_PATH)
    : path.resolve(process.cwd(), '../client/dist');

  if (fsSync.existsSync(clientDist)) {
    app.use(express.static(clientDist));
    app.get('*', (req: Request, res: Response, next: NextFunction) => {
      if (req.path.startsWith('/api') || req.path.startsWith('/health')) {
        return next();
      }
      res.sendFile(path.join(clientDist, 'index.html'));
    });
  }
}

// Global Error Handler
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
  console.error('Unhandled server error:', err);
  const statusCode = (err as { statusCode?: number }).statusCode || 500;
  res.status(statusCode).json({
    success: false,
    error: err.message || 'Internal Server Error',
  });
});

// Server boot listener & background systems
if (process.env.NODE_ENV !== 'test') {
  app.listen(config.PORT, async () => {
    console.log(`===================================================`);
    console.log(`🚀 ContentPilot AI Server running on port ${config.PORT}`);
    console.log(`🔒 AUTO_PUBLISH: ${config.AUTO_PUBLISH} (Safe Default)`);
    console.log(`👤 Human Approval Required: ${config.REQUIRE_HUMAN_APPROVAL}`);
    console.log(`===================================================`);

    if (process.env.DISABLE_BACKGROUND_WORKERS !== 'true' && !config.DISABLE_BACKGROUND_WORKERS) {
      try {
        await jobWorkerManager.start();
        await persistentScheduler.start();
      } catch (bootErr) {
        console.error('Failed to start background systems on boot:', bootErr);
      }
    }
  });
}

export default app;
