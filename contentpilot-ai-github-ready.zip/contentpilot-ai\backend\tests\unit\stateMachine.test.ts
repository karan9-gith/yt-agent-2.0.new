import { describe, it, expect, beforeEach } from 'vitest';
import { prisma } from '../../src/database/client.js';
import { pipelineStateMachine, InvalidStateTransitionError } from '../../src/core/pipeline/stateMachine.js';
import { VideoPipelineState } from '../../src/core/pipeline/stateTypes.js';

describe('Autonomous Pipeline State Machine', () => {
  let channelId: string;
  let projectId: string;

  beforeEach(async () => {
    // Create test user and channel if not exists
    const user = await prisma.user.upsert({
      where: { email: 'test_state_machine@contentpilot.ai' },
      update: {},
      create: {
        email: 'test_state_machine@contentpilot.ai',
        name: 'State Machine Test User',
      },
    });

    const channel = await prisma.channel.create({
      data: {
        userId: user.id,
        name: 'State Machine Channel',
        niche: 'AI Tech',
        targetAudience: 'Engineers',
        brandVoice: 'Authoritative',
        visualStyle: 'Modern Dark',
      },
    });
    channelId = channel.id;

    const project = await prisma.videoProject.create({
      data: {
        channelId,
        title: 'State Machine Test Video',
        status: VideoPipelineState.IDEA,
      },
    });
    projectId = project.id;
  });

  it('should allow valid sequential stage transitions', async () => {
    await pipelineStateMachine.transition(projectId, VideoPipelineState.RESEARCHED, 'agent_complete');
    let fresh = await prisma.videoProject.findUnique({ where: { id: projectId } });
    expect(fresh?.status).toBe(VideoPipelineState.RESEARCHED);

    await pipelineStateMachine.transition(projectId, VideoPipelineState.STRATEGY_READY, 'agent_complete');
    fresh = await prisma.videoProject.findUnique({ where: { id: projectId } });
    expect(fresh?.status).toBe(VideoPipelineState.STRATEGY_READY);

    await pipelineStateMachine.transition(projectId, VideoPipelineState.SCRIPT_READY, 'agent_complete');
    fresh = await prisma.videoProject.findUnique({ where: { id: projectId } });
    expect(fresh?.status).toBe(VideoPipelineState.SCRIPT_READY);
  });

  it('should reject invalid state transitions', async () => {
    await expect(
      pipelineStateMachine.transition(projectId, VideoPipelineState.PUBLISHED, 'system')
    ).rejects.toThrow(InvalidStateTransitionError);
  });

  it('should strictly reject publishing or upload transitions without explicit prior approval', async () => {
    // Attempting to bypass approval from QC_PASSED to UPLOADING
    await prisma.videoProject.update({
      where: { id: projectId },
      data: { status: VideoPipelineState.QC_PASSED },
    });

    await expect(
      pipelineStateMachine.transition(projectId, VideoPipelineState.UPLOADING, 'system')
    ).rejects.toThrow(/approval/i);
  });

  it('should support editorial rollback transitions from AWAITING_APPROVAL', async () => {
    await prisma.videoProject.update({
      where: { id: projectId },
      data: { status: VideoPipelineState.AWAITING_APPROVAL },
    });

    // Reviewer sends back to script
    await pipelineStateMachine.transition(
      projectId,
      VideoPipelineState.SCRIPT_READY,
      'user_action',
      { reason: 'Revise hook' }
    );

    const fresh = await prisma.videoProject.findUnique({ where: { id: projectId } });
    expect(fresh?.status).toBe(VideoPipelineState.SCRIPT_READY);
  });

  it('should persist every transition in PipelineStateLog', async () => {
    await pipelineStateMachine.transition(projectId, VideoPipelineState.RESEARCHED, 'agent_complete', { runId: 'run123' });

    const logs = await pipelineStateMachine.getHistory(projectId);
    expect(logs.length).toBeGreaterThanOrEqual(1);
    const latest = logs[logs.length - 1];
    expect(latest.fromState).toBe(VideoPipelineState.IDEA);
    expect(latest.toState).toBe(VideoPipelineState.RESEARCHED);
    expect(latest.trigger).toBe('agent_complete');
  });
});
