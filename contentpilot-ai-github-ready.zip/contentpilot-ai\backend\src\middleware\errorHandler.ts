import { Request, Response, NextFunction } from 'express';
import { ZodError } from 'zod';
import { AppError } from '../utils/errors.js';
import { logger } from '../utils/logger.js';

export function errorHandler(
  err: Error,
  _req: Request,
  res: Response,
  _next: NextFunction
): void {
  // Handle Zod Validation Errors
  if (err instanceof ZodError) {
    logger.warn({ msg: 'Request Schema Validation Failed', issues: err.issues });
    res.status(400).json({
      success: false,
      code: 'VALIDATION_ERROR',
      error: 'Invalid request data',
      details: err.issues.map((i) => ({
        path: i.path.join('.'),
        message: i.message,
      })),
    });
    return;
  }

  // Handle Operational App Errors
  if (err instanceof AppError) {
    logger.warn({ msg: 'Operational Application Error', code: err.code, error: err.message });
    res.status(err.statusCode).json({
      success: false,
      code: err.code,
      error: err.message,
      details: (err as unknown as { details?: unknown }).details,
    });
    return;
  }

  // Unhandled Programmer / System Errors
  logger.error({ msg: 'Unhandled Server Exception', error: err.message, stack: err.stack });
  res.status(500).json({
    success: false,
    code: 'INTERNAL_SERVER_ERROR',
    error: 'An internal error occurred. Please contact administrator.',
  });
}
