import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { ReviewBundle } from '../types';
import { EmptyState } from '../components/EmptyState';
import { VideoPlayer } from '../components/VideoPlayer';
import {
  Check,
  X,
  Edit,
  RotateCcw,
  CornerUpLeft,
  Calendar,
  ShieldCheck,
  AlertTriangle,
  FileText,
  Clock,
  Layers,
  Sparkles,
} from 'lucide-react';

interface ReviewStudioPageProps {
  channelId: string;
  onNavigate: (page: any) => void;
}

export const ReviewStudioPage: React.FC<ReviewStudioPageProps> = ({ channelId, onNavigate }) => {
  const [pendingList, setPendingList] = useState<any[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [bundle, setBundle] = useState<ReviewBundle | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  // Action dialog states
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [scheduleTime, setScheduleTime] = useState('');
  const [showEditModal, setShowEditModal] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [reviewerName, setReviewerName] = useState('supervising_editor@contentpilot.ai');

  useEffect(() => {
    loadPending();
  }, [channelId]);

  const loadPending = async () => {
    try {
      setLoading(true);
      const list = await api.getPendingApprovals(channelId);
      setPendingList(list);
      if (list.length > 0) {
        await selectProject(list[0].projectId);
      } else {
        setBundle(null);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const selectProject = async (projectId: string) => {
    try {
      setSelectedProjectId(projectId);
      const data = await api.getReviewBundle(projectId);
      setBundle(data);
      setEditTitle(data.metadata.title);
      setEditDesc(data.metadata.description);
    } catch (err) {
      console.error(err);
    }
  };

  const handleApprove = async () => {
    if (!selectedProjectId) return;
    try {
      setActionLoading(true);
      setMessage(null);
      await api.approveProject(selectedProjectId, reviewerName, 'Human editorial sign-off completed');
      setMessage('Project explicitly approved! Pre-upload safety check gate opened.');
      await loadPending();
    } catch (err: any) {
      setMessage(`Approval failed: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleReject = async () => {
    if (!selectedProjectId || !rejectReason) return;
    try {
      setActionLoading(true);
      setMessage(null);
      await api.rejectProject(selectedProjectId, reviewerName, rejectReason);
      setShowRejectModal(false);
      setRejectReason('');
      setMessage('Project rejected.');
      await loadPending();
    } catch (err: any) {
      setMessage(`Reject failed: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleEdit = async () => {
    if (!selectedProjectId) return;
    try {
      setActionLoading(true);
      await api.editProject(selectedProjectId, { title: editTitle, description: editDesc }, reviewerName);
      setShowEditModal(false);
      setMessage('Metadata updated.');
      await selectProject(selectedProjectId);
    } catch (err: any) {
      setMessage(`Edit failed: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleRegenerate = async (stage: string) => {
    if (!selectedProjectId) return;
    try {
      setActionLoading(true);
      const res = await api.regenerateProjectStage(selectedProjectId, stage, reviewerName);
      setMessage(res.message);
      await selectProject(selectedProjectId);
    } catch (err: any) {
      setMessage(`Regenerate failed: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleSendBack = async (targetStage: string) => {
    if (!selectedProjectId) return;
    try {
      setActionLoading(true);
      await api.sendBackProject(selectedProjectId, targetStage, 'Sent back from Review Studio', reviewerName);
      setMessage(`Project sent back to ${targetStage}.`);
      await loadPending();
    } catch (err: any) {
      setMessage(`Send back failed: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleSchedule = async () => {
    if (!selectedProjectId || !scheduleTime) return;
    try {
      setActionLoading(true);
      await api.scheduleProject(selectedProjectId, scheduleTime, 'private', reviewerName);
      setShowScheduleModal(false);
      setMessage('Project successfully scheduled for release.');
      await loadPending();
    } catch (err: any) {
      setMessage(`Scheduling failed: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Editorial Review Studio</h1>
          <p className="page-description">
            Mandatory human sign-off portal. Inspect video, metadata, QC signals, and copyright provenance.
          </p>
        </div>

        {bundle && (
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
            <button className="btn btn-success" onClick={handleApprove} disabled={actionLoading}>
              <Check size={16} /> APPROVE
            </button>
            <button className="btn btn-danger" onClick={() => setShowRejectModal(true)} disabled={actionLoading}>
              <X size={16} /> REJECT
            </button>
            <button className="btn btn-secondary" onClick={() => setShowEditModal(true)} disabled={actionLoading}>
              <Edit size={16} /> EDIT
            </button>
            <button className="btn btn-secondary" onClick={() => handleRegenerate('visual')} disabled={actionLoading}>
              <RotateCcw size={16} /> REGENERATE
            </button>
            <button className="btn btn-secondary" onClick={() => handleSendBack('SCRIPT_READY')} disabled={actionLoading}>
              <CornerUpLeft size={16} /> SEND BACK
            </button>
            <button className="btn btn-secondary" onClick={() => setShowScheduleModal(true)} disabled={actionLoading}>
              <Calendar size={16} /> SCHEDULE
            </button>
          </div>
        )}
      </div>

      {message && (
        <div className="badge badge-info" style={{ marginBottom: '1.25rem', padding: '8px 12px' }}>
          {message}
        </div>
      )}

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Loading review queue...</p>
      ) : pendingList.length === 0 ? (
        <EmptyState
          title="No pending approvals."
          message="All videos in the queue have been reviewed. When autonomous pipelines reach Stage 16, they will appear here for editorial review."
        />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 3fr', gap: '1.5rem' }}>
          {/* Pending items sidebar */}
          <div className="glass-panel" style={{ padding: '1rem', maxHeight: '75vh', overflowY: 'auto' }}>
            <h3 style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '0.75rem', textTransform: 'uppercase' }}>
              Pending Approvals ({pendingList.length})
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              {pendingList.map((item) => {
                const isSelected = selectedProjectId === item.projectId;
                return (
                  <div
                    key={item.id}
                    onClick={() => selectProject(item.projectId)}
                    style={{
                      padding: '0.85rem',
                      borderRadius: '8px',
                      background: isSelected ? 'rgba(59, 130, 246, 0.15)' : 'var(--bg-surface-elevated)',
                      border: `1px solid ${isSelected ? '#3b82f6' : 'var(--border-subtle)'}`,
                      cursor: 'pointer',
                    }}
                  >
                    <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>{item.project?.title}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                      Requested: {new Date(item.createdAt).toLocaleDateString()} • v{item.approvalVersion}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Complete 11-Element Inspection Bundle */}
          {bundle && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              {/* 1. Video Player & Thumbnail */}
              <div className="glass-panel" style={{ padding: '1.5rem' }}>
                <h3 style={{ fontSize: '1.1rem', fontWeight: 700, marginBottom: '1rem' }}>
                  1. Video Master & Thumbnail Preview
                </h3>
                <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: '1rem' }}>
                  <VideoPlayer filePath={bundle.video.masterPath} thumbnailPath={bundle.thumbnail.assetPath} />
                  <div style={{ background: '#090c14', borderRadius: '10px', padding: '1rem', border: '1px solid var(--border-subtle)' }}>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', fontWeight: 700, marginBottom: '6px' }}>
                      THUMBNAIL VARIANT
                    </div>
                    {bundle.thumbnail.assetPath ? (
                      <img
                        src={api.getMediaUrl(bundle.thumbnail.assetPath)}
                        alt="Thumbnail"
                        style={{ width: '100%', borderRadius: '6px', border: '1px solid var(--border-subtle)', marginBottom: '8px' }}
                      />
                    ) : (
                      <div style={{ height: '100px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>
                        No thumbnail generated
                      </div>
                    )}
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                      <strong>Prompt:</strong> {bundle.thumbnail.prompt}
                    </div>
                  </div>
                </div>
              </div>

              {/* 2. Metadata (Title, Description, Tags, Chapters) */}
              <div className="glass-panel" style={{ padding: '1.5rem' }}>
                <h3 style={{ fontSize: '1.1rem', fontWeight: 700, marginBottom: '1rem' }}>
                  2. Title, Description, Tags & Chapters
                </h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                  <div className="glass-card" style={{ padding: '0.85rem' }}>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)', fontWeight: 700 }}>TITLE</div>
                    <div style={{ fontSize: '1.05rem', fontWeight: 700, marginTop: '2px' }}>{bundle.metadata.title}</div>
                  </div>

                  <div className="glass-card" style={{ padding: '0.85rem' }}>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)', fontWeight: 700 }}>DESCRIPTION</div>
                    <p style={{ fontSize: '0.85rem', color: 'var(--text-primary)', marginTop: '4px', whiteSpace: 'pre-line' }}>
                      {bundle.metadata.description}
                    </p>
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                    <div className="glass-card" style={{ padding: '0.85rem' }}>
                      <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)', fontWeight: 700, marginBottom: '4px' }}>TAGS</div>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                        {bundle.metadata.tags.map((t, i) => (
                          <span key={i} className="badge badge-info">{t}</span>
                        ))}
                      </div>
                    </div>

                    <div className="glass-card" style={{ padding: '0.85rem' }}>
                      <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)', fontWeight: 700, marginBottom: '4px' }}>CHAPTERS</div>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', fontSize: '0.78rem' }}>
                        {bundle.metadata.chapters.map((ch, i) => (
                          <div key={i}>
                            <strong>{ch.timestamp}</strong> - {ch.title}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* 3. QC & Rights Reports */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div className="glass-panel" style={{ padding: '1.5rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                    <h3 style={{ fontSize: '1.05rem', fontWeight: 700 }}>3. Quality Control (QC)</h3>
                    <span className="badge badge-success">Score: {bundle.qualityControl?.overallScore || 0}%</span>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                    {bundle.qualityControl?.findings?.map((f, i) => (
                      <div key={i} style={{ fontSize: '0.8rem', display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid var(--border-subtle)' }}>
                        <span>{f.rule}</span>
                        <span style={{ color: f.passed ? '#34d399' : '#f87171', fontWeight: 600 }}>
                          {f.passed ? 'PASS' : 'FAIL'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="glass-panel" style={{ padding: '1.5rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                    <h3 style={{ fontSize: '1.05rem', fontWeight: 700 }}>4. Rights & Provenance</h3>
                    <span className="badge badge-success">{bundle.rightsAndProvenance?.status || 'PASS'}</span>
                  </div>
                  <div style={{ fontSize: '0.825rem', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                    <div>Claims Verified: <strong>{bundle.rightsAndProvenance?.factualClaimsChecked}</strong></div>
                    <div>Unsupported Claims: <strong>{bundle.rightsAndProvenance?.unsupportedClaimsCount}</strong></div>
                    <div>Copyright Risk: <strong>{bundle.rightsAndProvenance?.copyrightRiskScore}</strong></div>
                    <div style={{ marginTop: '4px', color: 'var(--text-secondary)', fontStyle: 'italic' }}>
                      {bundle.rightsAndProvenance?.disclaimerNotes}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Reject Modal */}
      {showRejectModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }}>
          <div className="glass-panel" style={{ width: '420px', padding: '1.75rem', background: 'var(--bg-surface)' }}>
            <h3 style={{ fontSize: '1.1rem', fontWeight: 800, marginBottom: '1rem' }}>Reject Project</h3>
            <textarea
              className="textarea"
              style={{ minHeight: '100px', marginBottom: '1rem' }}
              placeholder="State clear rejection reason for audit log..."
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              required
            />
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
              <button className="btn btn-secondary" onClick={() => setShowRejectModal(false)}>Cancel</button>
              <button className="btn btn-danger" onClick={handleReject} disabled={!rejectReason}>Confirm Rejection</button>
            </div>
          </div>
        </div>
      )}

      {/* Schedule Modal */}
      {showScheduleModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }}>
          <div className="glass-panel" style={{ width: '420px', padding: '1.75rem', background: 'var(--bg-surface)' }}>
            <h3 style={{ fontSize: '1.1rem', fontWeight: 800, marginBottom: '1rem' }}>Schedule Publishing</h3>
            <input
              type="datetime-local"
              className="input"
              style={{ marginBottom: '1rem' }}
              value={scheduleTime}
              onChange={(e) => setScheduleTime(e.target.value)}
              required
            />
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
              <button className="btn btn-secondary" onClick={() => setShowScheduleModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleSchedule} disabled={!scheduleTime}>Confirm Schedule</button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {showEditModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }}>
          <div className="glass-panel" style={{ width: '500px', padding: '1.75rem', background: 'var(--bg-surface)' }}>
            <h3 style={{ fontSize: '1.1rem', fontWeight: 800, marginBottom: '1rem' }}>Edit Video Metadata</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginBottom: '1.25rem' }}>
              <div>
                <label style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Title</label>
                <input className="input" value={editTitle} onChange={(e) => setEditTitle(e.target.value)} />
              </div>
              <div>
                <label style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Description</label>
                <textarea className="textarea" style={{ minHeight: '120px' }} value={editDesc} onChange={(e) => setEditDesc(e.target.value)} />
              </div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
              <button className="btn btn-secondary" onClick={() => setShowEditModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleEdit}>Save Metadata</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
