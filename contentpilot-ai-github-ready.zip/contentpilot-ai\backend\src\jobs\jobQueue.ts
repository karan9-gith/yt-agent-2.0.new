import { prisma } from '../database/client.js';
import { CreateJobInput, JobProgressUpdate, JobStatus, JobStatusType } from './jobTypes.js';
import { logger } from '../utils/logger.js';
import { NotFoundError } from '../utils/errors.js';

export class PersistentJobQueue {
  /**
   * Create and enqueue a new durable job
   */
  async createJob(input: CreateJobInput): Promise<string> {
    const job = await prisma.job.create({
      data: {
        type: input.type,
        status: JobStatus.QUEUED,
        progress: 0,
        currentStage: 'enqueued',
        retryCount: 0,
        maxRetries: input.maxRetries ?? 3,
        payloadJson: JSON.stringify(input.payload ?? {}),
        scheduledAt: input.scheduledAt ?? new Date(),
      },
    });

    await this.recordEvent(
      job.id,
      'job_created',
      'enqueued',
      0,
      `Job created and scheduled for ${job.scheduledAt.toISOString()}`
    );

    logger.info({ msg: 'Persistent job enqueued', jobId: job.id, type: job.type });
    return job.id;
  }

  /**
   * Fetch a job by ID
   */
  async getJob(jobId: string) {
    const job = await prisma.job.findUnique({
      where: { id: jobId },
      include: {
        events: {
          orderBy: { createdAt: 'desc' },
          take: 50,
        },
      },
    });

    if (!job) {
      throw new NotFoundError('Job', jobId);
    }
    return job;
  }

  /**
   * List jobs with optional status filter
   */
  async listJobs(options?: { status?: JobStatusType; limit?: number; offset?: number }) {
    return prisma.job.findMany({
      where: options?.status ? { status: options.status } : undefined,
      orderBy: { createdAt: 'desc' },
      take: options?.limit ?? 20,
      skip: options?.offset ?? 0,
      include: {
        events: {
          orderBy: { createdAt: 'desc' },
          take: 5,
        },
      },
    });
  }

  /**
   * Atomically acquire next available job for processing
   */
  async acquireNextJob(workerId: string) {
    const now = new Date();

    // Find candidate job
    const candidate = await prisma.job.findFirst({
      where: {
        status: { in: [JobStatus.QUEUED, JobStatus.RETRYING] },
        scheduledAt: { lte: now },
      },
      orderBy: { scheduledAt: 'asc' },
    });

    if (!candidate) return null;

    // Optimistically lock candidate
    const updated = await prisma.job.updateMany({
      where: {
        id: candidate.id,
        status: candidate.status,
      },
      data: {
        status: JobStatus.RUNNING,
        lockedBy: workerId,
        startedAt: candidate.startedAt ?? now,
        lastHeartbeatAt: now,
      },
    });

    if (updated.count === 0) {
      return null; // Another worker claimed it
    }

    await this.recordEvent(
      candidate.id,
      'status_change',
      candidate.currentStage,
      candidate.progress,
      `Claimed and started by worker ${workerId}`
    );

    return this.getJob(candidate.id);
  }

  /**
   * Update heartbeat timestamp
   */
  async updateHeartbeat(jobId: string): Promise<void> {
    await prisma.job.update({
      where: { id: jobId },
      data: { lastHeartbeatAt: new Date() },
    });
  }

  /**
   * Update job progress and stage
   */
  async updateProgress(jobId: string, update: JobProgressUpdate): Promise<void> {
    await prisma.job.update({
      where: { id: jobId },
      data: {
        progress: Math.min(100, Math.max(0, update.progress)),
        currentStage: update.stage,
        lastHeartbeatAt: new Date(),
      },
    });

    await this.recordEvent(
      jobId,
      'progress',
      update.stage,
      update.progress,
      update.message ?? `Progress updated to ${update.progress}% in stage '${update.stage}'`,
      update.data
    );
  }

  /**
   * Mark job as waiting for human approval
   */
  async setWaitingApproval(jobId: string, stage: string, message: string): Promise<void> {
    await prisma.job.update({
      where: { id: jobId },
      data: {
        status: JobStatus.WAITING_APPROVAL,
        currentStage: stage,
        lastHeartbeatAt: new Date(),
      },
    });

    await this.recordEvent(jobId, 'status_change', stage, 90, message);
    logger.info({ msg: 'Job waiting for human approval', jobId, stage });
  }

  /**
   * Complete job successfully
   */
  async completeJob(jobId: string, result?: Record<string, unknown>): Promise<void> {
    const now = new Date();
    await prisma.job.update({
      where: { id: jobId },
      data: {
        status: JobStatus.COMPLETED,
        progress: 100,
        resultJson: result ? JSON.stringify(result) : null,
        completedAt: now,
        lastHeartbeatAt: now,
      },
    });

    await this.recordEvent(jobId, 'completed', 'completed', 100, 'Job completed successfully');
    logger.info({ msg: 'Job completed successfully', jobId });
  }

  /**
   * Handle failure or schedule exponential backoff retry
   */
  async failOrRetryJob(jobId: string, error: Error | string): Promise<void> {
    const job = await prisma.job.findUnique({ where: { id: jobId } });
    if (!job) return;

    const errorMessage = typeof error === 'string' ? error : error.message;
    const nextRetry = job.retryCount + 1;

    if (nextRetry <= job.maxRetries) {
      // Exponential backoff: 2^(retryCount) * 5 seconds (5s, 10s, 20s...)
      const delayMs = Math.pow(2, job.retryCount) * 5000;
      const scheduledAt = new Date(Date.now() + delayMs);

      await prisma.job.update({
        where: { id: jobId },
        data: {
          status: JobStatus.RETRYING,
          retryCount: nextRetry,
          error: errorMessage,
          scheduledAt,
          lockedBy: null,
          lastHeartbeatAt: new Date(),
        },
      });

      await this.recordEvent(
        jobId,
        'retry_scheduled',
        job.currentStage,
        job.progress,
        `Attempt ${nextRetry}/${job.maxRetries} failed. Retrying in ${delayMs / 1000}s. Error: ${errorMessage}`
      );

      logger.warn({
        msg: 'Job scheduled for retry',
        jobId,
        attempt: nextRetry,
        delayMs,
        error: errorMessage,
      });
    } else {
      await prisma.job.update({
        where: { id: jobId },
        data: {
          status: JobStatus.FAILED,
          error: errorMessage,
          completedAt: new Date(),
          lockedBy: null,
          lastHeartbeatAt: new Date(),
        },
      });

      await this.recordEvent(
        jobId,
        'failed',
        job.currentStage,
        job.progress,
        `Job exhausted max retries (${job.maxRetries}). Final error: ${errorMessage}`
      );

      logger.error({ msg: 'Job permanently failed', jobId, error: errorMessage });
    }
  }

  /**
   * Safely cancel a running or queued job
   */
  async cancelJob(jobId: string, reason = 'Cancelled by user request'): Promise<void> {
    await prisma.job.update({
      where: { id: jobId },
      data: {
        status: JobStatus.CANCELLED,
        error: reason,
        completedAt: new Date(),
        lockedBy: null,
      },
    });

    await this.recordEvent(jobId, 'cancelled', 'cancelled', 0, reason);
    logger.info({ msg: 'Job cancelled', jobId, reason });
  }

  /**
   * Crash recovery: Recover orphaned jobs whose workers died
   */
  async recoverOrphanedJobs(): Promise<number> {
    const twoMinutesAgo = new Date(Date.now() - 2 * 60 * 1000);

    const orphaned = await prisma.job.findMany({
      where: {
        status: JobStatus.RUNNING,
        lastHeartbeatAt: { lt: twoMinutesAgo },
      },
    });

    for (const job of orphaned) {
      logger.warn({ msg: 'Recovering orphaned job from application crash', jobId: job.id });
      await this.failOrRetryJob(job.id, 'Process crashed or worker heartbeat timed out');
    }

    return orphaned.length;
  }

  /**
   * Helper to append an immutable event log to the job
   */
  async recordEvent(
    jobId: string,
    eventType: string,
    stage: string,
    progress: number,
    message: string,
    data?: Record<string, unknown>
  ): Promise<void> {
    await prisma.jobEvent.create({
      data: {
        jobId,
        eventType,
        stage,
        progress,
        message,
        dataJson: data ? JSON.stringify(data) : null,
      },
    });
  }
}

export const persistentJobQueue = new PersistentJobQueue();
export const jobQueue = persistentJobQueue;
