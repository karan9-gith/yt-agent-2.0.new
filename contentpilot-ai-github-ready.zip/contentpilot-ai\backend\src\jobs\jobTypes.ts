export const JobStatus = {
  QUEUED: 'QUEUED',
  RUNNING: 'RUNNING',
  RETRYING: 'RETRYING',
  WAITING_APPROVAL: 'WAITING_APPROVAL',
  COMPLETED: 'COMPLETED',
  FAILED: 'FAILED',
  CANCELLED: 'CANCELLED',
} as const;

export type JobStatusType = typeof JobStatus[keyof typeof JobStatus];

export const JobType = {
  CONTENT_PIPELINE: 'CONTENT_PIPELINE',
  RESEARCH: 'RESEARCH',
  STRATEGY: 'STRATEGY',
  SCRIPT: 'SCRIPT',
  SEO: 'SEO',
  THUMBNAILS: 'THUMBNAILS',
  NARRATION: 'NARRATION',
  VISUAL_ASSETS: 'VISUAL_ASSETS',
  VIDEO_RENDER: 'VIDEO_RENDER',
  QUALITY_GATE: 'QUALITY_GATE',
} as const;

export type JobTypeType = typeof JobType[keyof typeof JobType];

export interface CreateJobInput {
  type: JobTypeType | string;
  payload: Record<string, unknown>;
  maxRetries?: number;
  scheduledAt?: Date;
}

export interface JobProgressUpdate {
  progress: number;
  stage: string;
  message?: string;
  data?: Record<string, unknown>;
}

export interface JobHandlerContext {
  jobId: string;
  reportProgress: (update: JobProgressUpdate) => Promise<void>;
  isCancelled: () => Promise<boolean>;
  recordEvent: (eventType: string, stage: string, message: string, data?: Record<string, unknown>) => Promise<void>;
}

export type JobHandler = (
  payload: Record<string, unknown>,
  context: JobHandlerContext
) => Promise<Record<string, unknown> | void>;
