import { prisma } from '../../database/client.js';
import { logger } from '../../utils/logger.js';
import {
  ErrorClassification,
  AutoFixResult,
  DiagnosedError,
  AutoFixAttempt,
} from './types.js';

export class AutoFixEngine {
  /**
   * Classify any runtime error into standard operational taxonomy
   */
  public classifyError(error: unknown): DiagnosedError {
    const message = error instanceof Error ? error.message : String(error);
    const lower = message.toLowerCase();

    // 1. Quota errors (YouTube API, Gemini quota, LLM rate limits)
    if (
      lower.includes('quota') ||
      lower.includes('resource_exhausted') ||
      lower.includes('rate limit') ||
      lower.includes('429') ||
      lower.includes('quotaexceeded')
    ) {
      return {
        classification: 'QUOTA',
        diagnosis: `Service quota or rate limit exceeded: ${message}`,
        isRecoverable: true,
        recommendedAction: 'PAUSE_AND_BACKOFF',
        suggestedFix: 'Schedule backoff retry after cool-down window without consuming rapid retry attempts',
        retryDelayMs: 60000, // 1 minute pause
      };
    }

    // 2. Authentication & OAuth errors
    if (
      lower.includes('unauthorized') ||
      lower.includes('invalid_grant') ||
      lower.includes('token expired') ||
      lower.includes('token has been expired or revoked') ||
      lower.includes('401') ||
      lower.includes('oauth')
    ) {
      return {
        classification: 'AUTHENTICATION',
        diagnosis: `Authentication credential expired or invalid: ${message}`,
        isRecoverable: true,
        recommendedAction: 'REFRESH_OR_REAUTH',
        suggestedFix: 'Attempt token refresh; if refresh token is missing or revoked, request user re-authentication and halt retry loop',
      };
    }

    // 3. Configuration & Missing Environment variables
    if (
      lower.includes('missing environment variable') ||
      lower.includes('is not set') ||
      lower.includes('config error') ||
      lower.includes('client_id is required')
    ) {
      const match = message.match(/([A-Z0-9_]{3,})\b/);
      const varName = match ? match[1] : 'UNKNOWN_ENV_VAR';
      return {
        classification: 'CONFIGURATION',
        diagnosis: `Required configuration or environment variable is missing: ${varName}`,
        isRecoverable: false, // Never invent secrets or configs automatically!
        recommendedAction: 'HALT_WITH_DIAGNOSTIC',
        suggestedFix: `Configure required variable '${varName}' in .env file. System will never fabricate credentials.`,
      };
    }

    // 4. Validation & Schema errors (including invalid JSON from LLM)
    if (
      lower.includes('json') ||
      lower.includes('unexpected token') ||
      lower.includes('syntaxerror: unexpected') ||
      lower.includes('zod') ||
      lower.includes('validation error') ||
      lower.includes('failed to parse')
    ) {
      return {
        classification: 'VALIDATION',
        diagnosis: `Schema or JSON validation failure: ${message}`,
        isRecoverable: true,
        recommendedAction: 'REPAIR_JSON_AND_RETRY',
        suggestedFix: 'Run deterministic JSON repair (strip codeblocks, balance braces, unescape characters) and re-validate',
      };
    }

    // 5. Media errors (FFmpeg, FFprobe, audio, video decoding)
    if (
      lower.includes('ffmpeg') ||
      lower.includes('ffprobe') ||
      lower.includes('codec') ||
      lower.includes('dimension') ||
      lower.includes('moov atom not found') ||
      lower.includes('missing narration') ||
      lower.includes('audio track') ||
      lower.includes('video stream')
    ) {
      return {
        classification: 'MEDIA',
        diagnosis: `Media processing or encoding failure: ${message}`,
        isRecoverable: true,
        recommendedAction: 'APPLY_FALLBACK_RENDER_PARAMS',
        suggestedFix: 'Inspect dimensions, pad to even multiples of 2, force yuv420p pixel format, or regenerate missing audio segment',
      };
    }

    // 6. Network & Transient errors
    if (
      lower.includes('econnreset') ||
      lower.includes('etimedout') ||
      lower.includes('econnrefused') ||
      lower.includes('socket hang up') ||
      lower.includes('fetch failed') ||
      lower.includes('network')
    ) {
      return {
        classification: 'NETWORK',
        diagnosis: `Network connectivity or socket timeout: ${message}`,
        isRecoverable: true,
        recommendedAction: 'EXPONENTIAL_BACKOFF',
        suggestedFix: 'Perform jittered exponential backoff retry up to configured attempt limit',
        retryDelayMs: 5000,
      };
    }

    // 7. Database errors (SQLite locked, busy, connection dropped)
    if (
      lower.includes('sqlite_busy') ||
      lower.includes('database is locked') ||
      lower.includes('prisma') ||
      lower.includes('unique constraint')
    ) {
      return {
        classification: 'DATABASE',
        diagnosis: `Database concurrency contention or transient lock: ${message}`,
        isRecoverable: true,
        recommendedAction: 'RETRY_TRANSACTION',
        suggestedFix: 'Back off and retry SQLite operation after short wait',
        retryDelayMs: 500,
      };
    }

    // 8. General transient errors
    if (
      lower.includes('timeout') ||
      lower.includes('503') ||
      lower.includes('504') ||
      lower.includes('service unavailable')
    ) {
      return {
        classification: 'TRANSIENT',
        diagnosis: `Temporary upstream service unavailability: ${message}`,
        isRecoverable: true,
        recommendedAction: 'RETRY_WITH_BACKOFF',
        suggestedFix: 'Wait for upstream service recovery and retry',
        retryDelayMs: 3000,
      };
    }

    // 9. Unknown
    return {
      classification: 'UNKNOWN',
      diagnosis: `Unclassified system error: ${message}`,
      isRecoverable: false,
      recommendedAction: 'LOG_AND_ESCALATE',
      suggestedFix: 'Escalate to human review or system administrator',
    };
  }

  /**
   * Deterministic JSON Repair: Cleans common LLM formatting quirks
   * - Strips markdown wrappers (```json ... ```)
   * - Strips trailing commas
   * - Balances brackets and curly braces
   * - Normalizes smart quotes
   */
  public repairJsonString(raw: string): string {
    let cleaned = raw.trim();

    // Strip markdown code fences
    if (cleaned.startsWith('```json')) {
      cleaned = cleaned.replace(/^```json\s*/i, '').replace(/\s*```$/, '');
    } else if (cleaned.startsWith('```')) {
      cleaned = cleaned.replace(/^```\s*/, '').replace(/\s*```$/, '');
    }

    // Normalize unicode smart quotes
    cleaned = cleaned
      .replace(/[\u201C\u201D]/g, '"')
      .replace(/[\u2018\u2019]/g, "'");

    // Remove trailing commas before closing braces/brackets
    cleaned = cleaned.replace(/,\s*([}\]])/g, '$1');

    // Attempt direct parse
    try {
      JSON.parse(cleaned);
      return cleaned;
    } catch {
      // Continue to bracket balancing
    }

    // Find first '{' or '['
    const firstBrace = cleaned.indexOf('{');
    const firstBracket = cleaned.indexOf('[');
    let startIdx = 0;
    if (firstBrace !== -1 && (firstBracket === -1 || firstBrace < firstBracket)) {
      startIdx = firstBrace;
    } else if (firstBracket !== -1) {
      startIdx = firstBracket;
    }

    cleaned = cleaned.substring(startIdx);

    // Use LIFO stack to balance unclosed brackets and braces in proper nesting order
    const stack: string[] = [];
    let inString = false;
    let escapeNext = false;

    for (let i = 0; i < cleaned.length; i++) {
      const char = cleaned[i];
      if (escapeNext) {
        escapeNext = false;
        continue;
      }
      if (char === '\\') {
        escapeNext = true;
        continue;
      }
      if (char === '"') {
        inString = !inString;
        continue;
      }
      if (!inString) {
        if (char === '{') stack.push('}');
        else if (char === '[') stack.push(']');
        else if (char === '}' || char === ']') {
          if (stack.length > 0 && stack[stack.length - 1] === char) {
            stack.pop();
          }
        }
      }
    }

    // Close in exact LIFO order
    while (stack.length > 0) {
      cleaned += stack.pop();
    }

    return cleaned;
  }

  /**
   * Safe FFmpeg dimension calculation: Ensures width and height are even integers
   */
  public getSafeDimensions(width: number, height: number): { width: number; height: number; filterString: string } {
    const safeW = width % 2 === 0 ? width : width + 1;
    const safeH = height % 2 === 0 ? height : height + 1;
    // FFmpeg pad filter to guarantee even dimensions for H.264
    const filterString = `pad=ceil(iw/2)*2:ceil(ih/2)*2`;
    return { width: safeW, height: safeH, filterString };
  }

  /**
   * Log an auto-fix attempt and result in the database
   */
  public async recordAutoFix(attempt: AutoFixAttempt): Promise<void> {
    try {
      await prisma.autoFixLog.create({
        data: {
          jobId: attempt.jobId,
          projectId: attempt.projectId,
          error: attempt.error.slice(0, 500),
          classification: attempt.classification,
          diagnosis: attempt.diagnosis.slice(0, 500),
          fixApplied: attempt.fixApplied.slice(0, 500),
          result: attempt.result,
          retryCount: attempt.retryCount,
          metaJson: attempt.meta ? JSON.stringify(attempt.meta) : null,
          timestamp: new Date(),
        },
      });

      logger.info({
        msg: 'Auto-Fix action recorded',
        classification: attempt.classification,
        result: attempt.result,
        fix: attempt.fixApplied,
      });
    } catch (err) {
      logger.error({ msg: 'Failed to record auto-fix log', error: err });
    }
  }
}

export const autoFixEngine = new AutoFixEngine();
