import React from 'react';
import { Lock, ShieldCheck, Activity, RefreshCw } from 'lucide-react';
import { Channel } from '../types';

interface HeaderProps {
  channels: Channel[];
  selectedChannelId: string;
  onSelectChannel: (id: string) => void;
  onRefresh: () => void;
  isRefreshing?: boolean;
  isBackendConnected?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  channels,
  selectedChannelId,
  onSelectChannel,
  onRefresh,
  isRefreshing,
  isBackendConnected = false,
}) => {
  return (
    <header
      style={{
        height: 'var(--header-height)',
        borderBottom: '1px solid var(--border-subtle)',
        background: 'rgba(7, 9, 14, 0.85)',
        backdropFilter: 'blur(12px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 1.5rem',
        position: 'sticky',
        top: 0,
        zIndex: 40,
      }}
    >
      {/* Channel Switcher */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
        <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>
          Channel:
        </span>
        <select
          className="select"
          style={{ width: 'auto', minWidth: '180px', padding: '6px 12px', fontSize: '0.85rem' }}
          value={selectedChannelId}
          onChange={(e) => onSelectChannel(e.target.value)}
        >
          {channels.length === 0 ? (
            <option value="">No channels</option>
          ) : (
            channels.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.niche})
              </option>
            ))
          )}
        </select>
      </div>

      {/* Governance & Status Badges */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
        <button
          className="btn btn-secondary"
          style={{ padding: '6px 10px', fontSize: '0.8rem' }}
          onClick={onRefresh}
          disabled={isRefreshing}
          title="Refresh current view"
        >
          <RefreshCw size={14} className={isRefreshing ? 'spin' : ''} />
          <span>Refresh</span>
        </button>

        <span
          className="badge badge-success"
          title="Auto-publish is disabled by default for verified human-approved content"
          style={{ background: 'rgba(16, 185, 129, 0.2)', color: '#34d399', border: '1px solid rgba(16, 185, 129, 0.4)' }}
        >
          <Activity size={12} />
          AUTO-PUBLISH: OFF
        </span>

        <span
          className="badge badge-info"
          title="Mandatory human editorial sign-off strictly required before any upload"
          style={{ background: 'rgba(59, 130, 246, 0.2)', color: '#60a5fa', border: '1px solid rgba(59, 130, 246, 0.4)' }}
        >
          <ShieldCheck size={12} />
          HUMAN APPROVAL: REQUIRED
        </span>

        <span
          className="badge"
          title="Default YouTube upload visibility"
          style={{ background: 'rgba(139, 92, 246, 0.2)', color: '#c084fc', border: '1px solid rgba(139, 92, 246, 0.4)', fontSize: '0.72rem', display: 'flex', alignItems: 'center', gap: '4px' }}
        >
          <Lock size={12} />
          PRIVACY: PUBLIC
        </span>

        {/* Backend Connectivity / Demo Mode Indicator */}
        {!isBackendConnected ? (
          <span
            className="badge"
            title="Backend is not connected. Operating in zero-config Demo / Local Mode with deterministic sample data."
            style={{
              background: 'rgba(234, 179, 8, 0.15)',
              color: '#facc15',
              border: '1px solid rgba(234, 179, 8, 0.4)',
              fontSize: '0.74rem',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '5px 10px',
            }}
          >
            <span
              style={{
                width: '6px',
                height: '6px',
                borderRadius: '50%',
                background: '#facc15',
                boxShadow: '0 0 6px #facc15',
              }}
            />
            Backend not connected — Demo Mode
          </span>
        ) : (
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              fontSize: '0.75rem',
              color: 'var(--accent-emerald)',
              background: 'rgba(16, 185, 129, 0.1)',
              padding: '4px 10px',
              borderRadius: '9999px',
              border: '1px solid rgba(16, 185, 129, 0.25)',
            }}
          >
            <span
              style={{
                width: '6px',
                height: '6px',
                borderRadius: '50%',
                background: '#10b981',
                boxShadow: '0 0 8px #10b981',
              }}
            />
            BACKEND CONNECTED
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
