import { describe, it, expect, beforeEach } from 'vitest';
import { prisma } from '../../src/database/client.js';
import { persistentScheduler } from '../../src/services/scheduler/schedulerEngine.js';

describe('Persistent Scheduler Engine', () => {
  let channelId: string;

  beforeEach(async () => {
    const user = await prisma.user.upsert({
      where: { email: 'scheduler_test@contentpilot.ai' },
      update: {},
      create: { email: 'scheduler_test@contentpilot.ai', name: 'Scheduler User' },
    });

    const channel = await prisma.channel.create({
      data: {
        userId: user.id,
        name: 'Scheduler Channel',
        niche: 'AI Tech',
        targetAudience: 'Devs',
        brandVoice: 'Clear',
        visualStyle: 'Dark',
      },
    });
    channelId = channel.id;
  });

  describe('Schedule Recurrence Calculations', () => {
    it('should calculate custom_interval future date correctly', () => {
      const now = Date.now();
      const next = persistentScheduler.calculateNextRun('custom_interval', 30000);
      expect(next.getTime()).toBeGreaterThanOrEqual(now + 29000);
      expect(next.getTime()).toBeLessThanOrEqual(now + 31000);
    });

    it('should calculate daily recurrence future date in UTC', () => {
      const next = persistentScheduler.calculateNextRun('daily', undefined, '15:00');
      expect(next.getUTCHours()).toBe(15);
      expect(next.getUTCMinutes()).toBe(0);
      expect(next.getTime()).toBeGreaterThan(Date.now());
    });

    it('should calculate weekly recurrence future date', () => {
      const next = persistentScheduler.calculateNextRun('weekly', undefined, '14:00');
      expect(next.getTime()).toBeGreaterThan(Date.now());
      expect(next.getUTCHours()).toBe(14);
    });
  });

  describe('Task Persistence and Tick Execution', () => {
    it('should persist scheduled task and execute on tick', async () => {
      const pastDate = new Date(Date.now() - 5000);

      const taskId = await persistentScheduler.createTask({
        channelId,
        name: 'Research Runner',
        taskType: 'approval_reminders',
        scheduleType: 'one_time',
        nextRunAt: pastDate,
      });

      const taskBefore = await prisma.scheduledTask.findUnique({ where: { id: taskId } });
      expect(taskBefore?.status).toBe('ACTIVE');

      // Tick should execute due task
      const processed = await persistentScheduler.tick();
      expect(processed).toBeGreaterThanOrEqual(1);

      const taskAfter = await prisma.scheduledTask.findUnique({ where: { id: taskId } });
      expect(taskAfter?.status).toBe('COMPLETED');
      expect(taskAfter?.runCount).toBe(1);
      expect(taskAfter?.lastRunAt).not.toBeNull();
    });

    it('should update recurring task nextRunAt on tick without completing', async () => {
      const pastDate = new Date(Date.now() - 5000);

      const taskId = await persistentScheduler.createTask({
        channelId,
        name: 'Recurring Reminder',
        taskType: 'approval_reminders',
        scheduleType: 'custom_interval',
        intervalMs: 60000,
        nextRunAt: pastDate,
      });

      await persistentScheduler.tick();

      const taskAfter = await prisma.scheduledTask.findUnique({ where: { id: taskId } });
      expect(taskAfter?.status).toBe('ACTIVE'); // Stays active
      expect(taskAfter?.runCount).toBe(1);
      expect(taskAfter?.nextRunAt?.getTime()).toBeGreaterThan(Date.now());
    });
  });

  describe('Restart Recovery & Governance', () => {
    it('should survive restarts and re-initialize tasks', async () => {
      // Create task with null nextRunAt to simulate recovery
      const task = await prisma.scheduledTask.create({
        data: {
          channelId,
          name: 'Recovered Task',
          taskType: 'analytics',
          scheduleType: 'daily',
          preferredTime: '12:00',
          status: 'ACTIVE',
        },
      });

      // Start triggers recovery sweep
      await persistentScheduler.start();
      await persistentScheduler.stop();

      const fresh = await prisma.scheduledTask.findUnique({ where: { id: task.id } });
      expect(fresh?.nextRunAt).not.toBeNull();
    });

    it('should strictly SKIP unapproved content in scheduled publishing queue', async () => {
      const project = await prisma.videoProject.create({
        data: {
          channelId,
          title: 'Unapproved Scheduled Video',
          status: 'AWAITING_APPROVAL',
        },
      });

      // Publishing queue item due right now
      await prisma.publishingQueue.create({
        data: {
          projectId: project.id,
          channelId,
          scheduledPublishTime: new Date(Date.now() - 1000),
          privacyStatus: 'private',
          status: 'QUEUED',
          idempotencyKey: `sched_test_${Date.now()}`,
        },
      });

      // Execute queue processing
      const publishedCount = await persistentScheduler.processScheduledPublishingQueue(new Date());
      expect(publishedCount).toBe(0);

      // Status should remain QUEUED and not published
      const queueItem = await prisma.publishingQueue.findUnique({ where: { projectId: project.id } });
      expect(queueItem?.status).toBe('QUEUED');
    });
  });
});
