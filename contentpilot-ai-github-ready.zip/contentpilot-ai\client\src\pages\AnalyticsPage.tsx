import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { EmptyState } from '../components/EmptyState';
import { BarChart3, RefreshCw, Eye, Clock, ThumbsUp, MessageSquare, TrendingUp } from 'lucide-react';

interface AnalyticsPageProps {
  channelId: string;
  onNavigate: (page: any) => void;
}

export const AnalyticsPage: React.FC<AnalyticsPageProps> = ({ channelId, onNavigate }) => {
  const [snapshots, setSnapshots] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    loadAnalytics();
  }, [channelId]);

  const loadAnalytics = async () => {
    try {
      setLoading(true);
      const data = await api.getAnalyticsOverview(channelId);
      setSnapshots(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSync = async () => {
    try {
      setSyncing(true);
      setMessage(null);
      const res = await api.syncAnalytics(channelId);
      setMessage(`Analytics synchronization completed. ${res.snapshotsCaptured} snapshots captured.`);
      await loadAnalytics();
    } catch (err: any) {
      setMessage(`Sync failed: ${err.message}`);
    } finally {
      setSyncing(false);
    }
  };

  const totalViews = snapshots.reduce((acc, s) => acc + s.views, 0);
  const totalWatchTime = snapshots.reduce((acc, s) => acc + s.watchTimeMinutes, 0);
  const totalLikes = snapshots.reduce((acc, s) => acc + s.likes, 0);
  const totalComments = snapshots.reduce((acc, s) => acc + s.comments, 0);

  return (
    <div style={{ padding: '2rem' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Channel Analytics & Telemetry</h1>
          <p className="page-description">
            Live metrics ingested directly from YouTube API without synthetic estimation or placeholder data.
          </p>
        </div>
        <button className="btn btn-secondary" onClick={handleSync} disabled={syncing}>
          <RefreshCw size={16} className={syncing ? 'spin' : ''} /> {syncing ? 'Syncing...' : 'Sync Live Telemetry'}
        </button>
      </div>

      {message && (
        <div className="badge badge-info" style={{ marginBottom: '1.25rem', padding: '8px 12px' }}>
          {message}
        </div>
      )}

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Loading analytics...</p>
      ) : snapshots.length === 0 ? (
        <EmptyState
          title="No analytics snapshots on record."
          message="Analytics data is captured once videos are published to YouTube. Click 'Sync Live Telemetry' to poll latest stats."
          actionText="Sync Now"
          onAction={handleSync}
        />
      ) : (
        <div>
          {/* Lifetime Aggregate KPIs */}
          <div className="stat-grid">
            <div className="stat-card">
              <div className="label">Total Views</div>
              <div className="value" style={{ color: '#34d399' }}>{totalViews.toLocaleString()}</div>
            </div>
            <div className="stat-card">
              <div className="label">Total Watch Time (Mins)</div>
              <div className="value">{Math.round(totalWatchTime).toLocaleString()}</div>
            </div>
            <div className="stat-card">
              <div className="label">Likes</div>
              <div className="value">{totalLikes.toLocaleString()}</div>
            </div>
            <div className="stat-card">
              <div className="label">Comments</div>
              <div className="value">{totalComments.toLocaleString()}</div>
            </div>
          </div>

          {/* Video Performance Table */}
          <div className="glass-panel" style={{ padding: '1.5rem', marginBottom: '2rem' }}>
            <h3 style={{ fontSize: '1.1rem', fontWeight: 700, marginBottom: '1rem' }}>
              Lifetime Video Performance Ranking
            </h3>
            <div className="table-container">
              <table className="table">
                <thead>
                  <tr>
                    <th>Title</th>
                    <th>Views</th>
                    <th>Avg View Duration</th>
                    <th>Likes</th>
                    <th>Comments</th>
                    <th>Captured At</th>
                  </tr>
                </thead>
                <tbody>
                  {snapshots.map((s) => (
                    <tr key={s.id}>
                      <td style={{ fontWeight: 600 }}>{s.youtubeVideo?.title || s.youtubeVideoId}</td>
                      <td style={{ fontWeight: 700, color: '#34d399' }}>{s.views.toLocaleString()}</td>
                      <td>{Math.round(s.averageViewDurationSec)}s</td>
                      <td>{s.likes.toLocaleString()}</td>
                      <td>{s.comments.toLocaleString()}</td>
                      <td style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                        {new Date(s.capturedAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
