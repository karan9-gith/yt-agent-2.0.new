import { Router, Request, Response, NextFunction } from 'express';
import { experimentService } from '../services/experiments/experimentService.js';

const router = Router();
const param = (p: string | string[]): string => (Array.isArray(p) ? p[0] : p);

// GET list experiments for channel
router.get('/channel/:channelId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const list = await experimentService.listExperiments(param(req.params.channelId));
    res.json({ success: true, count: list.length, data: list });
  } catch (err) {
    next(err);
  }
});

// POST create experiment
router.post('/', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { channelId, title, hypothesis, baseline, variant, metric, experimentType } = req.body;
    if (!channelId || !title || !hypothesis || !baseline || !variant || !experimentType) {
      res.status(400).json({ success: false, error: 'Missing required experiment parameters' });
      return;
    }
    const exp = await experimentService.createExperiment({
      channelId,
      title,
      hypothesis,
      baseline,
      variant,
      metric,
      experimentType,
    });
    res.json({ success: true, experiment: exp });
  } catch (err) {
    next(err);
  }
});

// POST conclude experiment
router.post('/:id/conclude', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { baselineMetricValue, variantMetricValue, sampleSizeA, sampleSizeB } = req.body;
    const concluded = await experimentService.concludeExperiment(param(req.params.id), {
      baselineMetricValue,
      variantMetricValue,
      sampleSizeA,
      sampleSizeB,
    });
    res.json({ success: true, experiment: concluded });
  } catch (err) {
    next(err);
  }
});

// POST human approve winner
router.post('/:id/approve', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { approvedBy } = req.body;
    if (!approvedBy) {
      res.status(400).json({ success: false, error: 'Field "approvedBy" is required' });
      return;
    }
    await experimentService.approveExperimentWinner(param(req.params.id), approvedBy);
    res.json({ success: true, message: 'Experiment winner approved by human' });
  } catch (err) {
    next(err);
  }
});

// POST apply approved winner to channel strategy
router.post('/:id/apply', async (req: Request, res: Response, next: NextFunction) => {
  try {
    await experimentService.applyExperimentWinner(param(req.params.id));
    res.json({ success: true, message: 'Experiment winner applied to channel configuration' });
  } catch (err) {
    next(err);
  }
});

export default router;
