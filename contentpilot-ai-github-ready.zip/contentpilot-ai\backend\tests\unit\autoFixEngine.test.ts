import { describe, it, expect, beforeEach } from 'vitest';
import { autoFixEngine } from '../../src/services/autofix/autoFixEngine.js';
import { prisma } from '../../src/database/client.js';

describe('Auto-Fix Engine', () => {
  beforeEach(async () => {
    // Clean up test auto-fix logs if needed
  });

  describe('Error Classification Taxonomy', () => {
    it('should classify quota errors correctly', () => {
      const quotaErr = new Error('YouTube quotaExceeded: The request cannot be completed because you have exceeded your quota.');
      const diagnosed = autoFixEngine.classifyError(quotaErr);
      expect(diagnosed.classification).toBe('QUOTA');
      expect(diagnosed.isRecoverable).toBe(true);
      expect(diagnosed.recommendedAction).toBe('PAUSE_AND_BACKOFF');
      expect(diagnosed.retryDelayMs).toBe(60000);
    });

    it('should classify authentication/oauth errors correctly', () => {
      const authErr = new Error('invalid_grant: Token has been expired or revoked');
      const diagnosed = autoFixEngine.classifyError(authErr);
      expect(diagnosed.classification).toBe('AUTHENTICATION');
      expect(diagnosed.isRecoverable).toBe(true);
      expect(diagnosed.recommendedAction).toBe('REFRESH_OR_REAUTH');
    });

    it('should classify missing configuration without inventing secrets', () => {
      const configErr = new Error('Missing environment variable: YOUTUBE_CLIENT_SECRET is not set');
      const diagnosed = autoFixEngine.classifyError(configErr);
      expect(diagnosed.classification).toBe('CONFIGURATION');
      expect(diagnosed.isRecoverable).toBe(false); // Guardrail: Never invent secrets!
      expect(diagnosed.diagnosis).toContain('YOUTUBE_CLIENT_SECRET');
    });

    it('should classify validation and schema errors', () => {
      const valErr = new Error('SyntaxError: Unexpected token in JSON at position 42');
      const diagnosed = autoFixEngine.classifyError(valErr);
      expect(diagnosed.classification).toBe('VALIDATION');
      expect(diagnosed.isRecoverable).toBe(true);
      expect(diagnosed.recommendedAction).toBe('REPAIR_JSON_AND_RETRY');
    });

    it('should classify FFmpeg and media errors', () => {
      const mediaErr = new Error('ffmpeg failed: height not divisible by 2');
      const diagnosed = autoFixEngine.classifyError(mediaErr);
      expect(diagnosed.classification).toBe('MEDIA');
      expect(diagnosed.isRecoverable).toBe(true);
    });

    it('should classify network and socket errors', () => {
      const netErr = new Error('connect ECONNRESET 142.250.190.46:443');
      const diagnosed = autoFixEngine.classifyError(netErr);
      expect(diagnosed.classification).toBe('NETWORK');
      expect(diagnosed.isRecoverable).toBe(true);
    });

    it('should classify database lock errors', () => {
      const dbErr = new Error('PrismaClientKnownRequestError: database is locked');
      const diagnosed = autoFixEngine.classifyError(dbErr);
      expect(diagnosed.classification).toBe('DATABASE');
      expect(diagnosed.isRecoverable).toBe(true);
    });
  });

  describe('Deterministic JSON Repair', () => {
    it('should strip markdown code fences', () => {
      const raw = '```json\n{"title": "Test Video", "score": 95}\n```';
      const repaired = autoFixEngine.repairJsonString(raw);
      expect(JSON.parse(repaired)).toEqual({ title: 'Test Video', score: 95 });
    });

    it('should normalize smart quotes and remove trailing commas', () => {
      const raw = '{\u201Ctitle\u201D: \u201CTest Video\u201D, \u201Cviews\u201D: 1000,}';
      const repaired = autoFixEngine.repairJsonString(raw);
      expect(JSON.parse(repaired)).toEqual({ title: 'Test Video', views: 1000 });
    });

    it('should balance unclosed brackets and braces', () => {
      const raw = '{"title": "Unclosed Object", "items": ["one", "two"';
      const repaired = autoFixEngine.repairJsonString(raw);
      const parsed = JSON.parse(repaired);
      expect(parsed.title).toBe('Unclosed Object');
      expect(parsed.items).toEqual(['one', 'two']);
    });
  });

  describe('Safe FFmpeg Dimensions', () => {
    it('should calculate even dimensions and valid pad filter', () => {
      const { width, height, filterString } = autoFixEngine.getSafeDimensions(1919, 1079);
      expect(width % 2).toBe(0);
      expect(height % 2).toBe(0);
      expect(width).toBe(1920);
      expect(height).toBe(1080);
      expect(filterString).toContain('pad=');
    });
  });

  describe('Auto-Fix Log Persistence', () => {
    it('should persist auto-fix attempt to database', async () => {
      await autoFixEngine.recordAutoFix({
        error: 'JSON parse error test',
        classification: 'VALIDATION',
        diagnosis: 'Malformed JSON from model',
        fixApplied: 'Repaired quotes and stripped fences',
        result: 'SUCCESS',
        retryCount: 1,
      });

      const log = await prisma.autoFixLog.findFirst({
        where: { classification: 'VALIDATION' },
        orderBy: { timestamp: 'desc' },
      });

      expect(log).not.toBeNull();
      expect(log?.result).toBe('SUCCESS');
      expect(log?.classification).toBe('VALIDATION');
    });
  });
});
