import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { EmptyState } from '../components/EmptyState';
import { Search, Sparkles, ExternalLink, Globe, BookOpen } from 'lucide-react';

interface ResearchPageProps {
  channelId: string;
  onNavigate: (page: any) => void;
}

export const ResearchPage: React.FC<ResearchPageProps> = ({ channelId, onNavigate }) => {
  const [runs, setRuns] = useState<any[]>([]);
  const [selectedRun, setSelectedRun] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadResearch();
  }, [channelId]);

  const loadResearch = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getResearchRuns(channelId);
      setRuns(data);
      if (data.length > 0) {
        setSelectedRun(data[0]);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleTrigger = async () => {
    try {
      setIsGenerating(true);
      setError(null);
      const res = await api.runResearch({ channelId });
      setRuns([res, ...runs]);
      setSelectedRun(res);
    } catch (err: any) {
      setError(err.message || 'Failed to trigger research');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Market & Topic Research</h1>
          <p className="page-description">
            Automated intelligence gathering, authority source verification, and audience intent discovery.
          </p>
        </div>
        <button className="btn btn-primary" onClick={handleTrigger} disabled={isGenerating}>
          <Sparkles size={16} /> {isGenerating ? 'Synthesizing...' : 'Run New Research'}
        </button>
      </div>

      {error && (
        <div className="badge badge-danger" style={{ marginBottom: '1.5rem', padding: '8px 12px' }}>
          {error}
        </div>
      )}

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Loading research runs...</p>
      ) : runs.length === 0 ? (
        <EmptyState
          title="No research runs found."
          message="Run a new research cycle to discover trending topics, competitive angles, and authoritative citations."
          actionText="Run Research Now"
          onAction={handleTrigger}
        />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '1.5rem' }}>
          {/* Runs Sidebar */}
          <div className="glass-panel" style={{ padding: '1rem', maxHeight: '75vh', overflowY: 'auto' }}>
            <h3 style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              Historical Research Runs ({runs.length})
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              {runs.map((r) => {
                const isSelected = selectedRun?.id === r.id;
                return (
                  <div
                    key={r.id}
                    onClick={() => setSelectedRun(r)}
                    style={{
                      padding: '0.75rem',
                      borderRadius: '8px',
                      background: isSelected ? 'rgba(59, 130, 246, 0.15)' : 'var(--bg-surface-elevated)',
                      border: `1px solid ${isSelected ? '#3b82f6' : 'var(--border-subtle)'}`,
                      cursor: 'pointer',
                    }}
                  >
                    <div style={{ fontWeight: 600, fontSize: '0.85rem' }}>{r.niche || 'General'}</div>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '2px' }}>
                      {new Date(r.createdAt).toLocaleDateString()} • {r.ideas?.length || 0} ideas • {r.sources?.length || 0} sources
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Details Pane */}
          {selectedRun && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              {/* Discovered Ideas */}
              <div className="glass-panel" style={{ padding: '1.5rem' }}>
                <h3 style={{ fontSize: '1.1rem', fontWeight: 700, marginBottom: '1rem' }}>
                  Discovered Content Ideas ({selectedRun.ideas?.length || 0})
                </h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                  {selectedRun.ideas?.map((idea: any) => (
                    <div key={idea.id} className="glass-card" style={{ padding: '1rem' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                        <div>
                          <h4 style={{ fontSize: '0.95rem', fontWeight: 700 }}>{idea.topic}</h4>
                          <p style={{ fontSize: '0.825rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
                            {idea.angle}
                          </p>
                        </div>
                        <span className="badge badge-success">Trend: {idea.trendScore}</span>
                      </div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '8px' }}>
                        Intent: <strong>{idea.searchIntent}</strong> • Audience: <strong>{idea.targetAudience}</strong>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Research Sources & Citations */}
              <div className="glass-panel" style={{ padding: '1.5rem' }}>
                <h3 style={{ fontSize: '1.1rem', fontWeight: 700, marginBottom: '1rem' }}>
                  Verified Citations & Sources ({selectedRun.sources?.length || 0})
                </h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  {selectedRun.sources?.map((s: any) => (
                    <div
                      key={s.id}
                      style={{
                        padding: '0.75rem',
                        background: 'var(--bg-surface-elevated)',
                        borderRadius: '6px',
                        border: '1px solid var(--border-subtle)',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                      }}
                    >
                      <div>
                        <div style={{ fontSize: '0.85rem', fontWeight: 600 }}>{s.title}</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{s.url}</div>
                      </div>
                      <span className="badge badge-info">Authority: {s.authorityScore}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
