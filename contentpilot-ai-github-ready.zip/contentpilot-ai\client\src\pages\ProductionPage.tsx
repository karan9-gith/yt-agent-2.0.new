import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { EmptyState } from '../components/EmptyState';
import { VideoPlayer } from '../components/VideoPlayer';
import {
  Video,
  Play,
  RotateCcw,
  CheckCircle2,
  Clock,
  Layers,
  Mic,
  Film,
  HardDrive,
  AlertTriangle,
} from 'lucide-react';

interface ProductionPageProps {
  channelId: string;
  onNavigate: (page: any) => void;
}

export const ProductionPage: React.FC<ProductionPageProps> = ({ channelId, onNavigate }) => {
  const [projects, setProjects] = useState<any[]>([]);
  const [selectedProject, setSelectedProject] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [isRendering, setIsRendering] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    loadProjects();
  }, [channelId]);

  const loadProjects = async () => {
    try {
      setLoading(true);
      const list = await api.getProductionProjects(channelId);
      setProjects(list);
      if (list.length > 0) {
        await loadProjectDetails(list[0].id);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const loadProjectDetails = async (id: string) => {
    try {
      const details = await api.getProductionProject(id);
      setSelectedProject(details);
    } catch (err) {
      console.error(err);
    }
  };

  const handleRender = async () => {
    if (!selectedProject) return;
    try {
      setIsRendering(true);
      setMessage(null);
      const res = await api.renderProject(selectedProject.id);
      setMessage(res.message);
      await loadProjectDetails(selectedProject.id);
    } catch (err: any) {
      setMessage(`Render error: ${err.message}`);
    } finally {
      setIsRendering(false);
    }
  };

  const handleRegenerateScene = async (sceneIndex: number) => {
    if (!selectedProject) return;
    try {
      setMessage(null);
      const res = await api.regenerateScene(selectedProject.id, sceneIndex);
      setMessage(res.message);
      await loadProjectDetails(selectedProject.id);
    } catch (err: any) {
      setMessage(`Regeneration error: ${err.message}`);
    }
  };

  const latestRender = selectedProject?.renders?.[0];

  return (
    <div style={{ padding: '2rem' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Video Assembly & Production Studio</h1>
          <p className="page-description">
            Multi-scene visual sequencing, synced voiceover narration, and deterministic FFmpeg rendering.
          </p>
        </div>
        {selectedProject && (
          <button className="btn btn-primary" onClick={handleRender} disabled={isRendering}>
            <Play size={16} /> {isRendering ? 'Queuing Render...' : 'Trigger Master Render'}
          </button>
        )}
      </div>

      {message && (
        <div className="badge badge-info" style={{ marginBottom: '1rem', padding: '8px 12px' }}>
          {message}
        </div>
      )}

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Loading video projects...</p>
      ) : projects.length === 0 ? (
        <EmptyState
          title="No video production projects found."
          message="Trigger the Autonomous Operator to launch automated video assembly."
          actionText="Open Autonomous Operator"
          onAction={() => onNavigate('operator')}
        />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2.5fr', gap: '1.5rem' }}>
          {/* Projects sidebar */}
          <div className="glass-panel" style={{ padding: '1rem', maxHeight: '75vh', overflowY: 'auto' }}>
            <h3 style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '0.75rem', textTransform: 'uppercase' }}>
              Projects ({projects.length})
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              {projects.map((p) => {
                const isSelected = selectedProject?.id === p.id;
                return (
                  <div
                    key={p.id}
                    onClick={() => loadProjectDetails(p.id)}
                    style={{
                      padding: '0.85rem',
                      borderRadius: '8px',
                      background: isSelected ? 'rgba(59, 130, 246, 0.15)' : 'var(--bg-surface-elevated)',
                      border: `1px solid ${isSelected ? '#3b82f6' : 'var(--border-subtle)'}`,
                      cursor: 'pointer',
                    }}
                  >
                    <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>{p.title}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                      {p.format} • {p.status}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Project Production Pane */}
          {selectedProject && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              {/* Top Overview & Master Render Preview */}
              <div className="glass-panel" style={{ padding: '1.75rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
                  <div>
                    <span className="badge badge-info" style={{ marginBottom: '4px' }}>{selectedProject.status}</span>
                    <h2 style={{ fontSize: '1.3rem', fontWeight: 800 }}>{selectedProject.title}</h2>
                  </div>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <span className="badge badge-info">{selectedProject.resolution}</span>
                    <span className="badge badge-info">{selectedProject.targetFps} FPS</span>
                  </div>
                </div>

                {/* Video Player */}
                <div style={{ marginBottom: '1.5rem' }}>
                  <VideoPlayer
                    filePath={latestRender?.outputPath}
                    thumbnailPath={selectedProject.thumbnail?.variants?.[0]?.assetPath}
                    title={selectedProject.title}
                  />
                </div>

                {/* Validation Stats */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1rem' }}>
                  <div className="glass-card" style={{ padding: '0.85rem' }}>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)' }}>FILE INTEGRITY</div>
                    <div style={{ fontSize: '0.95rem', fontWeight: 700, marginTop: '4px', color: selectedProject.fileVerification?.verified ? '#34d399' : '#fbbf24' }}>
                      {selectedProject.fileVerification?.verified ? 'Verified MP4' : 'Pending Render'}
                    </div>
                  </div>

                  <div className="glass-card" style={{ padding: '0.85rem' }}>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)' }}>AUDIO NARRATION</div>
                    <div style={{ fontSize: '0.95rem', fontWeight: 700, marginTop: '4px', color: selectedProject.narration ? '#34d399' : '#fbbf24' }}>
                      {selectedProject.narration ? `${selectedProject.narration.durationSec}s Synthesized` : 'Missing'}
                    </div>
                  </div>

                  <div className="glass-card" style={{ padding: '0.85rem' }}>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)' }}>RENDER TIME</div>
                    <div style={{ fontSize: '0.95rem', fontWeight: 700, marginTop: '4px' }}>
                      {latestRender ? `${latestRender.renderTimeSec}s` : 'N/A'}
                    </div>
                  </div>
                </div>
              </div>

              {/* Scene Breakdown List */}
              <div className="glass-panel" style={{ padding: '1.5rem' }}>
                <h3 style={{ fontSize: '1.1rem', fontWeight: 700, marginBottom: '1rem' }}>
                  Scene Sequence & Narration Alignment ({selectedProject.scenes?.length || 0} Scenes)
                </h3>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                  {selectedProject.scenes?.map((scene: any) => (
                    <div key={scene.id} className="glass-card" style={{ padding: '1rem' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <span style={{ fontSize: '0.85rem', fontWeight: 700 }}>Scene #{scene.sceneIndex + 1}: {scene.label}</span>
                          <span className="badge badge-info">{scene.durationSec}s</span>
                        </div>
                        <button
                          className="btn btn-secondary"
                          style={{ fontSize: '0.72rem', padding: '4px 8px' }}
                          onClick={() => handleRegenerateScene(scene.sceneIndex)}
                        >
                          <RotateCcw size={12} /> Regenerate Scene
                        </button>
                      </div>

                      <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
                        <strong>Narration:</strong> "{scene.narrationSegment}"
                      </div>

                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        <strong>Visual Prompt:</strong> {scene.visualDescription}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
