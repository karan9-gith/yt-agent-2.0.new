export type PageId =
  | 'overview'
  | 'operator'
  | 'research'
  | 'ideas'
  | 'strategy'
  | 'scripts'
  | 'thumbnails'
  | 'production'
  | 'review'
  | 'publishing'
  | 'youtube'
  | 'analytics'
  | 'experiments'
  | 'learning'
  | 'scheduler'
  | 'providers'
  | 'settings'
  | 'logs'
  | 'health';

export interface Channel {
  id: string;
  name: string;
  niche: string;
  targetAudience: string;
  brandVoice: string;
  visualStyle: string;
  defaultLanguage: string;
  timezone: string;
  settings?: ChannelSettings;
}

export interface ChannelSettings {
  id: string;
  channelId: string;
  autoPublish: boolean;
  requireHumanApproval: boolean;
  automationEnabled: boolean;
  researchEnabled: boolean;
  generationEnabled: boolean;
  autoPublishEnabled: boolean;
  publishingCadence: string;
  preferredPublishTime: string;
  timezone: string;
  maxVideosPerDay: number;
  maxConcurrentJobs: number;
  targetDurationSec: number;
  defaultFormat: string;
  bannedTopics: string;
  excludedKeywords: string;
  contentPillars: string;
}

export interface OverviewData {
  activeJobsCount: number;
  failedJobsCount: number;
  queuedJobsCount: number;
  awaitingApprovalCount: number;
  scheduledVideosCount: number;
  publishedVideosCount: number;
  recentProjects: Array<{
    id: string;
    status: string;
    currentStage: string;
    title: string;
    updatedAt: string;
  }>;
  analytics: {
    hasData: boolean;
    totalViews: number;
    totalWatchTimeMinutes: number;
    totalLikes: number;
    totalComments: number;
    videoCount: number;
  };
  automation: {
    autoPublish: boolean;
    requireHumanApproval: boolean;
    defaultPrivacy?: string;
    schedulerRunning: boolean;
    workerRunning: boolean;
    channelAutomationEnabled: boolean;
    publishingCadence: string;
  };
  systemStatus: {
    geminiConfigured: boolean;
    youtubeConnected: boolean;
    databaseConnected: boolean;
    storageConfigured: boolean;
  };
}

export interface ComponentHealth {
  name: string;
  status: 'healthy' | 'warning' | 'error' | 'not_configured';
  message: string;
  latencyMs?: number;
  details?: Record<string, unknown>;
}

export interface HealthReport {
  status: 'healthy' | 'warning' | 'error';
  timestamp: string;
  totalDurationMs: number;
  governance: {
    autoPublish: boolean;
    requireHumanApproval: boolean;
  };
  components: ComponentHealth[];
}

export interface ReviewBundle {
  project: {
    id: string;
    title: string;
    status: string;
    currentStage: string;
    format: string;
  };
  video: {
    exists: boolean;
    masterPath: string | null;
    fileSize: number;
    durationSec: number;
    resolution: string;
    codec: string;
  };
  thumbnail: {
    variantId: string | null;
    assetPath: string | null;
    prompt: string | null;
    composition: string | null;
  };
  metadata: {
    title: string;
    description: string;
    tags: string[];
    chapters: Array<{ timestamp: string; title: string }>;
    primaryKeyword: string;
  };
  script: {
    id: string;
    version: number;
    hookText: string;
    sections: Array<{ type: string; title: string; narration: string; visualCue: string }>;
    ctaText: string;
    outroText: string;
    claims: Array<{ claim: string; confidence: number; sourceUrl?: string }>;
  };
  research: {
    sources: Array<{ title: string; url: string; platform: string; authority: number }>;
  };
  qualityControl: {
    id: string;
    status: string;
    passed: boolean;
    overallScore: number;
    loudnessLufs: number;
    blackFrameDetected: boolean;
    audioVideoDriftSec: number;
    findings: Array<{ rule: string; severity: string; passed: boolean; message: string }>;
  } | null;
  rightsAndProvenance: {
    id: string;
    status: string;
    syntheticMediaFlag: boolean;
    factualClaimsChecked: number;
    unsupportedClaimsCount: number;
    copyrightRiskScore: number;
    disclaimerNotes: string;
  } | null;
  approval: {
    id: string;
    status: string;
    version: number;
    approvedBy: string | null;
    approvedAt: string | null;
    reviewerNotes: string | null;
  } | null;
  logs: {
    stateTransitions: Array<{ from: string; to: string; trigger: string; timestamp: string }>;
    autoFixActions: Array<{ error: string; classification: string; fix: string; result: string; timestamp: string }>;
  };
}
