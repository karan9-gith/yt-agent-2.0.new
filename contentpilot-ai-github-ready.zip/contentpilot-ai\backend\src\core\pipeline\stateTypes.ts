export const VideoPipelineState = {
  IDEA: 'IDEA',
  RESEARCHED: 'RESEARCHED',
  STRATEGY_READY: 'STRATEGY_READY',
  SCRIPT_READY: 'SCRIPT_READY',
  SEO_READY: 'SEO_READY',
  THUMBNAIL_READY: 'THUMBNAIL_READY',
  NARRATION_READY: 'NARRATION_READY',
  VISUALS_READY: 'VISUALS_READY',
  RENDERED: 'RENDERED',
  QC_PASSED: 'QC_PASSED',
  AWAITING_APPROVAL: 'AWAITING_APPROVAL',
  APPROVED: 'APPROVED',
  SCHEDULED: 'SCHEDULED',
  UPLOADING: 'UPLOADING',
  PUBLISHED: 'PUBLISHED',
  ANALYTICS_PENDING: 'ANALYTICS_PENDING',
  LEARNING_COMPLETE: 'LEARNING_COMPLETE',
} as const;

export type VideoPipeStateType = typeof VideoPipelineState[keyof typeof VideoPipelineState];

export interface StateTransitionEvent {
  projectId: string;
  fromState: VideoPipeStateType;
  toState: VideoPipeStateType;
  trigger: 'user_action' | 'agent_complete' | 'error_recovery' | 'scheduler' | 'system';
  meta?: Record<string, unknown>;
  timestamp: Date;
}
