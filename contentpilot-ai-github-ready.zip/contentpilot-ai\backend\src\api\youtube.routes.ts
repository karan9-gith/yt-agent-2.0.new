import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '../database/client.js';
import { youtubeAuthService } from '../services/youtube/youtubeAuth.js';
import { youtubeUploadEngine } from '../services/youtube/youtubeUploadEngine.js';

const router = Router();
const param = (p: string | string[]): string => (Array.isArray(p) ? p[0] : p);

// GET OAuth authorization URL
router.get('/auth-url', (req: Request, res: Response, next: NextFunction) => {
  try {
    if (!youtubeAuthService.isConfigured()) {
      res.status(400).json({
        success: false,
        error: 'YouTube connection is not configured yet.',
        message: 'YouTube connection is not configured yet.',
      });
      return;
    }
    const state = req.query.state as string | undefined;
    const url = youtubeAuthService.getAuthUrl(state);
    res.json({ success: true, url });
  } catch (err) {
    next(err);
  }
});

// GET handle OAuth redirect callback directly from Google consent screen
router.get('/callback', async (req: Request, res: Response) => {
  try {
    const code = req.query.code as string | undefined;
    const channelId = req.query.state as string | undefined;
    const oauthError = req.query.error as string | undefined;

    if (oauthError) {
      res.status(400).send(`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8" />
          <title>ContentPilot AI — YouTube Authorization</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0b0f19; color: #f87171; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
            .card { background: #131b2e; padding: 2.5rem; border-radius: 12px; border: 1px solid #1e293b; max-width: 480px; text-align: center; box-shadow: 0 10px 25px rgba(0,0,0,0.5); }
            h2 { color: #f87171; margin-top: 0; }
            p { color: #94a3b8; font-size: 0.95rem; line-height: 1.5; }
            button { margin-top: 1.5rem; background: #3b82f6; color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 8px; font-weight: 600; cursor: pointer; }
          </style>
        </head>
        <body>
          <div class="card">
            <h2>Authentication Cancelled</h2>
            <p>Google OAuth returned: ${oauthError}. You may close this window and try again.</p>
            <button onclick="window.close()">Close Window</button>
          </div>
        </body>
        </html>
      `);
      return;
    }

    if (!code || !channelId) {
      res.status(400).send(`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8" />
          <title>ContentPilot AI — Missing Parameters</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0b0f19; color: #f87171; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
            .card { background: #131b2e; padding: 2.5rem; border-radius: 12px; border: 1px solid #1e293b; max-width: 480px; text-align: center; }
            h2 { color: #f87171; margin-top: 0; }
            p { color: #94a3b8; font-size: 0.95rem; }
            button { margin-top: 1.5rem; background: #3b82f6; color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 8px; font-weight: 600; cursor: pointer; }
          </style>
        </head>
        <body>
          <div class="card">
            <h2>Missing OAuth Code or Channel ID</h2>
            <p>Google callback did not provide the required authorization code or state identifier.</p>
            <button onclick="window.close()">Close Window</button>
          </div>
        </body>
        </html>
      `);
      return;
    }

    const result = await youtubeAuthService.handleCallback(code, channelId);

    res.status(200).send(`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8" />
        <title>YouTube Connected — ContentPilot AI</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0b0f19; color: #f1f5f9; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
          .card { background: #131b2e; padding: 2.5rem; border-radius: 12px; border: 1px solid rgba(34, 197, 94, 0.3); max-width: 480px; text-align: center; box-shadow: 0 10px 25px rgba(0,0,0,0.5); }
          h2 { color: #22c55e; margin-top: 0; }
          p { color: #94a3b8; font-size: 0.95rem; line-height: 1.5; }
          .status { color: #38bdf8; font-weight: 600; }
        </style>
      </head>
      <body>
        <div class="card">
          <h2>YouTube Channel Connected!</h2>
          <p>Channel <span class="status">${result.title || result.handle || result.channelId || 'Verified'}</span> has been successfully authenticated.</p>
          <p style="font-size: 0.85rem; color: #64748b;">This window will close automatically...</p>
        </div>
        <script>
          if (window.opener) {
            try { window.opener.postMessage({ type: 'YOUTUBE_AUTH_SUCCESS', channelId: '${channelId}' }, '*'); } catch (e) {}
          }
          setTimeout(function() { window.close(); }, 2500);
        </script>
      </body>
      </html>
    `);
  } catch (err: any) {
    res.status(500).send(`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8" />
        <title>OAuth Error — ContentPilot AI</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0b0f19; color: #f87171; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
          .card { background: #131b2e; padding: 2.5rem; border-radius: 12px; border: 1px solid #ef4444; max-width: 480px; text-align: center; }
          h2 { color: #ef4444; margin-top: 0; }
          p { color: #94a3b8; font-size: 0.95rem; }
          button { margin-top: 1.5rem; background: #3b82f6; color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 8px; font-weight: 600; cursor: pointer; }
        </style>
      </head>
      <body>
        <div class="card">
          <h2>Token Exchange Failed</h2>
          <p>${err.message || 'Failed to exchange OAuth code for tokens'}</p>
          <button onclick="window.close()">Close Window</button>
        </div>
      </body>
      </html>
    `);
  }
});

// POST handle OAuth callback code
router.post('/callback', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { code, channelId } = req.body;
    if (!code || !channelId) {
      res.status(400).json({ success: false, error: 'Fields "code" and "channelId" are required' });
      return;
    }
    const result = await youtubeAuthService.handleCallback(code, channelId);
    res.json({ success: true, channel: result });
  } catch (err) {
    next(err);
  }
});

// GET verify channel connection
router.get('/verify/:channelId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const status = await youtubeAuthService.verifyChannel(param(req.params.channelId));
    res.json({ success: true, status });
  } catch (err) {
    next(err);
  }
});

// POST disconnect channel
router.post('/disconnect/:channelId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    await youtubeAuthService.disconnectChannel(param(req.params.channelId));
    res.json({ success: true, message: 'YouTube channel disconnected' });
  } catch (err) {
    next(err);
  }
});

// POST trigger upload for project
router.post('/upload/:projectId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    if (!youtubeAuthService.isConfigured()) {
      res.status(400).json({
        success: false,
        error: 'YouTube connection is not configured yet.',
        message: 'YouTube connection is not configured yet. Upload requires YouTube OAuth configuration.',
      });
      return;
    }
    const { channelId, privacyStatus, scheduledPublishTime, playlistId } = req.body;
    if (!channelId) {
      res.status(400).json({ success: false, error: 'Field "channelId" is required' });
      return;
    }
    const result = await youtubeUploadEngine.upload({
      projectId: param(req.params.projectId),
      channelId,
      privacyStatus,
      scheduledPublishTime: scheduledPublishTime ? new Date(scheduledPublishTime) : undefined,
      playlistId,
    });
    res.json({ success: true, result });
  } catch (err) {
    next(err);
  }
});

// GET video status on YouTube
router.get('/video-status/:channelId/:videoId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const status = await youtubeUploadEngine.getVideoStatus(param(req.params.channelId), param(req.params.videoId));
    res.json({ success: true, status });
  } catch (err) {
    next(err);
  }
});

// PATCH update video metadata on YouTube
router.patch('/metadata/:channelId/:videoId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const updated = await youtubeUploadEngine.updateMetadata(
      param(req.params.channelId),
      param(req.params.videoId),
      req.body
    );
    res.json({ success: true, updated });
  } catch (err) {
    next(err);
  }
});

// GET all published/uploaded videos for a channel
router.get('/videos/:channelId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = param(req.params.channelId);
    const videos = await prisma.youTubeVideo.findMany({
      where: { channelId },
      include: {
        project: { select: { id: true, title: true, format: true } },
        analytics: { where: { measurementWindow: 'lifetime' }, take: 1 },
      },
      orderBy: { publishedAt: 'desc' },
      take: 50,
    });
    res.json({ success: true, count: videos.length, data: videos });
  } catch (err) {
    next(err);
  }
});

// GET complete channel YouTube connection and status overview
router.get('/status/:channelId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = param(req.params.channelId);
    const channel = await prisma.channel.findUnique({
      where: { id: channelId },
      include: { settings: true },
    });

    const credential = await prisma.credential.findFirst({
      where: { channelId, provider: 'youtube', status: 'active' },
      select: { provider: true, status: true, updatedAt: true, expiresAt: true },
    });

    const publishedCount = await prisma.youTubeVideo.count({ where: { channelId } });
    const queuedCount = await prisma.publishingQueue.count({
      where: { channelId, status: { in: ['QUEUED', 'PUBLISHING'] } },
    });

    const isConfigured = youtubeAuthService.isConfigured();

    res.json({
      success: true,
      data: {
        isConfigured,
        configurationMessage: isConfigured ? 'Configured' : 'YouTube connection is not configured yet.',
        channel: channel
          ? {
              id: channel.id,
              name: channel.name,
              handle: channel.handle,
              youtubeChannelId: channel.youtubeChannelId,
              defaultLanguage: channel.defaultLanguage,
              timezone: channel.timezone,
            }
          : null,
        isConnected: !!credential,
        credentialStatus: credential?.status || (isConfigured ? 'disconnected' : 'not_configured'),
        tokenExpiresAt: credential?.expiresAt || null,
        publishedCount,
        queuedCount,
      },
    });
  } catch (err) {
    next(err);
  }
});

export default router;
