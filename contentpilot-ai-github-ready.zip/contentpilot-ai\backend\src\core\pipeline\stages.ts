import { PipelineStageType } from '../../types/index.js';

export interface StageDefinition {
  stage: PipelineStageType;
  name: string;
  description: string;
  requiresArtifactsFrom: PipelineStageType[];
  isDeterministic: boolean;
  canAutoFix: boolean;
}

export const STAGE_DEFINITIONS: Record<PipelineStageType, StageDefinition> = {
  research: {
    stage: 'research',
    name: 'Research & Opportunity Mining',
    description: 'Discovers viral topics, keyword gaps, and competitor white space',
    requiresArtifactsFrom: [],
    isDeterministic: false,
    canAutoFix: true,
  },
  strategy: {
    stage: 'strategy',
    name: 'Content Strategy Formulation',
    description: 'Establishes format, target duration, hook hypothesis, and narrative arc',
    requiresArtifactsFrom: ['research'],
    isDeterministic: false,
    canAutoFix: true,
  },
  script: {
    stage: 'script',
    name: 'Screenplay & Scene Blueprinting',
    description: 'Generates scene-by-scene script text, visual prompts, and claim citations',
    requiresArtifactsFrom: ['strategy'],
    isDeterministic: false,
    canAutoFix: true,
  },
  seo: {
    stage: 'seo',
    name: 'SEO & Metadata Optimization',
    description: 'Generates high-CTR title variations, descriptions, tags, and timestamps',
    requiresArtifactsFrom: ['script'],
    isDeterministic: false,
    canAutoFix: true,
  },
  thumbnail: {
    stage: 'thumbnail',
    name: 'Thumbnail Conception & Rendering',
    description: 'Renders high-contrast, visually engaging 1280x720 thumbnail designs',
    requiresArtifactsFrom: ['script', 'seo'],
    isDeterministic: false,
    canAutoFix: true,
  },
  narration: {
    stage: 'narration',
    name: 'Voice Narration Synthesis',
    description: 'Synthesizes studio-grade voiceover audio with word-level timing alignment',
    requiresArtifactsFrom: ['script'],
    isDeterministic: true,
    canAutoFix: true,
  },
  visual_assets: {
    stage: 'visual_assets',
    name: 'Visual Assets Synthesis',
    description: 'Generates 1080p imagery or video clips for each individual scene',
    requiresArtifactsFrom: ['script'],
    isDeterministic: false,
    canAutoFix: true,
  },
  video_production: {
    stage: 'video_production',
    name: 'FFmpeg Timeline Compilation',
    description: 'Stitches visuals, applies motion filters, ducks music, and renders master video',
    requiresArtifactsFrom: ['narration', 'visual_assets'],
    isDeterministic: true,
    canAutoFix: true,
  },
  quality_control: {
    stage: 'quality_control',
    name: 'Automated QC & Audio Verification',
    description: 'FFprobe container check, LUFS -14 loudness check, and black-frame detection',
    requiresArtifactsFrom: ['video_production'],
    isDeterministic: true,
    canAutoFix: false,
  },
  rights_provenance: {
    stage: 'rights_provenance',
    name: 'Rights, Citations & AI Disclosure',
    description: 'Audits factual claims, cites sources, and sets synthetic media flags',
    requiresArtifactsFrom: ['script'],
    isDeterministic: true,
    canAutoFix: false,
  },
  human_approval: {
    stage: 'human_approval',
    name: 'Editorial Human Approval Gate',
    description: 'Mandatory human sign-off; enables granular scene inspection and revision',
    requiresArtifactsFrom: ['quality_control', 'rights_provenance'],
    isDeterministic: false,
    canAutoFix: false,
  },
  publishing: {
    stage: 'publishing',
    name: 'Idempotent YouTube Publication',
    description: 'Resumable HTTP upload to YouTube with thumbnail, scheduling, and tags',
    requiresArtifactsFrom: ['human_approval'],
    isDeterministic: true,
    canAutoFix: true,
  },
  analytics: {
    stage: 'analytics',
    name: 'Post-Publication Analytics Telemetry',
    description: 'Syncs retention curves, CTR, impressions, and subscriber lift from YouTube',
    requiresArtifactsFrom: ['publishing'],
    isDeterministic: true,
    canAutoFix: true,
  },
  learning: {
    stage: 'learning',
    name: 'Closed-Loop Algorithmic Learning',
    description: 'Extracts performance correlations to continually tune channel strategy',
    requiresArtifactsFrom: ['analytics'],
    isDeterministic: false,
    canAutoFix: false,
  },
};
