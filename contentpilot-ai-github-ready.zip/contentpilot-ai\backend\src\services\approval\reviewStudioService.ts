import { prisma } from '../../database/client.js';
import { logger } from '../../utils/logger.js';
import { AppError } from '../../utils/errors.js';
import { pipelineStateMachine } from '../../core/pipeline/stateMachine.js';
import { VideoPipelineState, VideoPipeStateType } from '../../core/pipeline/stateTypes.js';
import { persistentJobQueue } from '../../jobs/jobQueue.js';

export interface ReviewStudioBundle {
  project: {
    id: string;
    channelId: string;
    title: string;
    status: string;
    currentStage: string;
    format: string;
    resolution: string;
    createdAt: Date;
  };
  video: {
    id?: string;
    outputPath?: string;
    durationSec?: number;
    fileSize?: number;
    resolution?: string;
    fps?: number;
    status?: string;
    bitrate?: number | null;
  } | null;
  thumbnail: {
    selectedVariant: {
      id?: string;
      assetPath?: string | null;
      prompt?: string;
      textOverlay?: string;
      composition?: string;
      layout?: string;
      visualHierarchy?: string;
    } | null;
    allVariants: Array<{
      id: string;
      assetPath: string | null;
      textOverlay: string;
      isSelected: boolean;
    }>;
  };
  metadata: {
    recommendedTitle: string;
    candidateTitles: string[];
    description: string;
    tags: string[];
    chapters: Array<{ timestamp: string; title: string }>;
  };
  script: {
    id: string;
    title: string;
    hook: Record<string, unknown>;
    sections: Array<Record<string, unknown>>;
    ctaText: string;
    outroText: string;
    wordCount: number;
    estimatedDurationSec: number;
    claims: Array<Record<string, unknown>>;
  } | null;
  researchSources: Array<{
    id: string;
    title: string;
    url: string;
    sourcePlatform: string;
    authorityScore: number;
    relevanceScore: number;
    snippet: string | null;
  }>;
  qcReport: {
    id?: string;
    passed: boolean;
    overallScore: number;
    loudnessLufs: number;
    blackFrameDetected: boolean;
    audioVideoDriftSec: number;
    status: string;
    findings: Array<Record<string, unknown>>;
  } | null;
  rightsReport: {
    id?: string;
    status: string;
    syntheticMediaFlag: boolean;
    factualClaimsChecked: number;
    unsupportedClaimsCount: number;
    claims: Array<Record<string, unknown>>;
    sourceAttributions: Array<Record<string, unknown>>;
    copyrightRiskScore: number;
    disclaimerNotes: string;
  } | null;
  generationLogs: {
    stateHistory: Array<{
      fromState: string;
      toState: string;
      trigger: string;
      timestamp: Date;
    }>;
    jobEvents: Array<{
      stage: string;
      progress: number;
      message: string;
      createdAt: Date;
    }>;
    autoFixes: Array<{
      error: string;
      classification: string;
      diagnosis: string;
      fixApplied: string;
      result: string;
      timestamp: Date;
    }>;
  };
  approval: {
    id?: string;
    approvalStatus: string;
    approvedBy?: string | null;
    approvedAt?: Date | null;
    approvalVersion: number;
    reviewerNotes?: string | null;
  };
}

export class ReviewStudioService {
  /**
   * Fetch complete Review Studio artifact bundle
   */
  public async getReviewBundle(projectId: string): Promise<ReviewStudioBundle> {
    const project = await prisma.videoProject.findUnique({
      where: { id: projectId },
      include: {
        renders: { orderBy: { createdAt: 'desc' }, take: 1 },
        thumbnail: { include: { variants: true } },
        seoPackage: true,
        script: {
          include: {
            rightsChecks: { orderBy: { createdAt: 'desc' }, take: 1 },
            versions: { orderBy: { versionNumber: 'desc' }, take: 1 },
          },
        },
        qualityChecks: { orderBy: { createdAt: 'desc' }, take: 1 },
        approvalRequests: { orderBy: { createdAt: 'desc' }, take: 1 },
      },
    });

    if (!project) {
      throw new AppError(`Project '${projectId}' not found`, 404, 'PROJECT_NOT_FOUND');
    }

    // Video render info
    const latestRender = project.renders[0];
    const videoData = latestRender
      ? {
          id: latestRender.id,
          outputPath: latestRender.outputPath,
          durationSec: latestRender.durationSec,
          fileSize: latestRender.fileSize,
          resolution: latestRender.resolution,
          fps: latestRender.fps,
          status: latestRender.status,
          bitrate: latestRender.bitrate,
        }
      : null;

    // Thumbnail info
    const variants = project.thumbnail?.variants ?? [];
    const selectedVariant = variants.find((v) => v.isSelected) || variants[0] || null;

    // SEO & Metadata info
    const seo = project.seoPackage;
    let candidateTitles: string[] = [];
    let tags: string[] = [];
    let chapters: Array<{ timestamp: string; title: string }> = [];

    if (seo) {
      try {
        const parsed = JSON.parse(seo.titleCandidatesJson || '[]');
        candidateTitles = Array.isArray(parsed)
          ? parsed.map((item: { title?: string } | string) => (typeof item === 'string' ? item : item.title || ''))
          : [];
      } catch {
        candidateTitles = [];
      }
      try {
        tags = JSON.parse(seo.tagsJson || '[]');
      } catch {
        tags = [];
      }
      try {
        chapters = JSON.parse(seo.chaptersJson || '[]');
      } catch {
        chapters = [];
      }
    }

    // Script info
    let scriptData = null;
    if (project.script) {
      let sections = [];
      let claims = [];
      try {
        sections = JSON.parse(project.script.sectionsJson || '[]');
      } catch {}
      try {
        const latestVersion = project.script.versions[0];
        claims = latestVersion ? JSON.parse(latestVersion.claimsJson || '[]') : [];
      } catch {}

      scriptData = {
        id: project.script.id,
        title: project.script.title,
        hook: {
          text: project.script.hookText,
          visualCue: project.script.hookVisualCue,
          durationSec: project.script.hookDurationSec,
        },
        sections,
        ctaText: project.script.ctaText,
        outroText: project.script.outroText,
        wordCount: project.script.wordCount,
        estimatedDurationSec: project.script.estimatedDurationSec,
        claims,
      };
    }

    // Research sources info
    const researchSources = await prisma.researchSource.findMany({
      where: {
        researchRun: {
          channelId: project.channelId,
        },
      },
      take: 10,
      orderBy: { authorityScore: 'desc' },
    });

    // QC info
    const latestQc = project.qualityChecks[0];
    let findings: Array<Record<string, unknown>> = [];
    if (latestQc) {
      try {
        findings = JSON.parse(latestQc.findingsJson || '[]');
      } catch {}
    }

    // Rights info
    const latestRights = project.script?.rightsChecks[0];
    let rightsClaims: Array<Record<string, unknown>> = [];
    let attributions: Array<Record<string, unknown>> = [];
    if (latestRights) {
      try {
        rightsClaims = JSON.parse(latestRights.claimsJson || '[]');
      } catch {}
      try {
        attributions = JSON.parse(latestRights.sourceAttributionsJson || '[]');
      } catch {}
    }

    // Generation logs & telemetry
    const stateHistory = await prisma.pipelineStateLog.findMany({
      where: { projectId },
      orderBy: { timestamp: 'asc' },
    });

    const autoFixes = await prisma.autoFixLog.findMany({
      where: { projectId },
      orderBy: { timestamp: 'desc' },
      take: 20,
    });

    const jobEvents = await prisma.jobEvent.findMany({
      where: {
        job: {
          payloadJson: { contains: projectId },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: 30,
    });

    // Approval request
    const latestApproval = project.approvalRequests[0];

    return {
      project: {
        id: project.id,
        channelId: project.channelId,
        title: project.title,
        status: project.status,
        currentStage: project.currentStage,
        format: project.format,
        resolution: project.resolution,
        createdAt: project.createdAt,
      },
      video: videoData,
      thumbnail: {
        selectedVariant: selectedVariant
          ? {
              id: selectedVariant.id,
              assetPath: selectedVariant.assetPath,
              prompt: selectedVariant.prompt,
              textOverlay: selectedVariant.textOverlay,
              composition: selectedVariant.composition,
              layout: selectedVariant.layout,
              visualHierarchy: selectedVariant.visualHierarchy,
            }
          : null,
        allVariants: variants.map((v) => ({
          id: v.id,
          assetPath: v.assetPath,
          textOverlay: v.textOverlay,
          isSelected: v.isSelected,
        })),
      },
      metadata: {
        recommendedTitle: seo?.recommendedTitle || project.title,
        candidateTitles,
        description: seo?.description || '',
        tags,
        chapters,
      },
      script: scriptData,
      researchSources: researchSources.map((s) => ({
        id: s.id,
        title: s.title,
        url: s.url,
        sourcePlatform: s.sourcePlatform,
        authorityScore: s.authorityScore,
        relevanceScore: s.relevanceScore,
        snippet: s.snippet,
      })),
      qcReport: latestQc
        ? {
            id: latestQc.id,
            passed: latestQc.passed,
            overallScore: latestQc.overallScore,
            loudnessLufs: latestQc.loudnessLufs,
            blackFrameDetected: latestQc.blackFrameDetected,
            audioVideoDriftSec: latestQc.audioVideoDriftSec,
            status: latestQc.status,
            findings,
          }
        : null,
      rightsReport: latestRights
        ? {
            id: latestRights.id,
            status: latestRights.status,
            syntheticMediaFlag: latestRights.syntheticMediaFlag,
            factualClaimsChecked: latestRights.factualClaimsChecked,
            unsupportedClaimsCount: latestRights.unsupportedClaimsCount,
            claims: rightsClaims,
            sourceAttributions: attributions,
            copyrightRiskScore: latestRights.copyrightRiskScore,
            disclaimerNotes: latestRights.disclaimerNotes,
          }
        : null,
      generationLogs: {
        stateHistory: stateHistory.map((s) => ({
          fromState: s.fromState,
          toState: s.toState,
          trigger: s.trigger,
          timestamp: s.timestamp,
        })),
        jobEvents: jobEvents.map((j) => ({
          stage: j.stage,
          progress: j.progress,
          message: j.message,
          createdAt: j.createdAt,
        })),
        autoFixes: autoFixes.map((a) => ({
          error: a.error,
          classification: a.classification,
          diagnosis: a.diagnosis,
          fixApplied: a.fixApplied,
          result: a.result,
          timestamp: a.timestamp,
        })),
      },
      approval: {
        id: latestApproval?.id,
        approvalStatus: latestApproval?.status || 'PENDING',
        approvedBy: latestApproval?.approvedBy,
        approvedAt: latestApproval?.approvedAt,
        approvalVersion: latestApproval?.approvalVersion || 1,
        reviewerNotes: latestApproval?.reviewerNotes,
      },
    };
  }

  /**
   * ACTION: APPROVE
   * Explicit editorial approval with audit trail
   */
  public async approve(projectId: string, approvedBy: string, notes?: string): Promise<void> {
    const project = await prisma.videoProject.findUnique({
      where: { id: projectId },
      include: {
        qualityChecks: { orderBy: { createdAt: 'desc' }, take: 1 },
        approvalRequests: { orderBy: { createdAt: 'desc' }, take: 1 },
      },
    });

    if (!project) {
      throw new AppError(`Project '${projectId}' not found`, 404, 'PROJECT_NOT_FOUND');
    }

    // Verify QC
    const qc = project.qualityChecks[0];
    if (qc && qc.status === 'BLOCKED') {
      throw new AppError(
        'Cannot approve project with BLOCKED Quality Control status. Fix QC issues first.',
        422,
        'QC_BLOCKED'
      );
    }

    const latestApproval = project.approvalRequests[0];
    const newVersion = (latestApproval?.approvalVersion ?? 0) + 1;
    const now = new Date();

    if (latestApproval) {
      await prisma.approvalRequest.update({
        where: { id: latestApproval.id },
        data: {
          status: 'APPROVED',
          approvedBy,
          approvedAt: now,
          approvalVersion: newVersion,
          reviewerNotes: notes || latestApproval.reviewerNotes,
        },
      });
    } else {
      await prisma.approvalRequest.create({
        data: {
          projectId,
          channelId: project.channelId,
          status: 'APPROVED',
          approvedBy,
          approvedAt: now,
          approvalVersion: 1,
          reviewerNotes: notes,
        },
      });
    }

    // Transition state machine to APPROVED
    await pipelineStateMachine.transition(
      projectId,
      VideoPipelineState.APPROVED,
      'user_action',
      { approvedBy, notes, approvalVersion: newVersion }
    );

    // Immutable audit log
    await prisma.auditLog.create({
      data: {
        channelId: project.channelId,
        entityType: 'approval',
        entityId: projectId,
        action: 'APPROVE',
        beforeJson: JSON.stringify({ status: project.status, approvalStatus: latestApproval?.status }),
        afterJson: JSON.stringify({
          status: VideoPipelineState.APPROVED,
          approvalStatus: 'APPROVED',
          approvedBy,
          approvedAt: now.toISOString(),
          approvalVersion: newVersion,
          notes,
        }),
        timestamp: now,
      },
    });

    logger.info({ msg: 'Project explicitly approved by reviewer', projectId, approvedBy, version: newVersion });
  }

  /**
   * ACTION: REJECT
   */
  public async reject(projectId: string, reviewer: string, reason: string): Promise<void> {
    const project = await prisma.videoProject.findUnique({
      where: { id: projectId },
      include: { approvalRequests: { orderBy: { createdAt: 'desc' }, take: 1 } },
    });

    if (!project) throw new AppError(`Project '${projectId}' not found`, 404, 'PROJECT_NOT_FOUND');

    const latest = project.approvalRequests[0];
    const now = new Date();

    if (latest) {
      await prisma.approvalRequest.update({
        where: { id: latest.id },
        data: {
          status: 'REJECTED',
          rejectedAt: now,
          reviewerNotes: reason,
        },
      });
    } else {
      await prisma.approvalRequest.create({
        data: {
          projectId,
          channelId: project.channelId,
          status: 'REJECTED',
          rejectedAt: now,
          reviewerNotes: reason,
        },
      });
    }

    await prisma.auditLog.create({
      data: {
        channelId: project.channelId,
        entityType: 'approval',
        entityId: projectId,
        action: 'REJECT',
        beforeJson: JSON.stringify({ status: project.status }),
        afterJson: JSON.stringify({ rejectionReason: reason, reviewer }),
        timestamp: now,
      },
    });

    logger.info({ msg: 'Project rejected by reviewer', projectId, reviewer, reason });
  }

  /**
   * ACTION: EDIT
   * Update metadata or select alternative thumbnail
   */
  public async edit(
    projectId: string,
    edits: {
      title?: string;
      description?: string;
      tags?: string[];
      chapters?: Array<{ timestamp: string; title: string }>;
      selectedThumbnailVariantId?: string;
    },
    editor: string
  ): Promise<void> {
    const project = await prisma.videoProject.findUnique({
      where: { id: projectId },
      include: {
        seoPackage: true,
        thumbnail: { include: { variants: true } },
      },
    });

    if (!project) throw new AppError(`Project '${projectId}' not found`, 404, 'PROJECT_NOT_FOUND');

    // Update SEO metadata
    if (project.seoPackage) {
      await prisma.seoPackage.update({
        where: { id: project.seoPackage.id },
        data: {
          ...(edits.title && { recommendedTitle: edits.title }),
          ...(edits.description && { description: edits.description }),
          ...(edits.tags && { tagsJson: JSON.stringify(edits.tags) }),
          ...(edits.chapters && { chaptersJson: JSON.stringify(edits.chapters) }),
          status: 'edited',
        },
      });
    }

    if (edits.title) {
      await prisma.videoProject.update({
        where: { id: projectId },
        data: { title: edits.title },
      });
    }

    // Update Thumbnail variant selection
    if (edits.selectedThumbnailVariantId && project.thumbnail) {
      await prisma.thumbnailVariant.updateMany({
        where: { thumbnailId: project.thumbnail.id },
        data: { isSelected: false },
      });

      await prisma.thumbnailVariant.update({
        where: { id: edits.selectedThumbnailVariantId },
        data: { isSelected: true },
      });

      await prisma.thumbnail.update({
        where: { id: project.thumbnail.id },
        data: { selectedVariantId: edits.selectedThumbnailVariantId },
      });
    }

    await prisma.auditLog.create({
      data: {
        channelId: project.channelId,
        entityType: 'production',
        entityId: projectId,
        action: 'UPDATE',
        afterJson: JSON.stringify({ edits, editor }),
        timestamp: new Date(),
      },
    });

    logger.info({ msg: 'Project metadata updated in Review Studio', projectId, editor });
  }

  /**
   * ACTION: REGENERATE
   * Queue targeted regeneration of a specific stage
   */
  public async regenerate(
    projectId: string,
    stage: 'thumbnail' | 'narration' | 'script' | 'seo' | 'render',
    requestedBy: string
  ): Promise<string> {
    const project = await prisma.videoProject.findUnique({
      where: { id: projectId },
    });

    if (!project) throw new AppError(`Project '${projectId}' not found`, 404, 'PROJECT_NOT_FOUND');

    // Create targeted regeneration job
    const jobId = await persistentJobQueue.createJob({
      type: stage === 'render' ? 'render' : stage,
      payload: { projectId, stage, requestedBy },
    });

    await prisma.auditLog.create({
      data: {
        channelId: project.channelId,
        entityType: 'production',
        entityId: projectId,
        action: 'REGENERATE',
        afterJson: JSON.stringify({ stage, requestedBy, jobId }),
        timestamp: new Date(),
      },
    });

    logger.info({ msg: 'Stage regeneration scheduled', projectId, stage, jobId });
    return jobId;
  }

  /**
   * ACTION: SEND BACK / CHANGES REQUESTED
   * Roll back pipeline to a previous stage for modifications
   */
  public async sendBack(
    projectId: string,
    targetStage: VideoPipeStateType,
    notes: string,
    reviewer: string
  ): Promise<void> {
    const project = await prisma.videoProject.findUnique({
      where: { id: projectId },
      include: { approvalRequests: { orderBy: { createdAt: 'desc' }, take: 1 } },
    });

    if (!project) throw new AppError(`Project '${projectId}' not found`, 404, 'PROJECT_NOT_FOUND');

    const latest = project.approvalRequests[0];
    if (latest) {
      await prisma.approvalRequest.update({
        where: { id: latest.id },
        data: {
          status: 'CHANGES_REQUESTED',
          reviewerNotes: notes,
        },
      });
    }

    // Roll back state machine
    await pipelineStateMachine.transition(
      projectId,
      targetStage,
      'user_action',
      { rollbackReason: notes, reviewer }
    );

    await prisma.auditLog.create({
      data: {
        channelId: project.channelId,
        entityType: 'approval',
        entityId: projectId,
        action: 'ROLLBACK',
        afterJson: JSON.stringify({ targetStage, notes, reviewer }),
        timestamp: new Date(),
      },
    });

    logger.info({ msg: 'Project rolled back to stage', projectId, targetStage, reviewer });
  }

  /**
   * ACTION: SCHEDULE
   * Schedule approved project for publishing
   */
  public async schedule(
    projectId: string,
    scheduledPublishTime: Date,
    privacyStatus: 'private' | 'unlisted' | 'public',
    scheduledBy: string
  ): Promise<void> {
    const project = await prisma.videoProject.findUnique({
      where: { id: projectId },
      include: { approvalRequests: { orderBy: { createdAt: 'desc' }, take: 1 } },
    });

    if (!project) throw new AppError(`Project '${projectId}' not found`, 404, 'PROJECT_NOT_FOUND');

    // Strict safety check: Must be APPROVED before scheduling
    const latestApproval = project.approvalRequests[0];
    if (!latestApproval || latestApproval.status !== 'APPROVED') {
      throw new AppError(
        'Cannot schedule publishing: Project must be explicitly APPROVED by human reviewer first.',
        403,
        'APPROVAL_REQUIRED'
      );
    }

    const idempotencyKey = `schedule_${projectId}_${Date.now()}`;

    await prisma.publishingQueue.upsert({
      where: { projectId },
      update: {
        scheduledPublishTime,
        privacyStatus,
        status: 'QUEUED',
      },
      create: {
        projectId,
        channelId: project.channelId,
        scheduledPublishTime,
        privacyStatus,
        status: 'QUEUED',
        idempotencyKey,
      },
    });

    await pipelineStateMachine.transition(
      projectId,
      VideoPipelineState.SCHEDULED,
      'user_action',
      { scheduledPublishTime: scheduledPublishTime.toISOString(), scheduledBy }
    );

    await prisma.auditLog.create({
      data: {
        channelId: project.channelId,
        entityType: 'publishing',
        entityId: projectId,
        action: 'SCHEDULE',
        afterJson: JSON.stringify({
          scheduledPublishTime: scheduledPublishTime.toISOString(),
          privacyStatus,
          scheduledBy,
        }),
        timestamp: new Date(),
      },
    });

    logger.info({
      msg: 'Project scheduled for publishing',
      projectId,
      scheduledPublishTime: scheduledPublishTime.toISOString(),
    });
  }

  /**
   * List pending projects requiring approval
   */
  public async listPendingApprovals(channelId?: string) {
    return prisma.videoProject.findMany({
      where: {
        ...(channelId && { channelId }),
        status: VideoPipelineState.AWAITING_APPROVAL,
      },
      include: {
        channel: { select: { name: true, niche: true } },
        seoPackage: { select: { recommendedTitle: true } },
        renders: { take: 1, orderBy: { createdAt: 'desc' } },
        qualityChecks: { take: 1, orderBy: { createdAt: 'desc' } },
        approvalRequests: { take: 1, orderBy: { createdAt: 'desc' } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }
}

export const reviewStudioService = new ReviewStudioService();
