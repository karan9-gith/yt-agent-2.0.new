import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { EmptyState } from '../components/EmptyState';
import { Image, CheckCircle2, Sparkles, Layers, Eye } from 'lucide-react';

interface ThumbnailsPageProps {
  channelId: string;
  onNavigate: (page: any) => void;
}

export const ThumbnailsPage: React.FC<ThumbnailsPageProps> = ({ channelId, onNavigate }) => {
  const [thumbnails, setThumbnails] = useState<any[]>([]);
  const [selectedThumb, setSelectedThumb] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadThumbnails();
  }, [channelId]);

  const loadThumbnails = async () => {
    try {
      setLoading(true);
      const data = await api.getThumbnails(channelId);
      setThumbnails(data);
      if (data.length > 0) {
        setSelectedThumb(data[0]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectVariant = async (variantId: string) => {
    if (!selectedThumb) return;
    try {
      const updated = await api.selectThumbnailVariant(selectedThumb.id, variantId);
      setSelectedThumb(updated);
      await loadThumbnails();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Thumbnail Studio & CTR Variants</h1>
          <p className="page-description">
            High-contrast visual compositions, emotional hooks, and overlay typography optimization.
          </p>
        </div>
      </div>

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Loading thumbnails...</p>
      ) : thumbnails.length === 0 ? (
        <EmptyState
          title="No thumbnails generated."
          message="Run the Autonomous Operator to automatically generate visual concepts and variant options."
          actionText="Run Operator"
          onAction={() => onNavigate('operator')}
        />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2.5fr', gap: '1.5rem' }}>
          {/* List */}
          <div className="glass-panel" style={{ padding: '1rem', maxHeight: '75vh', overflowY: 'auto' }}>
            <h3 style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '0.75rem', textTransform: 'uppercase' }}>
              Thumbnails ({thumbnails.length})
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              {thumbnails.map((t) => {
                const isSelected = selectedThumb?.id === t.id;
                return (
                  <div
                    key={t.id}
                    onClick={() => setSelectedThumb(t)}
                    style={{
                      padding: '0.85rem',
                      borderRadius: '8px',
                      background: isSelected ? 'rgba(59, 130, 246, 0.15)' : 'var(--bg-surface-elevated)',
                      border: `1px solid ${isSelected ? '#3b82f6' : 'var(--border-subtle)'}`,
                      cursor: 'pointer',
                    }}
                  >
                    <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>{t.script?.title || 'Project Thumbnail'}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                      {t.variants?.length || 0} candidate variants • Status: {t.status}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Variants Grid Pane */}
          {selectedThumb && (
            <div className="glass-panel" style={{ padding: '1.75rem' }}>
              <div style={{ marginBottom: '1.5rem' }}>
                <span className="badge badge-info" style={{ marginBottom: '6px' }}>{selectedThumb.status}</span>
                <h2 style={{ fontSize: '1.35rem', fontWeight: 800 }}>
                  {selectedThumb.script?.title || 'Thumbnail Concepts'}
                </h2>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.25rem' }}>
                {selectedThumb.variants?.map((v: any, idx: number) => {
                  const isChosen = v.isSelected;
                  const imageUrl = v.assetPath ? api.getMediaUrl(v.assetPath) : null;

                  return (
                    <div
                      key={v.id}
                      className="glass-card"
                      style={{
                        padding: '1rem',
                        border: isChosen ? '2px solid #3b82f6' : '1px solid var(--border-subtle)',
                        background: isChosen ? 'rgba(59, 130, 246, 0.08)' : 'var(--bg-card)',
                      }}
                    >
                      {/* Image Preview / Placeholder Frame */}
                      <div
                        style={{
                          width: '100%',
                          aspectRatio: '16/9',
                          background: '#090c14',
                          borderRadius: '8px',
                          overflow: 'hidden',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          marginBottom: '0.75rem',
                          border: '1px solid var(--border-subtle)',
                        }}
                      >
                        {imageUrl ? (
                          <img src={imageUrl} alt={v.textOverlay} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                        ) : (
                          <div style={{ textAlign: 'center', padding: '1rem', color: 'var(--text-muted)' }}>
                            <Image size={32} />
                            <div style={{ fontSize: '0.75rem', marginTop: '4px' }}>Variant {idx + 1} Visual</div>
                          </div>
                        )}
                      </div>

                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                        <span style={{ fontSize: '0.85rem', fontWeight: 700 }}>Variant #{idx + 1}</span>
                        {isChosen && (
                          <span className="badge badge-success">
                            <CheckCircle2 size={12} /> Active Variant
                          </span>
                        )}
                      </div>

                      <div style={{ fontSize: '0.85rem', fontWeight: 700, color: '#fbbf24', marginBottom: '6px' }}>
                        Overlay Text: "{v.textOverlay}"
                      </div>

                      <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginBottom: '8px', lineHeight: 1.4 }}>
                        <strong>Composition:</strong> {v.composition}
                      </div>

                      <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginBottom: '12px' }}>
                        Subject: <strong>{v.subject}</strong> • Emotion: <strong>{v.emotion}</strong>
                      </div>

                      {!isChosen && (
                        <button
                          className="btn btn-secondary"
                          style={{ width: '100%', fontSize: '0.8rem', padding: '6px' }}
                          onClick={() => handleSelectVariant(v.id)}
                        >
                          Select This Variant
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
