import { describe, it, expect, beforeEach, vi } from 'vitest';
import fs from 'node:fs/promises';
import path from 'node:path';
import { prisma } from '../../src/database/client.js';
import { autonomousOperator } from '../../src/services/operator/autonomousOperator.js';
import { reviewStudioService } from '../../src/services/approval/reviewStudioService.js';
import { youtubeAuthService } from '../../src/services/youtube/youtubeAuth.js';
import { youtubeUploadEngine } from '../../src/services/youtube/youtubeUploadEngine.js';
import { autoFixEngine } from '../../src/services/autofix/autoFixEngine.js';
import { preUploadSafetyChecker } from '../../src/services/youtube/preUploadSafetyCheck.js';
import { persistentJobQueue } from '../../src/jobs/jobQueue.js';
import { persistentScheduler } from '../../src/services/scheduler/schedulerEngine.js';
import { storageManager } from '../../src/storage/storageManager.js';
import { VideoPipelineState } from '../../src/core/pipeline/stateTypes.js';

describe('Deterministic End-to-End Pipeline & Resilience Test Suite', () => {
  let channelId: string;
  let mockYoutube: any;

  beforeEach(async () => {
    // 1. Mock YouTube API Client
    mockYoutube = {
      videos: {
        insert: vi.fn().mockImplementation((_params: any, options: any) => {
          options?.onUploadProgress?.({ bytesRead: 2048 });
          return Promise.resolve({
            data: { id: `yt_e2e_vid_${Date.now()}_${Math.random().toString(36).slice(2, 6)}` },
          });
        }),
        list: vi.fn().mockResolvedValue({
          data: {
            items: [
              {
                id: 'yt_e2e_vid_123',
                snippet: { title: 'E2E Title', publishedAt: new Date().toISOString() },
                contentDetails: { duration: 'PT4M00S' },
                statistics: { viewCount: '5000', likeCount: '450', commentCount: '60' },
              },
            ],
          },
        }),
        update: vi.fn().mockResolvedValue({ data: {} }),
      },
      thumbnails: {
        set: vi.fn().mockResolvedValue({ data: {} }),
      },
      playlistItems: {
        insert: vi.fn().mockResolvedValue({ data: {} }),
      },
    };

    vi.spyOn(youtubeAuthService, 'getAuthenticatedClient').mockResolvedValue({
      oauth2Client: {} as any,
      youtube: mockYoutube as any,
    });

    // 2. Setup Channel and Settings
    const user = await prisma.user.upsert({
      where: { email: 'e2e_operator@contentpilot.ai' },
      update: {},
      create: { email: 'e2e_operator@contentpilot.ai', name: 'E2E Operator' },
    });

    const channel = await prisma.channel.create({
      data: {
        userId: user.id,
        name: 'Autonomous AI Network',
        niche: 'Autonomous Software Engineering',
        targetAudience: 'Senior Engineers and Tech Leads',
        brandVoice: 'Authoritative, precise, technical',
        visualStyle: 'Cinematic dark mode with high-contrast amber accents',
        settings: {
          create: {
            defaultFormat: 'explainer',
            targetDurationSec: 480,
            publishingCadence: 'weekly',
            preferredPublishTime: '14:00',
            contentPillars: JSON.stringify(['Multi-Agent Architecture', 'AI Automation', 'Production Systems']),
            bannedTopics: JSON.stringify(['Crypto Scams', 'Unverified Rumors']),
          },
        },
      },
      include: { settings: true },
    });
    channelId = channel.id;
  });

  // ==========================================
  // E2E TEST: COMPLETE 20-STAGE FLOW
  // ==========================================
  it('E2E: Complete 20-Stage Pipeline Flow with Mandatory Approval Gate', async () => {
    // ----------------------------------------------------
    // PHASE 1: Autonomous Operator Run 1 (Stages 1 through 15)
    // ----------------------------------------------------
    const run1 = await autonomousOperator.run({
      channelId,
      channelObjective: 'Authority and technical reach',
      targetAudience: 'Software Engineers',
      contentPillars: ['Multi-Agent Architecture'],
      language: 'en',
      brandVoice: 'Authoritative',
    });

    // STAGE 16 ENFORCEMENT: The operator MUST pause and not publish!
    expect(run1.pausedForApproval).toBe(true);
    expect(run1.currentStageNumber).toBe(16);
    expect(run1.status).toBe(VideoPipelineState.AWAITING_APPROVAL);
    expect(run1.projectId).toBeDefined();

    const projectId = run1.projectId;

    // Verify all creative and media artifacts were synthesized
    expect(run1.artifacts.researchId).toBeDefined();
    expect(run1.artifacts.strategyId).toBeDefined();
    expect(run1.artifacts.scriptId).toBeDefined();
    expect(run1.artifacts.seoId).toBeDefined();
    expect(run1.artifacts.thumbnailId).toBeDefined();
    expect(run1.artifacts.narrationId).toBeDefined();
    expect(run1.artifacts.renderId).toBeDefined();
    expect(run1.artifacts.qcId).toBeDefined();
    expect(run1.artifacts.rightsId).toBeDefined();
    expect(run1.artifacts.approvalRequestId).toBeDefined();

    // ----------------------------------------------------
    // PHASE 2: Review Studio Inspection & Editorial Approval
    // ----------------------------------------------------
    const reviewBundle = await reviewStudioService.getReviewBundle(projectId);
    expect(reviewBundle.qcReport?.passed).toBe(true);
    expect(reviewBundle.rightsReport?.syntheticMediaFlag).toBe(true);
    expect(reviewBundle.approval.approvalStatus).toBe('WAITING_APPROVAL');

    // Human explicitly signs off in Review Studio
    await reviewStudioService.approve(
      projectId,
      'supervising_editor@contentpilot.ai',
      'Production quality verified. Approved for release.'
    );

    // Verify state transition to APPROVED
    const projectApproved = await prisma.videoProject.findUnique({ where: { id: projectId } });
    expect(projectApproved?.status).toBe(VideoPipelineState.APPROVED);

    // ----------------------------------------------------
    // PHASE 3: Autonomous Operator Run 2 (Stages 17 through 20)
    // Resumes seamlessly from checkpoint without regenerating!
    // ----------------------------------------------------
    const run2 = await autonomousOperator.run({
      channelId,
      existingProjectId: projectId,
    });

    expect(run2.pausedForApproval).toBe(false);
    expect(run2.currentStageNumber).toBe(20);
    expect(run2.status).toBe(VideoPipelineState.LEARNING_COMPLETE);
    expect(run2.artifacts.youtubeVideoId).toBeDefined();

    // Verify video was published
    expect(mockYoutube.videos.insert).toHaveBeenCalledTimes(1);

    const publishedRecord = await prisma.youTubeVideo.findUnique({
      where: { youtubeVideoId: run2.artifacts.youtubeVideoId },
    });
    expect(publishedRecord).not.toBeNull();
    expect(publishedRecord?.projectId).toBe(projectId);

    // Verify analytics snapshot was captured
    const snapshots = await prisma.analyticsSnapshot.findMany({
      where: { youtubeVideoId: run2.artifacts.youtubeVideoId },
    });
    expect(snapshots.length).toBeGreaterThanOrEqual(1);

    // Verify learning insights were emitted
    const insights = await prisma.learningInsight.findMany({ where: { channelId } });
    expect(insights.length).toBeGreaterThanOrEqual(1);
  });

  // ==========================================
  // FAILURE & EDGE CASE TESTS
  // ==========================================

  it('Edge Case: Gemini Failure & JSON Parse Repair Recovery', () => {
    // Malformed JSON with markdown blocks, smart quotes, and unclosed brackets
    const malformedJson = '```json\n{\u201Ctitle\u201D: \u201CDeep Learning\u201D, \u201Cscore\u201D: 99, \u201Ctags\u201D: [\u201Cai\u201D, \u201Cdeep\u201D\n```';
    const repaired = autoFixEngine.repairJsonString(malformedJson);
    const parsed = JSON.parse(repaired);
    expect(parsed.title).toBe('Deep Learning');
    expect(parsed.score).toBe(99);
    expect(parsed.tags).toEqual(['ai', 'deep']);
  });

  it('Edge Case: OAuth Failure & Token Expiration Classification', () => {
    const expiredOAuthError = new Error('invalid_grant: The OAuth token has expired or been revoked.');
    const diagnosis = autoFixEngine.classifyError(expiredOAuthError);
    expect(diagnosis.classification).toBe('AUTHENTICATION');
    expect(diagnosis.isRecoverable).toBe(true);
    expect(diagnosis.recommendedAction).toBe('REFRESH_OR_REAUTH');
  });

  it('Edge Case: Quota Exceeded Pause and Safe Retry Scheduling', () => {
    const quotaError = new Error('429 Too Many Requests: quotaExceeded');
    const diagnosis = autoFixEngine.classifyError(quotaError);
    expect(diagnosis.classification).toBe('QUOTA');
    expect(diagnosis.isRecoverable).toBe(true);
    expect(diagnosis.recommendedAction).toBe('PAUSE_AND_BACKOFF');
    expect(diagnosis.retryDelayMs).toBe(60000);
  });

  it('Edge Case: FFmpeg Dimension Failure Safe Fallback Padding', () => {
    const { width, height, filterString } = autoFixEngine.getSafeDimensions(1920, 1081);
    expect(height).toBe(1082); // Padded to even
    expect(width).toBe(1920);
    expect(filterString).toContain('pad=');
  });

  it('Edge Case: Missing Narration and Missing Media Pre-Upload Block', async () => {
    // Project without narration or video
    const unrenderedProject = await prisma.videoProject.create({
      data: {
        channelId,
        title: 'Unrendered Project',
        status: VideoPipelineState.APPROVED,
      },
    });

    await prisma.approvalRequest.create({
      data: {
        projectId: unrenderedProject.id,
        channelId,
        status: 'APPROVED',
        approvedBy: 'lead',
        approvedAt: new Date(),
      },
    });

    await prisma.qualityCheck.create({
      data: {
        projectId: unrenderedProject.id,
        passed: true,
        status: 'PASS',
        overallScore: 90,
        loudnessLufs: -14,
      },
    });

    await expect(preUploadSafetyChecker.verify(unrenderedProject.id)).rejects.toThrow(/VIDEO_CHECK_FAILED/);
  });

  it('Edge Case: Corrupt or Zero-Byte Media Detection', async () => {
    const corruptProject = await prisma.videoProject.create({
      data: {
        channelId,
        title: 'Corrupt Project',
        status: VideoPipelineState.APPROVED,
      },
    });

    const videoDir = storageManager.getVideoDir(corruptProject.id);
    const emptyMp4 = path.join(videoDir, 'empty.mp4');
    await fs.writeFile(emptyMp4, Buffer.alloc(0)); // 0-byte corrupt file!

    await prisma.approvalRequest.create({
      data: {
        projectId: corruptProject.id,
        channelId,
        status: 'APPROVED',
        approvedBy: 'lead',
        approvedAt: new Date(),
      },
    });

    await prisma.qualityCheck.create({
      data: {
        projectId: corruptProject.id,
        passed: true,
        status: 'PASS',
        overallScore: 90,
        loudnessLufs: -14,
      },
    });

    await prisma.videoRender.create({
      data: {
        projectId: corruptProject.id,
        outputPath: emptyMp4,
        durationSec: 10,
        fileSize: 0,
        status: 'completed',
        renderTimeSec: 1,
      },
    });

    await expect(preUploadSafetyChecker.verify(corruptProject.id)).rejects.toThrow(/empty or not an MP4/);
  });

  it('Edge Case: Crash Recovery & Orphaned Job Reclaim', async () => {
    // Create an orphaned job simulating a crash
    const orphanedJob = await prisma.job.create({
      data: {
        type: 'render',
        status: 'RUNNING',
        lockedBy: 'dead-worker-pid-999',
        lastHeartbeatAt: new Date(Date.now() - 5 * 60 * 1000), // 5 minutes stale
      },
    });

    // Run recovery sweep
    const recoveredCount = await persistentJobQueue.recoverOrphanedJobs();
    expect(recoveredCount).toBeGreaterThanOrEqual(1);

    const fresh = await persistentJobQueue.getJob(orphanedJob.id);
    expect(fresh.status).toBe('RETRYING');
    expect(fresh.retryCount).toBe(1);
  });

  it('Edge Case: Job Exponential Backoff Calculation', async () => {
    const job = await prisma.job.create({
      data: {
        type: 'script',
        status: 'RUNNING',
        retryCount: 1,
        maxRetries: 3,
      },
    });

    await persistentJobQueue.failOrRetryJob(job.id, 'Temporary LLM timeout');

    const retried = await persistentJobQueue.getJob(job.id);
    expect(retried.status).toBe('RETRYING');
    expect(retried.retryCount).toBe(2);
    // Scheduled for 2^1 * 5000 = 10s into future
    expect(retried.scheduledAt.getTime()).toBeGreaterThan(Date.now() + 5000);
  });

  it('Edge Case: Duplicate Upload Prevention and Idempotency', async () => {
    const project = await prisma.videoProject.create({
      data: { channelId, title: 'Duplicate Guard Test Video', status: 'PUBLISHED' },
    });

    const uniqueDupId = `yt_dup_guard_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;

    // Create existing publication
    await prisma.youTubeVideo.create({
      data: {
        projectId: project.id,
        channelId,
        youtubeVideoId: uniqueDupId,
        youtubeUrl: `https://youtube.com/watch?v=${uniqueDupId}`,
        title: 'Duplicate Guard Test Video',
        description: 'Testing duplicate prevention',
      },
    });

    // Attempt second upload -> Must immediately return existing without calling YouTube insert!
    const res = await youtubeUploadEngine.upload({
      projectId: project.id,
      channelId,
    });

    expect(res.youtubeVideoId).toBe(uniqueDupId);
    expect(mockYoutube.videos.insert).not.toHaveBeenCalled();
  });

  it('Edge Case: Human Rejection Flow and Rollback', async () => {
    const project = await prisma.videoProject.create({
      data: { channelId, title: 'Rejected Concept Video', status: VideoPipelineState.AWAITING_APPROVAL },
    });

    await prisma.approvalRequest.create({
      data: { projectId: project.id, channelId, status: 'WAITING_APPROVAL' },
    });

    // Editorial Rejection
    await reviewStudioService.reject(project.id, 'senior_editor@contentpilot.ai', 'Violates brand voice');

    const approval = await prisma.approvalRequest.findFirst({ where: { projectId: project.id } });
    expect(approval?.status).toBe('REJECTED');
    expect(approval?.reviewerNotes).toBe('Violates brand voice');

    // Attempting upload MUST be blocked!
    await expect(preUploadSafetyChecker.verify(project.id)).rejects.toThrow(/requires explicit 'APPROVED'/);
  });

  it('Edge Case: Scheduler Restart & Persistence Survival', async () => {
    const task = await prisma.scheduledTask.create({
      data: {
        channelId,
        name: 'Daily Research Harvester',
        taskType: 'research',
        scheduleType: 'daily',
        preferredTime: '15:00',
        status: 'ACTIVE',
      },
    });

    // Reboot scheduler
    await persistentScheduler.start();
    await persistentScheduler.stop();

    const fresh = await prisma.scheduledTask.findUnique({ where: { id: task.id } });
    expect(fresh?.nextRunAt).not.toBeNull();
    expect(fresh?.status).toBe('ACTIVE');
  });
});
