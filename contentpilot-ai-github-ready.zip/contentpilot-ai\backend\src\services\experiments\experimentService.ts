import { prisma } from '../../database/client.js';
import { logger } from '../../utils/logger.js';
import { AppError } from '../../utils/errors.js';

export type ExperimentType =
  | 'titles'
  | 'thumbnails'
  | 'topics'
  | 'formats'
  | 'publish_timing';

export type ExperimentStatus = 'draft' | 'running' | 'concluded' | 'applied';

export interface CreateExperimentInput {
  channelId: string;
  title: string;
  hypothesis: string;
  baseline: string; // variantA
  variant: string;  // variantB
  metric?: string;  // retention, views, ctr, etc.
  experimentType: ExperimentType;
}

export class ExperimentService {
  /**
   * Create and register a new A/B experiment
   */
  public async createExperiment(input: CreateExperimentInput) {
    const experiment = await prisma.experiment.create({
      data: {
        channelId: input.channelId,
        title: input.title,
        hypothesis: input.hypothesis,
        variantA: input.baseline,
        variantB: input.variant,
        metric: input.metric || 'retention',
        experimentType: input.experimentType,
        status: 'draft',
        humanApproved: false,
      },
    });

    logger.info({
      msg: 'A/B Experiment created',
      experimentId: experiment.id,
      title: experiment.title,
      type: experiment.experimentType,
    });

    return experiment;
  }

  /**
   * Conclude experiment and compute outcome
   */
  public async concludeExperiment(
    experimentId: string,
    results: {
      baselineMetricValue: number;
      variantMetricValue: number;
      sampleSizeA: number;
      sampleSizeB: number;
    }
  ) {
    const experiment = await prisma.experiment.findUnique({
      where: { id: experimentId },
    });

    if (!experiment) {
      throw new AppError(`Experiment '${experimentId}' not found`, 404, 'NOT_FOUND');
    }

    const { baselineMetricValue, variantMetricValue, sampleSizeA, sampleSizeB } = results;
    const diffPct =
      baselineMetricValue > 0
        ? ((variantMetricValue - baselineMetricValue) / baselineMetricValue) * 100
        : 0;

    const winner =
      variantMetricValue > baselineMetricValue
        ? experiment.variantB
        : variantMetricValue < baselineMetricValue
        ? experiment.variantA
        : 'TIE';

    // Statistical confidence estimation based on sample size and relative difference
    const totalSample = sampleSizeA + sampleSizeB;
    const confidence = totalSample < 10 ? 0.3 : totalSample < 50 ? 0.75 : 0.95;

    const resultsJson = JSON.stringify({
      baselineMetricValue,
      variantMetricValue,
      percentageDifference: parseFloat(diffPct.toFixed(2)),
      sampleSize: totalSample,
      confidence,
      winner,
    });

    const updated = await prisma.experiment.update({
      where: { id: experimentId },
      data: {
        status: 'concluded',
        winnerVariant: winner,
        resultsJson,
        endedAt: new Date(),
      },
    });

    logger.info({
      msg: 'A/B Experiment concluded',
      experimentId,
      winner,
      confidence,
    });

    return updated;
  }

  /**
   * Human approval gate for experiment outcomes
   * STRICT GOVERNANCE: Experiment winners CANNOT automatically alter strategy without human approval.
   */
  public async approveExperimentWinner(experimentId: string, approvedBy: string): Promise<void> {
    const experiment = await prisma.experiment.findUnique({
      where: { id: experimentId },
    });

    if (!experiment) {
      throw new AppError(`Experiment '${experimentId}' not found`, 404, 'NOT_FOUND');
    }

    if (experiment.status !== 'concluded') {
      throw new AppError('Cannot approve winner for an experiment that is not concluded', 400, 'INVALID_STATUS');
    }

    await prisma.experiment.update({
      where: { id: experimentId },
      data: {
        humanApproved: true,
        approvedBy,
      },
    });

    await prisma.auditLog.create({
      data: {
        channelId: experiment.channelId,
        entityType: 'experiment',
        entityId: experimentId,
        action: 'APPROVE',
        afterJson: JSON.stringify({ approvedBy, winner: experiment.winnerVariant }),
        timestamp: new Date(),
      },
    });

    logger.info({ msg: 'Experiment outcome approved by human', experimentId, approvedBy });
  }

  /**
   * Apply approved winner to channel operational defaults
   */
  public async applyExperimentWinner(experimentId: string): Promise<void> {
    const experiment = await prisma.experiment.findUnique({
      where: { id: experimentId },
    });

    if (!experiment) {
      throw new AppError(`Experiment '${experimentId}' not found`, 404, 'NOT_FOUND');
    }

    // STRICT GOVERNANCE CHECK
    if (!experiment.humanApproved) {
      throw new AppError(
        'Cannot apply experiment to channel strategy: Explicit human approval is required.',
        403,
        'HUMAN_APPROVAL_REQUIRED'
      );
    }

    if (!experiment.winnerVariant || experiment.winnerVariant === 'TIE') {
      throw new AppError('No conclusive winner variant exists to apply', 400, 'NO_WINNER');
    }

    // If format experiment, update ChannelSetting defaultFormat
    if (experiment.experimentType === 'formats') {
      await prisma.channelSetting.updateMany({
        where: { channelId: experiment.channelId },
        data: { defaultFormat: experiment.winnerVariant },
      });
    }

    // If publish timing experiment, update preferredPublishTime
    if (experiment.experimentType === 'publish_timing') {
      await prisma.channelSetting.updateMany({
        where: { channelId: experiment.channelId },
        data: { preferredPublishTime: experiment.winnerVariant },
      });
    }

    await prisma.experiment.update({
      where: { id: experimentId },
      data: { status: 'applied' },
    });

    await prisma.auditLog.create({
      data: {
        channelId: experiment.channelId,
        entityType: 'experiment',
        entityId: experimentId,
        action: 'APPLY_WINNER',
        afterJson: JSON.stringify({ winner: experiment.winnerVariant, type: experiment.experimentType }),
        timestamp: new Date(),
      },
    });

    logger.info({
      msg: 'Applied experiment winner to channel configuration',
      experimentId,
      winner: experiment.winnerVariant,
    });
  }

  /**
   * List experiments for channel
   */
  public async listExperiments(channelId: string) {
    return prisma.experiment.findMany({
      where: { channelId },
      orderBy: { createdAt: 'desc' },
    });
  }
}

export const experimentService = new ExperimentService();
