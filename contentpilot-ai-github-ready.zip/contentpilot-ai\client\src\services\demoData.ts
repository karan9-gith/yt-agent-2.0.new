import { Channel, ChannelSettings, HealthReport, OverviewData, ReviewBundle } from '../types';

export const DEMO_CHANNEL_ID = 'demo-channel-alpha';

export const DEMO_CHANNELS: Channel[] = [
  {
    id: DEMO_CHANNEL_ID,
    name: 'ContentPilot AI Tech (Demo / Local)',
    niche: 'Artificial Intelligence & Robotics',
    targetAudience: 'Software Engineers and Tech Leaders',
    brandVoice: 'Authoritative, analytical, and visionary (Demo / Local)',
    visualStyle: 'Sleek dark tech with amber cybernetic accents',
    defaultLanguage: 'en',
    timezone: 'UTC',
    settings: {
      id: 'settings-demo-1',
      channelId: DEMO_CHANNEL_ID,
      autoPublish: false,
      requireHumanApproval: true,
      automationEnabled: true,
      researchEnabled: true,
      generationEnabled: true,
      autoPublishEnabled: false,
      publishingCadence: 'daily',
      preferredPublishTime: '18:00',
      timezone: 'UTC',
      maxVideosPerDay: 1,
      maxConcurrentJobs: 1,
      targetDurationSec: 480,
      defaultFormat: 'explainer',
      bannedTopics: 'unverified gossip, crypto scams',
      excludedKeywords: 'cheap, fast hack',
      contentPillars: 'AI Architecture, Autonomous Agents, Neural Systems',
    },
  },
];

export const DEMO_OVERVIEW_DATA: OverviewData = {
  activeJobsCount: 0,
  failedJobsCount: 0,
  queuedJobsCount: 1,
  awaitingApprovalCount: 1,
  scheduledVideosCount: 1,
  publishedVideosCount: 0,
  recentProjects: [
    {
      id: 'proj-demo-101',
      title: '[Demo / Local] Inside Autonomous Multi-Agent Media Pipelines',
      status: 'AWAITING_APPROVAL',
      currentStage: 'Human Approval Gate',
      updatedAt: new Date(Date.now() - 3600000).toISOString(),
    },
    {
      id: 'proj-demo-102',
      title: '[Demo / Local] Real-Time State Machine Orchestration in Video AI',
      status: 'QC_PASSED',
      currentStage: 'Quality Control (QC)',
      updatedAt: new Date(Date.now() - 86400000).toISOString(),
    },
  ],
  analytics: {
    hasData: true,
    totalViews: 12450,
    totalWatchTimeMinutes: 3820,
    totalLikes: 890,
    totalComments: 142,
    videoCount: 4,
  },
  automation: {
    autoPublish: false,
    requireHumanApproval: true,
    defaultPrivacy: 'public',
    schedulerRunning: true,
    workerRunning: true,
    channelAutomationEnabled: true,
    publishingCadence: 'daily',
  },
  systemStatus: {
    geminiConfigured: false,
    youtubeConnected: false,
    databaseConnected: true,
    storageConfigured: true,
  },
};

export const DEMO_REVIEW_BUNDLE: ReviewBundle = {
  project: {
    id: 'proj-demo-101',
    title: '[Demo / Local] Inside Autonomous Multi-Agent Media Pipelines',
    status: 'AWAITING_APPROVAL',
    currentStage: 'Human Approval Gate',
    format: 'explainer',
  },
  video: {
    exists: true,
    masterPath: '/storage/renders/demo_master.mp4',
    fileSize: 42188400,
    durationSec: 120,
    resolution: '1920x1080',
    codec: 'h264/aac',
  },
  thumbnail: {
    variantId: 'thumb-var-1',
    assetPath: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    prompt: 'High-contrast cinematic cybernetic intelligence node with amber accent lighting [Demo / Local]',
    composition: 'Rule of thirds, bold headline on left, glowing node on right',
  },
  metadata: {
    title: '[Demo / Local] Inside Autonomous Multi-Agent Media Pipelines',
    description: 'A deep-dive engineering breakdown of how autonomous multi-agent pipelines operate with state machine governance.\n\n0:00 - Introduction\n0:10 - The Anatomy of Autonomy\n0:55 - State Machine Safety\n\n#AIAgents #Engineering #Automation [Demo / Local]',
    tags: ['ai agents', 'youtube automation', 'state machines', 'software engineering'],
    chapters: [
      { timestamp: '00:00', title: 'Introduction' },
      { timestamp: '00:10', title: 'The Anatomy of Autonomy' },
      { timestamp: '00:55', title: 'State Machine Safety' },
    ],
    primaryKeyword: 'autonomous AI agents',
  },
  script: {
    id: 'script-demo-1',
    version: 1,
    hookText: 'Most developers believe AI agents are just simple API wrappers—until you see what happens inside an autonomous multi-agent pipeline [Demo / Local].',
    sections: [
      {
        type: 'INTRO',
        title: 'The Anatomy of Real Autonomy [Demo / Local]',
        narration: 'In this breakdown, we examine the fundamental differences between experimental toy agents and resilient enterprise architectures.',
        visualCue: 'Architectural schematic showing isolated worker pools and persistent SQLite job queues.',
      },
      {
        type: 'MAIN_CONTENT',
        title: 'State Machine Governance [Demo / Local]',
        narration: 'By strictly enforcing immutable state transitions, we guarantee that no publishing operation can ever bypass human editorial review.',
        visualCue: 'State machine diagram transitioning from QC_PASSED to AWAITING_APPROVAL with a locked gate icon.',
      },
    ],
    ctaText: 'Subscribe to ContentPilot AI for weekly architectural breakdowns.',
    outroText: 'Thanks for watching, and see you in the next architectural breakdown.',
    claims: [
      {
        claim: 'State machines eliminate race conditions in multi-agent publishing workflows.',
        confidence: 0.95,
        sourceUrl: 'https://en.wikipedia.org/wiki/Finite-state_machine',
      },
    ],
  },
  research: {
    sources: [
      { title: 'Autonomous Multi-Agent Architectures', url: 'https://arxiv.org/abs/2308.08155', platform: 'arXiv', authority: 95 },
      { title: 'Google DeepMind Research Insights', url: 'https://deepmind.google/discover/blog/', platform: 'Google DeepMind', authority: 98 },
    ],
  },
  qualityControl: {
    id: 'qc-demo-1',
    status: 'passed',
    passed: true,
    overallScore: 98.0,
    loudnessLufs: -14.2,
    blackFrameDetected: false,
    audioVideoDriftSec: 0.02,
    findings: [
      { rule: 'EBU R128 Loudness', severity: 'INFO', passed: true, message: 'Loudness measured at -14.2 LUFS (Target: -14.0 ± 1.0) [Demo / Local]' },
      { rule: 'Black Frame Detection', severity: 'CRITICAL', passed: true, message: 'No black frames detected [Demo / Local]' },
      { rule: 'Audio/Video Drift', severity: 'WARNING', passed: true, message: 'Drift measured at +0.02s (Threshold: ±0.20s) [Demo / Local]' },
    ],
  },
  rightsAndProvenance: {
    id: 'rp-demo-1',
    status: 'cleared',
    syntheticMediaFlag: true,
    factualClaimsChecked: 3,
    unsupportedClaimsCount: 0,
    copyrightRiskScore: 0.04,
    disclaimerNotes: 'Contains synthetic narration and AI-assisted scene concepts. Factual claims grounded by research citations [Demo / Local].',
  },
  approval: {
    id: 'appr-demo-1',
    status: 'WAITING_APPROVAL',
    version: 1,
    approvedBy: null,
    approvedAt: null,
    reviewerNotes: null,
  },
  logs: {
    stateTransitions: [
      { from: 'QC_IN_PROGRESS', to: 'QC_PASSED', trigger: 'system', timestamp: new Date(Date.now() - 7200000).toISOString() },
      { from: 'QC_PASSED', to: 'AWAITING_APPROVAL', trigger: 'system', timestamp: new Date(Date.now() - 3600000).toISOString() },
    ],
    autoFixActions: [
      { error: 'Temporary loudness variance', classification: 'LOUDNESS', fix: 'Applied dynamic two-pass normalization', result: 'RESOLVED', timestamp: new Date(Date.now() - 7200000).toISOString() },
    ],
  },
};

export const DEMO_HEALTH_REPORT: HealthReport = {
  status: 'healthy',
  timestamp: new Date().toISOString(),
  totalDurationMs: 14,
  governance: {
    autoPublish: false,
    requireHumanApproval: true,
  },
  components: [
    {
      name: 'Client Frontend Application',
      status: 'healthy',
      message: 'Running ContentPilot AI Client (Demo / Local Offline Mode)',
      details: { mode: 'DEMO_OFFLINE' },
    },
    {
      name: 'Backend API Connection',
      status: 'not_configured',
      message: 'Backend not connected — Running in client Demo / Local mode',
    },
    {
      name: 'Google Gemini Provider',
      status: 'not_configured',
      message: 'GEMINI_API_KEY is not configured (Local Demo Provider active)',
    },
    {
      name: 'YouTube OAuth v3',
      status: 'not_configured',
      message: 'YouTube connection is not configured yet.',
    },
    {
      name: 'Governance Enforcement Gate',
      status: 'healthy',
      message: 'HUMAN APPROVAL strictly enforced; AUTO-PUBLISH disabled by default',
    },
  ],
};

export const DEMO_RESEARCH_RUNS = [
  {
    id: 'res-demo-1',
    channelId: DEMO_CHANNEL_ID,
    niche: 'Artificial Intelligence & Autonomous Systems',
    status: 'completed',
    ideasCount: 3,
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    ideas: [
      {
        id: 'idea-demo-1',
        topic: '[Demo / Local] How Autonomous AI Agents Are Transforming Software Engineering',
        angle: 'Deep dive into multi-agent workflows with state machines [Demo / Local]',
        trendScore: 92.5,
        searchIntent: 'informational',
        competitionScore: 45.0,
        status: 'ACCEPTED',
      },
      {
        id: 'idea-demo-2',
        topic: '[Demo / Local] Building Resilient Self-Healing Pipelines in 2025',
        angle: 'Practical architectural patterns for state machines and backoff retry queues [Demo / Local]',
        trendScore: 89.0,
        searchIntent: 'practical guide',
        competitionScore: 50.0,
        status: 'GENERATED',
      },
    ],
  },
];

export const DEMO_CONTENT_IDEAS = [
  {
    id: 'idea-demo-1',
    channelId: DEMO_CHANNEL_ID,
    topic: '[Demo / Local] How Autonomous AI Agents Are Transforming Software Engineering',
    angle: 'Engineering deep-dive comparing multi-agent architectures with zero simulated mocks [Demo / Local]',
    trendScore: 92.5,
    searchIntent: 'informational',
    competitionScore: 45.0,
    noveltyScore: 88.0,
    evergreenScore: 85.0,
    riskScore: 10.0,
    recommendedFormat: 'explainer',
    status: 'ACCEPTED',
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: 'idea-demo-2',
    channelId: DEMO_CHANNEL_ID,
    topic: '[Demo / Local] Building Resilient Self-Healing Pipelines in 2025',
    angle: 'Practical architectural patterns for state machines and backoff retry queues [Demo / Local]',
    trendScore: 89.0,
    searchIntent: 'practical guide',
    competitionScore: 50.0,
    noveltyScore: 84.0,
    evergreenScore: 90.0,
    riskScore: 8.0,
    recommendedFormat: 'explainer',
    status: 'REVIEWED',
    createdAt: new Date(Date.now() - 43200000).toISOString(),
  },
];

export const DEMO_STRATEGIES = [
  {
    id: 'strat-demo-1',
    channelId: DEMO_CHANNEL_ID,
    titleConcept: '[Demo / Local] Inside Production Multi-Agent Systems',
    hook: 'Most developers believe AI agents are simple API wrappers—until you see what happens inside an autonomous multi-agent pipeline [Demo / Local].',
    angle: 'Engineering deep dive into multi-agent systems [Demo / Local]',
    primaryKeyword: 'autonomous AI agents',
    secondaryKeywords: ['multi-agent orchestration', 'AI automation'],
    expectedKpi: 'retention',
    status: 'ACTIVE',
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
];

export const DEMO_SCRIPTS = [
  {
    id: 'script-demo-1',
    channelId: DEMO_CHANNEL_ID,
    title: '[Demo / Local] Inside Autonomous Multi-Agent Media Pipelines',
    version: 1,
    wordCount: 180,
    estimatedDurationSec: 120,
    hookText: 'Most developers believe AI agents are just simple API wrappers—until you see what happens inside an autonomous multi-agent pipeline [Demo / Local].',
    sectionsJson: JSON.stringify([
      {
        type: 'INTRO',
        label: 'The Anatomy of Real Autonomy [Demo / Local]',
        narrationText: 'In this breakdown, we examine the fundamental differences between experimental toy agents and resilient enterprise architectures.',
        visualDescription: 'Architectural schematic showing isolated worker pools and persistent SQLite job queues.',
        targetDurationSec: 45,
      },
      {
        type: 'MAIN_CONTENT',
        label: 'State Machine Governance [Demo / Local]',
        narrationText: 'By strictly enforcing immutable state transitions, we guarantee that no publishing operation can ever bypass human editorial review.',
        visualDescription: 'State machine diagram transitioning from QC_PASSED to AWAITING_APPROVAL with a locked gate icon.',
        targetDurationSec: 60,
      },
    ]),
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
];

export const DEMO_THUMBNAILS = [
  {
    id: 'thumb-demo-1',
    channelId: DEMO_CHANNEL_ID,
    title: '[Demo / Local] High Contrast Cybernetic Intelligence Node',
    variants: [
      {
        id: 'thumb-var-1',
        label: 'Concept A (Amber Core)',
        prompt: 'High contrast cinematic 3D render of glowing cybernetic brain core [Demo / Local]',
        imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80',
        isSelected: true,
      },
      {
        id: 'thumb-var-2',
        label: 'Concept B (Neon Cyan)',
        prompt: 'Neon cybernetic schematic with glowing data streams [Demo / Local]',
        imageUrl: 'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&w=600&q=80',
        isSelected: false,
      },
    ],
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
];

export const DEMO_PRODUCTION_PROJECTS = [
  {
    id: 'proj-demo-101',
    channelId: DEMO_CHANNEL_ID,
    title: '[Demo / Local] Inside Autonomous Multi-Agent Media Pipelines',
    status: 'AWAITING_APPROVAL',
    currentStage: 'Human Approval Gate',
    format: 'explainer',
    renders: [
      {
        id: 'render-demo-1',
        status: 'completed',
        outputPath: '/storage/renders/demo_master.mp4',
        durationSec: 120,
        fileSize: 42188400,
        createdAt: new Date(Date.now() - 7200000).toISOString(),
      },
    ],
    scenes: [
      { sceneIndex: 0, label: 'Hook [Demo / Local]', durationSec: 10, narrationSegment: 'Opening hook segment' },
      { sceneIndex: 1, label: 'Architecture Breakdown [Demo / Local]', durationSec: 50, narrationSegment: 'Main architectural walkthrough' },
    ],
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 3600000).toISOString(),
  },
];

export const DEMO_PUBLISHING_QUEUE = [
  {
    id: 'pub-demo-1',
    projectId: 'proj-demo-101',
    channelId: DEMO_CHANNEL_ID,
    status: 'QUEUED',
    privacyStatus: 'public',
    scheduledPublishTime: new Date(Date.now() + 86400000).toISOString(),
    uploadAttempts: 0,
    project: {
      id: 'proj-demo-101',
      title: '[Demo / Local] Inside Autonomous Multi-Agent Media Pipelines',
      format: 'explainer',
    },
    createdAt: new Date(Date.now() - 3600000).toISOString(),
  },
];

export const DEMO_EXPERIMENTS = [
  {
    id: 'exp-demo-1',
    channelId: DEMO_CHANNEL_ID,
    title: '[Demo / Local] Thumbnail Contrast: Amber vs Cyan Core',
    type: 'thumbnail',
    status: 'COMPLETED',
    winner: 'Amber Core',
    confidence: 0.88,
    createdAt: new Date(Date.now() - 604800000).toISOString(),
  },
];

export const DEMO_LEARNING_INSIGHTS = [
  {
    id: 'learn-demo-1',
    channelId: DEMO_CHANNEL_ID,
    topic: '[Demo / Local] Audience Retention Peaks on Diagrammatic Walkthroughs',
    insight: 'Technical audiences sustain 82% retention when state machine graphs are demonstrated before code.',
    confidence: 0.91,
    evidenceSample: 'Analyzed across 4 simulated video cohorts [Demo / Local]',
    createdAt: new Date(Date.now() - 172800000).toISOString(),
  },
];

export const DEMO_SCHEDULER_TASKS = [
  {
    id: 'task-demo-1',
    channelId: DEMO_CHANNEL_ID,
    taskType: 'research',
    cronExpression: '0 9 * * 1-5',
    status: 'ACTIVE',
    lastRunAt: new Date(Date.now() - 86400000).toISOString(),
    nextRunAt: new Date(Date.now() + 86400000).toISOString(),
  },
  {
    id: 'task-demo-2',
    channelId: DEMO_CHANNEL_ID,
    taskType: 'approval_reminders',
    cronExpression: '0 10,16 * * *',
    status: 'ACTIVE',
    lastRunAt: new Date(Date.now() - 14400000).toISOString(),
    nextRunAt: new Date(Date.now() + 14400000).toISOString(),
  },
];

export const DEMO_PROVIDERS = [
  {
    id: 'prov-demo-1',
    name: 'gemini',
    providerType: 'text',
    isDefault: true,
    isEnabled: false,
    hasServerSideKey: false,
    config: { model: 'gemini-2.5-flash', mode: 'Local Demo Fallback Active' },
  },
  {
    id: 'prov-demo-2',
    name: 'youtube',
    providerType: 'distribution',
    isDefault: true,
    isEnabled: false,
    hasServerSideKey: false,
    config: { status: 'YouTube connection is not configured yet.' },
  },
  {
    id: 'prov-demo-3',
    name: 'openai',
    providerType: 'text',
    isDefault: false,
    isEnabled: false,
    hasServerSideKey: false,
    config: { model: 'gpt-4o-mini' },
  },
];

export const DEMO_LOGS = {
  system: [
    { id: 'log-1', timestamp: new Date(Date.now() - 600000).toISOString(), level: 'info', message: '[Demo / Local] Operating in zero-config offline mode. All components running locally.' },
    { id: 'log-2', timestamp: new Date(Date.now() - 1200000).toISOString(), level: 'info', message: '[Demo / Local] Human approval gate strictly active: AUTO_PUBLISH=false.' },
  ],
  audit: [
    { id: 'audit-1', timestamp: new Date(Date.now() - 3600000).toISOString(), action: 'PIPELINE_TRANSITION', targetId: 'proj-demo-101', performedBy: 'system', details: 'Transitioned from QC_PASSED to AWAITING_APPROVAL [Demo / Local]' },
  ],
  autofix: [
    { id: 'fix-1', timestamp: new Date(Date.now() - 7200000).toISOString(), error: 'Loudness outside target LUFS threshold', classification: 'LOUDNESS', fix: 'Applied dynamic two-pass normalization', result: 'RESOLVED [Demo / Local]' },
  ],
};
