import { z } from 'zod';

export interface AICompletionOptions {
  model?: string;
  temperature?: number;
  maxTokens?: number;
  systemInstruction?: string;
}

export interface ITextProvider {
  readonly providerName: string;
  generateText(prompt: string, options?: AICompletionOptions): Promise<string>;
  generateStructured<T>(
    prompt: string,
    schema: z.ZodSchema<T>,
    options?: AICompletionOptions
  ): Promise<T>;
}

export interface ImageGenerationOptions {
  prompt: string;
  width?: number;
  height?: number;
  aspectRatio?: '16:9' | '9:16' | '1:1';
}

export interface IImageProvider {
  readonly providerName: string;
  generateImage(options: ImageGenerationOptions): Promise<Buffer>;
}

export interface TTSGenerationOptions {
  text: string;
  voiceId?: string;
  speed?: number;
  outputPath: string;
}

export interface ITTSProvider {
  readonly providerName: string;
  synthesizeToFile(options: TTSGenerationOptions): Promise<{ durationSec: number; filePath: string }>;
}

export interface IAIService {
  text: ITextProvider;
  image: IImageProvider;
  tts: ITTSProvider;
}
