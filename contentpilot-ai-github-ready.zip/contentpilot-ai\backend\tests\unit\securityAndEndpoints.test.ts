import { describe, it, expect, beforeEach } from 'vitest';
import path from 'node:path';
import fs from 'node:fs/promises';
import { SecurityGuard } from '../../src/utils/security.js';
import { prisma } from '../../src/database/client.js';
import { config } from '../../src/config/index.js';
import app from '../../src/index.js';

describe('Security Hardening & Endpoint Protection Suite', () => {
  describe('Path Traversal & Sandbox Isolation', () => {
    it('should block directory traversal sequences attempting to escape storage sandbox', () => {
      const maliciousPaths = [
        '../../etc/passwd',
        '..\\..\\Windows\\System32\\cmd.exe',
        path.resolve(config.STORAGE_DIR, '..', 'secret.env'),
        'C:\\Windows\\System32',
        '/etc/shadow',
      ];

      for (const p of maliciousPaths) {
        expect(() => SecurityGuard.validatePathWithinStorage(p)).toThrow(/Security Violation/);
      }
    });

    it('should permit valid paths strictly within storage directory', () => {
      const validPath = path.join(config.STORAGE_DIR, 'projects', 'test_proj', 'video.mp4');
      const resolved = SecurityGuard.validatePathWithinStorage(validPath);
      expect(resolved).toBe(path.resolve(validPath));
    });
  });

  describe('SSRF (Server-Side Request Forgery) Prevention', () => {
    it('should block localhost and internal private network IPs', () => {
      const internalUrls = [
        'http://127.0.0.1/admin',
        'http://localhost:8080/metrics',
        'http://169.254.169.254/latest/meta-data/', // AWS / GCP metadata
        'http://10.0.0.1/internal',
        'http://192.168.1.1/router',
        'http://172.16.0.5/api',
      ];

      for (const u of internalUrls) {
        expect(() => SecurityGuard.validateSafeExternalUrl(u)).toThrow(/Security Violation.*blocked/);
      }
    });

    it('should block dangerous non-HTTP/HTTPS protocols', () => {
      const dangerousProtocols = [
        'file:///etc/passwd',
        'ftp://example.com/file',
        'gopher://example.com',
      ];

      for (const u of dangerousProtocols) {
        expect(() => SecurityGuard.validateSafeExternalUrl(u)).toThrow(/Prohibited protocol/);
      }
    });

    it('should allow valid public HTTPS URLs', () => {
      const safe = SecurityGuard.validateSafeExternalUrl('https://youtube.com/watch?v=123');
      expect(safe.hostname).toBe('youtube.com');
    });
  });

  describe('Media Magic Byte Validation', () => {
    it('should validate MP4 ftyp box correctly', async () => {
      const testFile = path.join(config.STORAGE_DIR, 'test_magic.mp4');
      await fs.mkdir(config.STORAGE_DIR, { recursive: true });
      // Write 4 blank bytes + 'ftyp' + 8 more bytes
      const mp4Header = Buffer.concat([Buffer.from([0, 0, 0, 20]), Buffer.from('ftypmp42'), Buffer.alloc(8)]);
      await fs.writeFile(testFile, mp4Header);

      try {
        const isValid = await SecurityGuard.validateMediaFileMagicBytes(testFile, 'mp4');
        expect(isValid).toBe(true);

        const isPng = await SecurityGuard.validateMediaFileMagicBytes(testFile, 'png');
        expect(isPng).toBe(false);
      } finally {
        await fs.unlink(testFile).catch(() => {});
      }
    });

    it('should validate PNG magic bytes', async () => {
      const testFile = path.join(config.STORAGE_DIR, 'test_magic.png');
      const pngHeader = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 0, 0, 0, 0, 0]);
      await fs.writeFile(testFile, pngHeader);

      try {
        const isValid = await SecurityGuard.validateMediaFileMagicBytes(testFile, 'png');
        expect(isValid).toBe(true);
      } finally {
        await fs.unlink(testFile).catch(() => {});
      }
    });
  });

  describe('Untrusted AI Text Output Sanitization', () => {
    it('should strip null bytes and escape control characters from AI responses', () => {
      const dirty = 'Safe Title\x00\x08with control characters\x1b[31m and ANSI';
      const clean = SecurityGuard.sanitizeAiText(dirty);
      expect(clean).not.toContain('\x00');
      expect(clean).not.toContain('\x08');
      expect(clean.startsWith('Safe Title')).toBe(true);
    });
  });

  describe('Core API Endpoints & Health Probe', () => {
    let server: any;
    let baseUrl: string;

    beforeEach(async () => {
      if (!server) {
        await new Promise<void>((resolve) => {
          server = app.listen(0, () => {
            const addr = server.address();
            const port = typeof addr === 'string' ? 0 : addr.port;
            baseUrl = `http://127.0.0.1:${port}`;
            resolve();
          });
        });
      }
    });

    it('GET /health/detailed should inspect all 8 subsystems', async () => {
      const res = await fetch(`${baseUrl}/health/detailed`);
      const json = await res.json();

      expect(json.success).toBe(true);
      expect(json.components).toHaveLength(8);

      const componentNames = json.components.map((c: any) => c.name);
      expect(componentNames).toContain('Backend Core');
      expect(componentNames).toContain('Database (SQLite/WAL)');
      expect(componentNames).toContain('Google Gemini');
      expect(componentNames).toContain('YouTube OAuth v3');
      expect(componentNames).toContain('FFmpeg Media Engine');
      expect(componentNames).toContain('Storage Subsystem');
      expect(componentNames).toContain('Persistent Scheduler');
      expect(componentNames).toContain('Background Job Worker');
    });

    it('GET /api/overview should return live zero-faking telemetry', async () => {
      const res = await fetch(`${baseUrl}/api/overview`);
      const json = await res.json();

      expect(json.success).toBe(true);
      expect(typeof json.data.activeJobsCount).toBe('number');
      expect(typeof json.data.awaitingApprovalCount).toBe('number');
      expect(json.data.automation.requireHumanApproval).toBe(true);
      expect(json.data.automation.autoPublish).toBe(true);
    });

    it('GET /api/media/file should reject path traversal with 403', async () => {
      const res = await fetch(`${baseUrl}/api/media/file?path=../../package.json`);
      expect(res.status).toBe(403);
      const json = await res.json();
      expect(json.success).toBe(false);
      expect(json.error).toMatch(/Access denied/);
    });

    it('GET /api/providers should never leak server-side secrets or tokens', async () => {
      const res = await fetch(`${baseUrl}/api/providers`);
      const json = await res.json();

      expect(json.success).toBe(true);
      for (const p of json.data) {
        expect(p.config.apiKey).toBeUndefined();
        expect(p.config.apiToken).toBeUndefined();
        expect(p.config.secret).toBeUndefined();
      }
    });

    it('GET /api/youtube/callback and /api/auth/youtube/callback should handle OAuth redirect flows', async () => {
      // 1. Missing parameters test
      const res1 = await fetch(`${baseUrl}/api/youtube/callback`);
      expect(res1.status).toBe(400);
      const html1 = await res1.text();
      expect(html1).toContain('Missing OAuth Code or Channel ID');

      // 2. OAuth error parameter test
      const res2 = await fetch(`${baseUrl}/api/youtube/callback?error=access_denied`);
      expect(res2.status).toBe(400);
      const html2 = await res2.text();
      expect(html2).toContain('Authentication Cancelled');

      // 3. Alternate mounted path /api/auth/youtube/callback should resolve identically
      const res3 = await fetch(`${baseUrl}/api/auth/youtube/callback`);
      expect(res3.status).toBe(400);
      const html3 = await res3.text();
      expect(html3).toContain('Missing OAuth Code or Channel ID');
    });

    it('CORS headers should reflect allowed origin', async () => {
      const res = await fetch(`${baseUrl}/health`, {
        headers: {
          Origin: 'http://localhost:5173',
        },
      });
      expect(res.status).toBe(200);
      expect(res.headers.get('access-control-allow-origin')).toBe('http://localhost:5173');
    });
  });
});
