import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '../database/client.js';
import { AppError } from '../utils/errors.js';

const router = Router();
const param = (p: string | string[]): string => (Array.isArray(p) ? p[0] : p);

// GET all channels
router.get('/channels', async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const channels = await prisma.channel.findMany({
      include: { settings: true },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    res.json({ success: true, count: channels.length, data: channels });
  } catch (err) {
    next(err);
  }
});

// POST create channel
router.post('/channels', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { name, niche, targetAudience, brandVoice, visualStyle, defaultLanguage, timezone } = req.body;
    if (!name || !niche) {
      res.status(400).json({ success: false, error: 'Fields "name" and "niche" are required' });
      return;
    }

    // Find or create default user
    let user = await prisma.user.findFirst();
    if (!user) {
      user = await prisma.user.create({
        data: {
          email: 'admin@contentpilot.ai',
          name: 'ContentPilot Admin',
          role: 'admin',
        },
      });
    }

    const channel = await prisma.channel.create({
      data: {
        userId: user.id,
        name,
        niche,
        targetAudience: targetAudience || 'YouTube Audience',
        brandVoice: brandVoice || 'Authoritative & Engaging',
        visualStyle: visualStyle || 'Modern Dark Tech',
        defaultLanguage: defaultLanguage || 'en',
        timezone: timezone || 'UTC',
      },
    });

    const settings = await prisma.channelSetting.create({
      data: {
        channelId: channel.id,
        autoPublish: false,
        requireHumanApproval: true,
        automationEnabled: false,
        publishingCadence: 'weekly',
      },
    });

    res.json({ success: true, data: { ...channel, settings } });
  } catch (err) {
    next(err);
  }
});

// GET channel settings
router.get('/:channelId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = param(req.params.channelId);
    let channel = await prisma.channel.findUnique({
      where: { id: channelId },
      include: { settings: true },
    });

    if (!channel) {
      throw new AppError('Channel not found', 404, 'NOT_FOUND');
    }

    if (!channel.settings) {
      const settings = await prisma.channelSetting.create({
        data: {
          channelId: channel.id,
          autoPublish: false,
          requireHumanApproval: true,
          automationEnabled: false,
        },
      });
      channel = { ...channel, settings };
    }

    res.json({ success: true, data: channel });
  } catch (err) {
    next(err);
  }
});

// PUT update channel and settings
router.put('/:channelId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = param(req.params.channelId);
    const {
      name,
      niche,
      targetAudience,
      brandVoice,
      visualStyle,
      defaultLanguage,
      timezone,
      settings: newSettings,
    } = req.body;

    const channel = await prisma.channel.update({
      where: { id: channelId },
      data: {
        name,
        niche,
        targetAudience,
        brandVoice,
        visualStyle,
        defaultLanguage,
        timezone,
      },
    });

    if (newSettings) {
      // NOTE: autoPublish CAN be set via explicit channel settings if allowed,
      // but REQUIRE_HUMAN_APPROVAL must remain true by default unless explicitly modified by admin
      await prisma.channelSetting.upsert({
        where: { channelId },
        create: {
          channelId,
          autoPublish: newSettings.autoPublish ?? false,
          requireHumanApproval: newSettings.requireHumanApproval ?? true,
          automationEnabled: newSettings.automationEnabled ?? false,
          researchEnabled: newSettings.researchEnabled ?? true,
          generationEnabled: newSettings.generationEnabled ?? true,
          autoPublishEnabled: newSettings.autoPublishEnabled ?? false,
          publishingCadence: newSettings.publishingCadence ?? 'weekly',
          preferredPublishTime: newSettings.preferredPublishTime ?? '14:00',
          timezone: newSettings.timezone ?? 'UTC',
          maxVideosPerDay: Number(newSettings.maxVideosPerDay ?? 1),
          maxConcurrentJobs: Number(newSettings.maxConcurrentJobs ?? 2),
          targetDurationSec: Number(newSettings.targetDurationSec ?? 480),
          defaultFormat: newSettings.defaultFormat ?? 'explainer',
          bannedTopics: JSON.stringify(newSettings.bannedTopics || []),
          excludedKeywords: JSON.stringify(newSettings.excludedKeywords || []),
          contentPillars: JSON.stringify(newSettings.contentPillars || []),
        },
        update: {
          autoPublish: newSettings.autoPublish !== undefined ? newSettings.autoPublish : undefined,
          requireHumanApproval:
            newSettings.requireHumanApproval !== undefined ? newSettings.requireHumanApproval : undefined,
          automationEnabled:
            newSettings.automationEnabled !== undefined ? newSettings.automationEnabled : undefined,
          researchEnabled: newSettings.researchEnabled !== undefined ? newSettings.researchEnabled : undefined,
          generationEnabled:
            newSettings.generationEnabled !== undefined ? newSettings.generationEnabled : undefined,
          autoPublishEnabled:
            newSettings.autoPublishEnabled !== undefined ? newSettings.autoPublishEnabled : undefined,
          publishingCadence: newSettings.publishingCadence,
          preferredPublishTime: newSettings.preferredPublishTime,
          timezone: newSettings.timezone,
          maxVideosPerDay:
            newSettings.maxVideosPerDay !== undefined ? Number(newSettings.maxVideosPerDay) : undefined,
          maxConcurrentJobs:
            newSettings.maxConcurrentJobs !== undefined ? Number(newSettings.maxConcurrentJobs) : undefined,
          targetDurationSec:
            newSettings.targetDurationSec !== undefined ? Number(newSettings.targetDurationSec) : undefined,
          defaultFormat: newSettings.defaultFormat,
          bannedTopics: newSettings.bannedTopics ? JSON.stringify(newSettings.bannedTopics) : undefined,
          excludedKeywords: newSettings.excludedKeywords
            ? JSON.stringify(newSettings.excludedKeywords)
            : undefined,
          contentPillars: newSettings.contentPillars
            ? JSON.stringify(newSettings.contentPillars)
            : undefined,
        },
      });
    }

    const updated = await prisma.channel.findUnique({
      where: { id: channelId },
      include: { settings: true },
    });

    res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
});

export default router;
