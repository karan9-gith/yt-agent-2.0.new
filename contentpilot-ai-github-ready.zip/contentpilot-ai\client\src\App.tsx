import React, { useEffect, useState, useCallback } from 'react';
import { api, ConnectionState } from './services/api';
import { Channel, PageId } from './types';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';

// 19 Pages
import { OverviewPage } from './pages/OverviewPage';
import { AutonomousOperatorPage } from './pages/AutonomousOperatorPage';
import { ResearchPage } from './pages/ResearchPage';
import { ContentIdeasPage } from './pages/ContentIdeasPage';
import { StrategyPage } from './pages/StrategyPage';
import { ScriptsPage } from './pages/ScriptsPage';
import { ThumbnailsPage } from './pages/ThumbnailsPage';
import { ProductionPage } from './pages/ProductionPage';
import { ReviewStudioPage } from './pages/ReviewStudioPage';
import { PublishingQueuePage } from './pages/PublishingQueuePage';
import { YouTubeChannelPage } from './pages/YouTubeChannelPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { ExperimentsPage } from './pages/ExperimentsPage';
import { LearningPage } from './pages/LearningPage';
import { SchedulerPage } from './pages/SchedulerPage';
import { ProvidersPage } from './pages/ProvidersPage';
import { SettingsPage } from './pages/SettingsPage';
import { LogsPage } from './pages/LogsPage';
import { SystemHealthPage } from './pages/SystemHealthPage';

const VALID_PAGES: PageId[] = [
  'overview',
  'operator',
  'research',
  'ideas',
  'strategy',
  'scripts',
  'thumbnails',
  'production',
  'review',
  'publishing',
  'youtube',
  'analytics',
  'experiments',
  'learning',
  'scheduler',
  'providers',
  'settings',
  'logs',
  'health',
];

function getPageFromPathname(pathname: string): PageId {
  const clean = pathname.replace(/^\/+|\/+$/g, '').toLowerCase();
  if (!clean || clean === 'dashboard' || clean === 'overview') {
    return 'overview';
  }
  if (VALID_PAGES.includes(clean as PageId)) {
    return clean as PageId;
  }
  return 'overview';
}

export const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<PageId>(() =>
    getPageFromPathname(window.location.pathname)
  );
  const [channels, setChannels] = useState<Channel[]>([]);
  const [selectedChannelId, setSelectedChannelId] = useState<string>('');
  const [pendingApprovalsCount, setPendingApprovalsCount] = useState<number>(0);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [initLoading, setInitLoading] = useState<boolean>(true);
  const [connection, setConnection] = useState<ConnectionState>(() =>
    api.getConnectionState()
  );

  // Sync with browser URL popstate (Back/Forward buttons)
  useEffect(() => {
    const handlePopState = () => {
      const targetPage = getPageFromPathname(window.location.pathname);
      setCurrentPage(targetPage);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Listen to live backend connectivity state changes
  useEffect(() => {
    const unsubscribe = api.onConnectionChange((state) => {
      setConnection(state);
    });
    return () => unsubscribe();
  }, []);

  const handleNavigate = useCallback((page: PageId) => {
    setCurrentPage(page);
    const targetUrl = page === 'overview' ? '/' : `/${page}`;
    if (window.location.pathname !== targetUrl) {
      window.history.pushState(null, '', targetUrl);
    }
  }, []);

  useEffect(() => {
    initApp();
  }, []);

  useEffect(() => {
    if (selectedChannelId) {
      loadPendingCount();
    }
  }, [selectedChannelId]);

  const initApp = async () => {
    try {
      setInitLoading(true);
      let list = await api.getChannels();
      if (!list || list.length === 0) {
        const def = await api.createChannel({
          name: 'ContentPilot AI Tech (Demo / Local)',
          niche: 'Artificial Intelligence & Robotics',
          targetAudience: 'Software Engineers and Tech Leaders',
          brandVoice: 'Authoritative, analytical, and visionary',
          visualStyle: 'Sleek dark tech with cybernetic neon accents',
        });
        list = [def];
      }
      setChannels(list);
      setSelectedChannelId(list[0]?.id || '');
    } catch (err) {
      console.warn('Initialization using local demo fallback:', err);
    } finally {
      setInitLoading(false);
    }
  };

  const loadPendingCount = async () => {
    try {
      const pending = await api.getPendingApprovals(selectedChannelId);
      setPendingApprovalsCount(pending?.length || 0);
    } catch {
      // Ignore count fetch errors
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await loadPendingCount();
    setTimeout(() => setIsRefreshing(false), 400);
  };

  const renderActivePage = () => {
    switch (currentPage) {
      case 'overview':
        return <OverviewPage channelId={selectedChannelId} onNavigate={handleNavigate} />;
      case 'operator':
        return <AutonomousOperatorPage channelId={selectedChannelId} onNavigate={handleNavigate} />;
      case 'research':
        return <ResearchPage channelId={selectedChannelId} onNavigate={handleNavigate} />;
      case 'ideas':
        return <ContentIdeasPage channelId={selectedChannelId} onNavigate={handleNavigate} />;
      case 'strategy':
        return <StrategyPage channelId={selectedChannelId} onNavigate={handleNavigate} />;
      case 'scripts':
        return <ScriptsPage channelId={selectedChannelId} onNavigate={handleNavigate} />;
      case 'thumbnails':
        return <ThumbnailsPage channelId={selectedChannelId} onNavigate={handleNavigate} />;
      case 'production':
        return <ProductionPage channelId={selectedChannelId} onNavigate={handleNavigate} />;
      case 'review':
        return <ReviewStudioPage channelId={selectedChannelId} onNavigate={handleNavigate} />;
      case 'publishing':
        return <PublishingQueuePage channelId={selectedChannelId} onNavigate={handleNavigate} />;
      case 'youtube':
        return <YouTubeChannelPage channelId={selectedChannelId} onNavigate={handleNavigate} />;
      case 'analytics':
        return <AnalyticsPage channelId={selectedChannelId} onNavigate={handleNavigate} />;
      case 'experiments':
        return <ExperimentsPage channelId={selectedChannelId} onNavigate={handleNavigate} />;
      case 'learning':
        return <LearningPage channelId={selectedChannelId} onNavigate={handleNavigate} />;
      case 'scheduler':
        return <SchedulerPage channelId={selectedChannelId} onNavigate={handleNavigate} />;
      case 'providers':
        return <ProvidersPage />;
      case 'settings':
        return <SettingsPage channelId={selectedChannelId} onRefreshChannels={initApp} />;
      case 'logs':
        return <LogsPage channelId={selectedChannelId} />;
      case 'health':
        return <SystemHealthPage />;
      default:
        return <OverviewPage channelId={selectedChannelId} onNavigate={handleNavigate} />;
    }
  };

  if (initLoading) {
    return (
      <div
        style={{
          minHeight: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: 'var(--bg-main)',
          color: 'var(--text-secondary)',
          fontSize: '0.9rem',
        }}
      >
        Initializing ContentPilot AI Enterprise Operations Console...
      </div>
    );
  }

  return (
    <div className="app-container">
      {/* Sidebar Navigation */}
      <Sidebar
        currentPage={currentPage}
        onNavigate={handleNavigate}
        pendingApprovalsCount={pendingApprovalsCount}
      />

      {/* Main Content Area */}
      <div className="main-content">
        <Header
          channels={channels}
          selectedChannelId={selectedChannelId}
          onSelectChannel={setSelectedChannelId}
          onRefresh={handleRefresh}
          isRefreshing={isRefreshing}
          isBackendConnected={connection.isBackendConnected}
        />

        <main style={{ minHeight: 'calc(100vh - var(--header-height))' }}>
          {renderActivePage()}
        </main>
      </div>
    </div>
  );
};

export default App;
