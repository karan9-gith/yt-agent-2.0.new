import { persistentJobQueue } from './jobQueue.js';
import { JobHandler, JobHandlerContext, JobStatus } from './jobTypes.js';
import { logger } from '../utils/logger.js';
import { config } from '../config/index.js';
import os from 'node:os';

export class JobWorkerManager {
  private handlers = new Map<string, JobHandler>();
  private isRunning = false;
  private workerId: string;
  private pollTimer: NodeJS.Timeout | null = null;
  private heartbeatTimer: NodeJS.Timeout | null = null;
  private activeJobId: string | null = null;

  constructor() {
    this.workerId = `${os.hostname()}-${process.pid}-${Math.random().toString(36).slice(2, 7)}`;
  }

  public isWorkerRunning(): boolean {
    return this.isRunning;
  }

  /**
   * Register a handler for a given job type
   */
  public registerHandler(type: string, handler: JobHandler): void {
    this.handlers.set(type, handler);
    logger.info({ msg: 'Registered job handler', type });
  }

  /**
   * Start worker poll loop and recovery sweep
   */
  public async start(): Promise<void> {
    if (this.isRunning) return;
    this.isRunning = true;

    this.registerDefaultHandlers();

    logger.info({ msg: 'Starting persistent job worker', workerId: this.workerId });

    // Run crash recovery on startup
    try {
      const recoveredCount = await persistentJobQueue.recoverOrphanedJobs();
      if (recoveredCount > 0) {
        logger.info({ msg: `Recovered ${recoveredCount} orphaned jobs on boot` });
      }
    } catch (error) {
      logger.error({ msg: 'Crash recovery sweep on boot failed', error });
    }

    // Start background polling
    this.scheduleNextPoll(100);

    // Periodic heartbeat timer (every 15s)
    this.heartbeatTimer = setInterval(async () => {
      if (this.activeJobId) {
        try {
          await persistentJobQueue.updateHeartbeat(this.activeJobId);
        } catch {
          // Ignore heartbeat write errors
        }
      }
    }, 15000);
  }

  /**
   * Graceful shutdown of worker
   */
  public async stop(): Promise<void> {
    this.isRunning = false;
    if (this.pollTimer) clearTimeout(this.pollTimer);
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    logger.info({ msg: 'Job worker stopped', workerId: this.workerId });
  }

  private scheduleNextPoll(delayMs = config.JOB_WORKER_POLL_INTERVAL_MS): void {
    if (!this.isRunning) return;
    this.pollTimer = setTimeout(async () => {
      await this.pollAndExecute();
      this.scheduleNextPoll();
    }, delayMs);
  }

  private async pollAndExecute(): Promise<void> {
    if (this.activeJobId) return; // Currently busy

    try {
      const job = await persistentJobQueue.acquireNextJob(this.workerId);
      if (!job) return;

      this.activeJobId = job.id;
      const handler = this.handlers.get(job.type);

      if (!handler) {
        const errorMsg = `No registered handler for job type '${job.type}'`;
        logger.error({ msg: errorMsg, jobId: job.id });
        await persistentJobQueue.failOrRetryJob(job.id, errorMsg);
        this.activeJobId = null;
        return;
      }

      logger.info({ msg: 'Executing job', jobId: job.id, type: job.type });

      const context: JobHandlerContext = {
        jobId: job.id,
        reportProgress: async (update) => {
          await persistentJobQueue.updateProgress(job.id, update);
        },
        isCancelled: async () => {
          const fresh = await persistentJobQueue.getJob(job.id);
          return fresh.status === JobStatus.CANCELLED;
        },
        recordEvent: async (eventType, stage, message, data) => {
          await persistentJobQueue.recordEvent(job.id, eventType, stage, job.progress, message, data);
        },
      };

      const payload = JSON.parse(job.payloadJson || '{}');
      const result = await handler(payload, context);

      // Check if job transitioned to WAITING_APPROVAL inside handler
      const finalState = await persistentJobQueue.getJob(job.id);
      if (finalState.status !== JobStatus.WAITING_APPROVAL && finalState.status !== JobStatus.CANCELLED) {
        await persistentJobQueue.completeJob(job.id, (result as Record<string, unknown>) || undefined);
      }
    } catch (error) {
      if (this.activeJobId) {
        logger.error({ msg: 'Job execution error', jobId: this.activeJobId, error });
        await persistentJobQueue.failOrRetryJob(this.activeJobId, error as Error);
      }
    } finally {
      this.activeJobId = null;
    }
  }

  private registerDefaultHandlers(): void {
    if (!this.handlers.has('pipeline')) {
      this.registerHandler('pipeline', async (payload, context) => {
        await context.reportProgress({ progress: 10, stage: 'pipeline_init', message: 'Starting autonomous pipeline' });
        const { autonomousOperator } = await import('../services/operator/autonomousOperator.js');
        const channelId = payload.channelId as string;
        const existingProjectId = payload.projectId as string | undefined;
        const res = await autonomousOperator.run({ channelId, existingProjectId });
        return res as unknown as Record<string, unknown>;
      });
      const pipelineHandler = this.handlers.get('pipeline')!;
      this.registerHandler('CONTENT_PIPELINE', pipelineHandler);
    }

    if (!this.handlers.has('render')) {
      this.registerHandler('render', async (payload, context) => {
        await context.reportProgress({ progress: 20, stage: 'rendering', message: 'Executing video render' });
        const { autonomousOperator } = await import('../services/operator/autonomousOperator.js');
        const { prisma } = await import('../database/client.js');
        const projectId = payload.projectId as string;
        if (projectId) {
          const project = await prisma.videoProject.findUnique({ where: { id: projectId } });
          if (project) {
            const res = await autonomousOperator.run({
              channelId: project.channelId,
              existingProjectId: projectId,
            });
            return res as unknown as Record<string, unknown>;
          }
        }
        return { success: true };
      });
      const renderHandler = this.handlers.get('render')!;
      this.registerHandler('VIDEO_RENDER', renderHandler);
    }

    if (!this.handlers.has('research')) {
      this.registerHandler('research', async (payload, context) => {
        await context.reportProgress({ progress: 20, stage: 'research', message: 'Running research engine' });
        const { autonomousOperator } = await import('../services/operator/autonomousOperator.js');
        const channelId = payload.channelId as string;
        if (channelId) {
          const res = await autonomousOperator.run({ channelId });
          return res as unknown as Record<string, unknown>;
        }
        return { success: true };
      });
      const researchHandler = this.handlers.get('research')!;
      this.registerHandler('RESEARCH', researchHandler);
    }

    if (!this.handlers.has('visual')) {
      this.registerHandler('visual', async (payload, context) => {
        await context.reportProgress({ progress: 30, stage: 'visuals', message: 'Regenerating scene visuals' });
        const { autonomousOperator } = await import('../services/operator/autonomousOperator.js');
        const { prisma } = await import('../database/client.js');
        const projectId = payload.projectId as string;
        if (projectId) {
          const project = await prisma.videoProject.findUnique({ where: { id: projectId } });
          if (project) {
            const res = await autonomousOperator.run({
              channelId: project.channelId,
              existingProjectId: projectId,
            });
            return res as unknown as Record<string, unknown>;
          }
        }
        return { success: true };
      });
      const visualHandler = this.handlers.get('visual')!;
      this.registerHandler('VISUAL_ASSETS', visualHandler);
    }

    if (!this.handlers.has('analytics')) {
      this.registerHandler('analytics', async (payload, context) => {
        await context.reportProgress({ progress: 10, stage: 'analytics', message: 'Syncing channel analytics snapshots' });
        const { youtubeAnalyticsService } = await import('../services/analytics/youtubeAnalyticsService.js');
        const channelId = payload.channelId as string;
        if (channelId) {
          const count = await youtubeAnalyticsService.syncChannelVideos(channelId);
          return { syncedSnapshots: count };
        }
        return { success: true };
      });
      const analyticsHandler = this.handlers.get('analytics')!;
      this.registerHandler('ANALYTICS', analyticsHandler);
    }

    if (!this.handlers.has('learning')) {
      this.registerHandler('learning', async (payload, context) => {
        await context.reportProgress({ progress: 10, stage: 'learning', message: 'Running learning agent analysis' });
        const { learningAgent } = await import('../services/learning/learningAgent.js');
        const channelId = payload.channelId as string;
        if (channelId) {
          const insights = await learningAgent.analyzeChannel(channelId);
          return { insightsCount: insights.length };
        }
        return { success: true };
      });
      const learningHandler = this.handlers.get('learning')!;
      this.registerHandler('LEARNING', learningHandler);
    }
  }
}

export const jobWorkerManager = new JobWorkerManager();
