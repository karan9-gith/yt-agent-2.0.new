import { describe, it, expect, beforeEach } from 'vitest';
import { prisma } from '../../src/database/client.js';
import { reviewStudioService } from '../../src/services/approval/reviewStudioService.js';
import { VideoPipelineState } from '../../src/core/pipeline/stateTypes.js';

describe('Review Studio Backend & Editorial Actions', () => {
  let channelId: string;
  let projectId: string;
  let scriptId: string;
  let thumbnailVariantId: string;

  beforeEach(async () => {
    const user = await prisma.user.upsert({
      where: { email: 'review_studio@contentpilot.ai' },
      update: {},
      create: { email: 'review_studio@contentpilot.ai', name: 'Review Studio Lead' },
    });

    const channel = await prisma.channel.create({
      data: {
        userId: user.id,
        name: 'Review Studio Channel',
        niche: 'AI Systems',
        targetAudience: 'Architects',
        brandVoice: 'Authoritative',
        visualStyle: 'Sleek Dark',
      },
    });
    channelId = channel.id;

    // Create research run & sources
    const research = await prisma.researchRun.create({
      data: {
        channelId,
        niche: 'AI Systems',
        targetAudience: 'Architects',
        status: 'completed',
      },
    });

    await prisma.researchSource.create({
      data: {
        researchRunId: research.id,
        title: 'Deepmind Multi-Agent Research',
        url: 'https://arxiv.org/abs/2308.08155',
        authorityScore: 95.0,
        relevanceScore: 92.0,
      },
    });

    const strategy = await prisma.contentStrategy.create({
      data: {
        channelId,
        titleConcept: 'Review Studio Concept',
        hook: 'Watch how human governance works.',
        angle: 'Enterprise Governance',
        targetAudience: 'Architects',
        primaryKeyword: 'governance',
        cta: 'Subscribe',
        thumbnailConcept: 'Split screen',
        reasonForSelection: 'Editorial audit',
      },
    });

    const script = await prisma.script.create({
      data: {
        strategyId: strategy.id,
        channelId,
        title: 'Review Studio Demonstration Video',
        hookText: 'The human-in-the-loop review studio is live.',
        hookVisualCue: 'Studio dashboard interface',
        hookDurationSec: 10,
        sectionsJson: JSON.stringify([
          {
            label: 'Intro',
            narrationText: 'Review Studio provides 100% visibility over all generation artifacts.',
            targetDurationSec: 30,
          },
        ]),
        ctaText: 'Sign up for access.',
        ctaVisualCue: 'Watermark icon',
        outroText: 'See you next time.',
        outroVisualCue: 'End cards',
        wordCount: 150,
        estimatedDurationSec: 60,
      },
    });
    scriptId = script.id;

    const thumbnail = await prisma.thumbnail.create({
      data: {
        scriptId: script.id,
        channelId,
        status: 'generated',
      },
    });

    const variant = await prisma.thumbnailVariant.create({
      data: {
        thumbnailId: thumbnail.id,
        prompt: 'Studio control room mockup with illuminated approval button',
        composition: 'Cinematic center framing',
        subject: 'Approval Control',
        emotion: 'Authority',
        textOverlay: 'APPROVED',
        layout: 'Centered bold headline',
        visualHierarchy: 'Headline -> Key Art',
        contrastGuidance: 'Neon Amber on Charcoal',
        isSelected: true,
      },
    });
    thumbnailVariantId = variant.id;

    const seo = await prisma.seoPackage.create({
      data: {
        scriptId: script.id,
        channelId,
        recommendedTitle: 'Inside the AI Review Studio: Complete Human Governance',
        titleCandidatesJson: JSON.stringify([
          'Inside the AI Review Studio: Complete Human Governance',
          'Why Autonomous Channels Require Real Human Signoff',
          'The Review Studio Architecture Explained',
        ]),
        description: 'Comprehensive walkthrough of ContentPilot AI Review Studio governance.\n\n0:00 - Intro',
        chaptersJson: JSON.stringify([{ timestamp: '00:00', title: 'Intro' }]),
        tagsJson: JSON.stringify(['review studio', 'governance', 'ai automation']),
        hashtagsJson: JSON.stringify(['#ReviewStudio', '#AI']),
        primaryKeyword: 'review studio',
      },
    });

    const project = await prisma.videoProject.create({
      data: {
        channelId,
        title: 'Inside the AI Review Studio: Complete Human Governance',
        scriptId: script.id,
        thumbnailId: thumbnail.id,
        seoPackageId: seo.id,
        status: VideoPipelineState.AWAITING_APPROVAL,
      },
    });
    projectId = project.id;

    // Quality Check (PASS)
    await prisma.qualityCheck.create({
      data: {
        projectId,
        passed: true,
        overallScore: 98.0,
        loudnessLufs: -14.0,
        blackFrameDetected: false,
        audioVideoDriftSec: 0.0,
        status: 'PASS',
        findingsJson: JSON.stringify([
          { rule: 'Loudness Target', severity: 'INFO', passed: true, message: 'Meets -14 LUFS' },
        ]),
      },
    });

    // Rights Check
    await prisma.rightsCheck.create({
      data: {
        projectId,
        scriptId: script.id,
        factualClaimsChecked: 1,
        unsupportedClaimsCount: 0,
        syntheticMediaFlag: true,
        copyrightRiskScore: 0.05,
        status: 'PASS',
        disclaimerNotes: 'Synthetic media flagged and source citations linked.',
      },
    });

    // Approval Request
    await prisma.approvalRequest.create({
      data: {
        projectId,
        channelId,
        status: 'WAITING_APPROVAL',
        requestedBy: 'system',
        approvalVersion: 1,
      },
    });
  });

  it('should retrieve complete Review Studio bundle with all 11 required elements', async () => {
    const bundle = await reviewStudioService.getReviewBundle(projectId);

    // 1. video
    expect(bundle.video).toBeDefined();
    // 2. thumbnail
    expect(bundle.thumbnail.selectedVariant).not.toBeNull();
    expect(bundle.thumbnail.selectedVariant?.textOverlay).toBe('APPROVED');
    // 3. title
    expect(bundle.metadata.recommendedTitle).toBe('Inside the AI Review Studio: Complete Human Governance');
    // 4. description
    expect(bundle.metadata.description).toContain('Comprehensive walkthrough');
    // 5. tags
    expect(bundle.metadata.tags).toContain('review studio');
    // 6. chapters
    expect(bundle.metadata.chapters).toHaveLength(1);
    // 7. script
    expect(bundle.script?.hook).toBeDefined();
    // 8. research sources
    expect(bundle.researchSources).toHaveLength(1);
    expect(bundle.researchSources[0].title).toBe('Deepmind Multi-Agent Research');
    // 9. QC report
    expect(bundle.qcReport?.passed).toBe(true);
    expect(bundle.qcReport?.overallScore).toBe(98.0);
    // 10. rights/provenance report
    expect(bundle.rightsReport?.syntheticMediaFlag).toBe(true);
    // 11. generation logs
    expect(bundle.generationLogs).toBeDefined();
    // approval
    expect(bundle.approval.approvalStatus).toBe('WAITING_APPROVAL');
  });

  describe('Review Actions & Audit Logs', () => {
    it('ACTION APPROVE: should explicitly approve project and advance state machine with audit log', async () => {
      await reviewStudioService.approve(projectId, 'chief_editor@contentpilot.ai', 'Looks ready for prime time.');

      const project = await prisma.videoProject.findUnique({
        where: { id: projectId },
        include: { approvalRequests: { take: 1, orderBy: { createdAt: 'desc' } } },
      });

      expect(project?.status).toBe(VideoPipelineState.APPROVED);

      const approval = project?.approvalRequests[0];
      expect(approval?.status).toBe('APPROVED');
      expect(approval?.approvedBy).toBe('chief_editor@contentpilot.ai');
      expect(approval?.approvedAt).not.toBeNull();
      expect(approval?.approvalVersion).toBe(2);

      // Audit log entry must exist
      const auditLog = await prisma.auditLog.findFirst({
        where: { entityId: projectId, action: 'APPROVE' },
      });
      expect(auditLog).not.toBeNull();
      expect(auditLog?.afterJson).toContain('chief_editor@contentpilot.ai');
    });

    it('ACTION REJECT: should reject project and record reviewer reason in audit log', async () => {
      await reviewStudioService.reject(projectId, 'chief_editor@contentpilot.ai', 'Angle is saturated.');

      const approval = await prisma.approvalRequest.findFirst({
        where: { projectId },
        orderBy: { createdAt: 'desc' },
      });

      expect(approval?.status).toBe('REJECTED');
      expect(approval?.reviewerNotes).toBe('Angle is saturated.');

      const auditLog = await prisma.auditLog.findFirst({
        where: { entityId: projectId, action: 'REJECT' },
      });
      expect(auditLog).not.toBeNull();
      expect(auditLog?.afterJson).toContain('Angle is saturated.');
    });

    it('ACTION EDIT: should update title, description, and thumbnail variant', async () => {
      await reviewStudioService.edit(
        projectId,
        {
          title: 'Revised Better Title For Review Studio',
          tags: ['updated', 'tags'],
          selectedThumbnailVariantId: thumbnailVariantId,
        },
        'editor@contentpilot.ai'
      );

      const seo = await prisma.seoPackage.findUnique({ where: { scriptId } });
      expect(seo?.recommendedTitle).toBe('Revised Better Title For Review Studio');
      expect(JSON.parse(seo?.tagsJson || '[]')).toEqual(['updated', 'tags']);

      const auditLog = await prisma.auditLog.findFirst({
        where: { entityId: projectId, action: 'UPDATE' },
      });
      expect(auditLog).not.toBeNull();
    });

    it('ACTION SEND BACK: should roll back pipeline to requested stage and set CHANGES_REQUESTED', async () => {
      await reviewStudioService.sendBack(
        projectId,
        VideoPipelineState.SCRIPT_READY,
        'Please re-write hook with more tension.',
        'reviewer@contentpilot.ai'
      );

      const project = await prisma.videoProject.findUnique({ where: { id: projectId } });
      expect(project?.status).toBe(VideoPipelineState.SCRIPT_READY);

      const approval = await prisma.approvalRequest.findFirst({
        where: { projectId },
        orderBy: { createdAt: 'desc' },
      });
      expect(approval?.status).toBe('CHANGES_REQUESTED');
      expect(approval?.reviewerNotes).toContain('re-write hook');
    });

    it('ACTION SCHEDULE: should block scheduling if unapproved, and succeed once approved', async () => {
      const publishDate = new Date(Date.now() + 24 * 3600 * 1000);

      // Attempt to schedule UNAPPROVED project -> MUST THROW!
      await expect(
        reviewStudioService.schedule(projectId, publishDate, 'private', 'scheduler@contentpilot.ai')
      ).rejects.toThrow(/approved/i);

      // Now approve it first
      await reviewStudioService.approve(projectId, 'lead@contentpilot.ai');

      // Now schedule must succeed
      await reviewStudioService.schedule(projectId, publishDate, 'private', 'scheduler@contentpilot.ai');

      const project = await prisma.videoProject.findUnique({ where: { id: projectId } });
      expect(project?.status).toBe(VideoPipelineState.SCHEDULED);

      const queue = await prisma.publishingQueue.findUnique({ where: { projectId } });
      expect(queue?.status).toBe('QUEUED');
      expect(queue?.privacyStatus).toBe('private');
    });
  });
});
