import {
  Channel,
  ChannelSettings,
  HealthReport,
  OverviewData,
  ReviewBundle,
} from '../types';
import {
  DEMO_CHANNELS,
  DEMO_CHANNEL_ID,
  DEMO_OVERVIEW_DATA,
  DEMO_REVIEW_BUNDLE,
  DEMO_HEALTH_REPORT,
  DEMO_RESEARCH_RUNS,
  DEMO_CONTENT_IDEAS,
  DEMO_STRATEGIES,
  DEMO_SCRIPTS,
  DEMO_THUMBNAILS,
  DEMO_PRODUCTION_PROJECTS,
  DEMO_PUBLISHING_QUEUE,
  DEMO_EXPERIMENTS,
  DEMO_LEARNING_INSIGHTS,
  DEMO_SCHEDULER_TASKS,
  DEMO_PROVIDERS,
  DEMO_LOGS,
} from './demoData';

const BASE_URL = (import.meta.env.VITE_API_URL || '').replace(/\/+$/, '');

export interface ConnectionState {
  isBackendConnected: boolean;
  isDemoMode: boolean;
}

let connectionState: ConnectionState = {
  isBackendConnected: false,
  isDemoMode: false,
};

const connectionListeners: Array<(state: ConnectionState) => void> = [];

function updateConnection(connected: boolean) {
  const newState = {
    isBackendConnected: connected,
    isDemoMode: !connected,
  };
  if (
    connectionState.isBackendConnected !== newState.isBackendConnected ||
    connectionState.isDemoMode !== newState.isDemoMode
  ) {
    connectionState = newState;
    connectionListeners.forEach((fn) => {
      try {
        fn(connectionState);
      } catch {}
    });
  }
}

// In-memory local stores for interactive demo workflows
let localChannels: Channel[] = [...DEMO_CHANNELS];
let localIdeas = [...DEMO_CONTENT_IDEAS];
let localScripts = [...DEMO_SCRIPTS];
let localThumbnails = [...DEMO_THUMBNAILS];
let localReviewBundle = { ...DEMO_REVIEW_BUNDLE };
let localSchedulerTasks = [...DEMO_SCHEDULER_TASKS];
let localExperiments = [...DEMO_EXPERIMENTS];

/**
 * Handle endpoint requests with automatic failover to local demo mode.
 * Prevents blank screens, uncaught errors, and infinite spinners.
 */
async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const url = `${BASE_URL}${endpoint}`;
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 4000);

  try {
    const response = await fetch(url, {
      ...options,
      headers,
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    const contentType = response.headers.get('content-type') || '';
    // If Vercel rewrites the API request to index.html or response is not JSON
    if (contentType.includes('text/html') || !contentType.includes('application/json')) {
      throw new Error('Non-JSON response received (SPA fallback detected)');
    }

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    if (data && data.success === false) {
      throw new Error(data.error || data.message || 'Request returned failure');
    }

    updateConnection(true);
    return data as T;
  } catch (_err) {
    clearTimeout(timeoutId);
    updateConnection(false);
    return handleDemoFallback<T>(endpoint, options);
  }
}

/**
 * Deterministic client-side demo fallback dispatcher
 */
function handleDemoFallback<T>(endpoint: string, options: RequestInit = {}): T {
  const cleanUrl = endpoint.split('?')[0];
  const method = (options.method || 'GET').toUpperCase();

  // 1. Settings & Channels
  if (cleanUrl === '/api/settings/channels') {
    if (method === 'POST' && options.body) {
      const payload = JSON.parse(options.body as string);
      const newChan: Channel = {
        id: `demo-channel-${Date.now()}`,
        name: `${payload.name || 'New Channel'} [Demo / Local]`,
        niche: payload.niche || 'Tech',
        targetAudience: payload.targetAudience || 'General',
        brandVoice: payload.brandVoice || 'Analytical [Demo / Local]',
        visualStyle: payload.visualStyle || 'Dark modern',
        defaultLanguage: 'en',
        timezone: 'UTC',
      };
      localChannels.push(newChan);
      return { success: true, data: newChan } as T;
    }
    return { success: true, data: localChannels } as T;
  }

  if (cleanUrl.startsWith('/api/settings/')) {
    const channelId = cleanUrl.replace('/api/settings/', '');
    const found = localChannels.find((c) => c.id === channelId) || localChannels[0];
    return { success: true, data: found } as T;
  }

  // 2. Overview
  if (cleanUrl === '/api/overview') {
    return { success: true, data: DEMO_OVERVIEW_DATA } as T;
  }

  // 3. Autonomous Operator
  if (cleanUrl === '/api/operator/status') {
    return {
      success: true,
      data: {
        hasActivePipeline: true,
        project: {
          id: 'proj-demo-101',
          title: '[Demo / Local] Inside Autonomous Multi-Agent Media Pipelines',
          status: 'AWAITING_APPROVAL',
          currentStage: 'Human Approval Gate',
          format: 'explainer',
          updatedAt: new Date().toISOString(),
        },
        isAwaitingApproval: true,
        recentCycles: [
          {
            stage: 'Human Approval Gate',
            status: 'WAITING',
            details: 'Awaiting human editorial sign-off in Review Studio [Demo / Local]',
            timestamp: new Date().toISOString(),
          },
          {
            stage: 'Quality Control (QC)',
            status: 'PASSED',
            details: 'Loudness and frame integrity passed [Demo / Local]',
            timestamp: new Date(Date.now() - 3600000).toISOString(),
          },
        ],
      },
    } as T;
  }

  if (cleanUrl === '/api/operator/run') {
    return { success: true, result: { message: 'Operator started in Demo / Local mode', projectId: 'proj-demo-101' } } as T;
  }
  if (cleanUrl === '/api/operator/pause' || cleanUrl === '/api/operator/cancel') {
    return { success: true, message: 'Operator state updated in Demo / Local mode' } as T;
  }
  if (cleanUrl === '/api/operator/resume') {
    return { success: true, result: { message: 'Operator resumed' }, message: 'Resumed in Demo mode' } as T;
  }
  if (cleanUrl.startsWith('/api/operator/logs/')) {
    return { success: true, data: DEMO_LOGS.system } as T;
  }

  // 4. Research
  if (cleanUrl === '/api/research') {
    return { success: true, data: DEMO_RESEARCH_RUNS } as T;
  }
  if (cleanUrl === '/api/research/run') {
    return {
      success: true,
      data: {
        id: `res-demo-${Date.now()}`,
        status: 'completed',
        ideas: DEMO_RESEARCH_RUNS[0].ideas,
      },
    } as T;
  }

  // 5. Content Ideas
  if (cleanUrl === '/api/ideas') {
    if (method === 'POST' && options.body) {
      const payload = JSON.parse(options.body as string);
      const newIdea = {
        id: `idea-demo-${Date.now()}`,
        channelId: DEMO_CHANNEL_ID,
        topic: `[Demo / Local] ${payload.topic || 'New Concept'}`,
        angle: payload.angle || 'Architectural breakdown',
        trendScore: 88,
        searchIntent: 'informational',
        competitionScore: 40,
        noveltyScore: 85,
        evergreenScore: 88,
        riskScore: 10,
        recommendedFormat: 'explainer',
        status: 'ACCEPTED',
        createdAt: new Date().toISOString(),
      };
      localIdeas.unshift(newIdea);
      return { success: true, data: newIdea } as T;
    }
    return { success: true, data: localIdeas } as T;
  }
  if (cleanUrl.includes('/status') && cleanUrl.startsWith('/api/ideas/')) {
    const parts = cleanUrl.split('/');
    const ideaId = parts[3];
    const payload = options.body ? JSON.parse(options.body as string) : { status: 'ACCEPTED' };
    const idea = localIdeas.find((i) => i.id === ideaId);
    if (idea) idea.status = payload.status;
    return { success: true, data: idea || { id: ideaId, status: payload.status } } as T;
  }

  // 6. Strategy
  if (cleanUrl === '/api/strategy') {
    return { success: true, data: DEMO_STRATEGIES } as T;
  }
  if (cleanUrl === '/api/strategy/generate') {
    return { success: true, data: DEMO_STRATEGIES[0] } as T;
  }

  // 7. Scripts
  if (cleanUrl === '/api/scripts') {
    return { success: true, data: localScripts } as T;
  }
  if (cleanUrl.startsWith('/api/scripts/')) {
    const id = cleanUrl.replace('/api/scripts/', '');
    const found = localScripts.find((s) => s.id === id) || localScripts[0];
    if (method === 'PUT' && options.body) {
      return { success: true, data: found, version: found.version + 1 } as T;
    }
    return { success: true, data: found } as T;
  }
  if (cleanUrl === '/api/scripts/generate') {
    return { success: true, data: DEMO_SCRIPTS[0] } as T;
  }

  // 8. Thumbnails
  if (cleanUrl === '/api/thumbnails') {
    return { success: true, data: localThumbnails } as T;
  }
  if (cleanUrl === '/api/thumbnails/generate') {
    return { success: true, data: DEMO_THUMBNAILS[0] } as T;
  }
  if (cleanUrl.includes('/select-variant')) {
    return { success: true, data: localThumbnails[0] } as T;
  }

  // 9. Production
  if (cleanUrl === '/api/production/projects') {
    return { success: true, data: DEMO_PRODUCTION_PROJECTS } as T;
  }
  if (cleanUrl.startsWith('/api/production/projects/')) {
    if (cleanUrl.endsWith('/render') || cleanUrl.endsWith('/regenerate-scene')) {
      return { success: true, message: 'Render queued in Demo / Local mode', jobId: `job-demo-${Date.now()}` } as T;
    }
    return { success: true, data: DEMO_PRODUCTION_PROJECTS[0] } as T;
  }

  // 10. Review Studio & Approvals
  if (cleanUrl === '/api/review/pending') {
    return {
      success: true,
      count: 1,
      data: [
        {
          id: 'appr-demo-1',
          projectId: 'proj-demo-101',
          status: 'WAITING_APPROVAL',
          projectTitle: '[Demo / Local] Inside Autonomous Multi-Agent Media Pipelines',
          createdAt: new Date().toISOString(),
        },
      ],
    } as T;
  }
  if (cleanUrl.startsWith('/api/review/review/') || cleanUrl.startsWith('/api/review/')) {
    if (cleanUrl.endsWith('/approve')) {
      localReviewBundle.approval = {
        id: 'appr-demo-1',
        status: 'APPROVED',
        version: 1,
        approvedBy: 'reviewer@contentpilot.ai',
        approvedAt: new Date().toISOString(),
        reviewerNotes: 'Approved in Demo mode',
      };
      return { success: true, message: 'Project approved successfully [Demo / Local]' } as T;
    }
    if (cleanUrl.endsWith('/reject')) {
      localReviewBundle.approval = {
        id: 'appr-demo-1',
        status: 'REJECTED',
        version: 1,
        approvedBy: null,
        approvedAt: null,
        reviewerNotes: 'Rejected in Demo mode',
      };
      return { success: true, message: 'Project rejected [Demo / Local]' } as T;
    }
    if (cleanUrl.endsWith('/edit') || cleanUrl.endsWith('/schedule') || cleanUrl.endsWith('/send-back')) {
      return { success: true, message: 'Action processed in Demo mode' } as T;
    }
    if (cleanUrl.endsWith('/regenerate')) {
      return { success: true, message: 'Stage regenerated', jobId: `job-demo-${Date.now()}` } as T;
    }
    return { success: true, data: localReviewBundle } as T;
  }

  // 11. Publishing Queue
  if (cleanUrl === '/api/publishing-queue') {
    return { success: true, data: DEMO_PUBLISHING_QUEUE } as T;
  }
  if (cleanUrl.startsWith('/api/publishing-queue/')) {
    return { success: true, message: 'Queue item updated in Demo mode' } as T;
  }

  // 12. YouTube Channel (Zero fake publishing)
  if (cleanUrl.startsWith('/api/youtube/status/')) {
    return {
      success: true,
      data: {
        channel: localChannels[0],
        isConnected: false,
        isConfigured: false,
        configurationMessage: 'YouTube connection is not configured yet. (Demo / Local Mode)',
        credentialStatus: 'not_configured',
        tokenExpiresAt: null,
        publishedCount: 0,
        queuedCount: 1,
      },
    } as T;
  }
  if (cleanUrl.startsWith('/api/youtube/videos/')) {
    return { success: true, count: 0, data: [] } as T;
  }
  if (cleanUrl === '/api/youtube/auth-url') {
    return {
      success: false,
      url: '',
      message: 'YouTube connection is not configured yet. Configure YOUTUBE_CLIENT_ID and YOUTUBE_CLIENT_SECRET in environment to connect.',
    } as T;
  }
  if (cleanUrl.startsWith('/api/youtube/disconnect/')) {
    return { success: true, message: 'Disconnected' } as T;
  }
  if (cleanUrl.startsWith('/api/youtube/upload/')) {
    // Explicitly reject fake uploads in demo mode
    throw new Error('YouTube connection is not configured yet. Real YouTube publishing requires backend with YouTube OAuth credentials.');
  }

  // 13. Analytics
  if (cleanUrl.startsWith('/api/analytics/overview/')) {
    return {
      success: true,
      data: [
        {
          metric: 'Channel Views',
          value: 12450,
          changePercent: +18.4,
          note: '[Demo / Local] Channel Telemetry',
        },
        {
          metric: 'Watch Time (Hours)',
          value: 63.6,
          changePercent: +12.1,
          note: '[Demo / Local] Channel Telemetry',
        },
        {
          metric: 'Subscribers',
          value: 1420,
          changePercent: +5.2,
          note: '[Demo / Local] Channel Telemetry',
        },
      ],
    } as T;
  }
  if (cleanUrl.startsWith('/api/analytics/snapshots/')) {
    return { success: true, data: [] } as T;
  }
  if (cleanUrl.startsWith('/api/analytics/sync/')) {
    return { success: true, snapshotsCaptured: 0 } as T;
  }

  // 14. Experiments
  if (cleanUrl.startsWith('/api/experiments/channel/')) {
    return { success: true, data: localExperiments } as T;
  }
  if (cleanUrl === '/api/experiments') {
    return { success: true, experiment: DEMO_EXPERIMENTS[0] } as T;
  }
  if (cleanUrl.startsWith('/api/experiments/')) {
    return { success: true, message: 'Experiment action recorded in Demo mode' } as T;
  }

  // 15. Learning
  if (cleanUrl.startsWith('/api/learning/insights/')) {
    return { success: true, data: DEMO_LEARNING_INSIGHTS } as T;
  }
  if (cleanUrl.startsWith('/api/learning/analyze/')) {
    return { success: true, data: DEMO_LEARNING_INSIGHTS } as T;
  }

  // 16. Scheduler
  if (cleanUrl === '/api/scheduler/tasks') {
    if (method === 'POST') {
      return { success: true, taskId: `task-demo-${Date.now()}` } as T;
    }
    return { success: true, data: localSchedulerTasks } as T;
  }
  if (cleanUrl.startsWith('/api/scheduler/tasks/')) {
    return { success: true, message: 'Task deleted in Demo mode' } as T;
  }
  if (cleanUrl === '/api/scheduler/tick') {
    return { success: true, processedTasksCount: 0 } as T;
  }
  if (cleanUrl.startsWith('/api/scheduler/config/')) {
    return { success: true, data: localChannels[0].settings } as T;
  }

  // 17. Providers
  if (cleanUrl === '/api/providers') {
    return { success: true, count: DEMO_PROVIDERS.length, data: DEMO_PROVIDERS } as T;
  }
  if (cleanUrl.startsWith('/api/providers/')) {
    return { success: true, data: DEMO_PROVIDERS[0] } as T;
  }

  // 18. Logs
  if (cleanUrl === '/api/logs/system') {
    return { success: true, data: DEMO_LOGS.system } as T;
  }
  if (cleanUrl === '/api/logs/audit') {
    return { success: true, data: DEMO_LOGS.audit } as T;
  }
  if (cleanUrl === '/api/logs/autofix') {
    return { success: true, data: DEMO_LOGS.autofix } as T;
  }

  // 19. System Health
  if (cleanUrl === '/api/health' || cleanUrl === '/health') {
    return DEMO_HEALTH_REPORT as unknown as T;
  }

  // Generic fallback
  return { success: true, data: [] } as T;
}

export const api = {
  // Connection state observability
  getConnectionState(): ConnectionState {
    return connectionState;
  },
  onConnectionChange(listener: (state: ConnectionState) => void): () => void {
    connectionListeners.push(listener);
    listener(connectionState);
    return () => {
      const idx = connectionListeners.indexOf(listener);
      if (idx !== -1) connectionListeners.splice(idx, 1);
    };
  },

  // 1. Overview
  async getOverview(channelId?: string): Promise<OverviewData> {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: OverviewData }>(`/api/overview${query}`);
    return res.data;
  },

  // 2. Autonomous Operator
  async getOperatorStatus(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: any }>(`/api/operator/status${query}`);
    return res.data;
  },
  async runOperator(payload: any) {
    return request<{ success: boolean; result: any }>('/api/operator/run', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  async pauseOperator(projectId: string) {
    return request<{ success: boolean; message: string }>('/api/operator/pause', {
      method: 'POST',
      body: JSON.stringify({ projectId }),
    });
  },
  async resumeOperator(projectId: string, channelId: string) {
    return request<{ success: boolean; result: any; message: string }>('/api/operator/resume', {
      method: 'POST',
      body: JSON.stringify({ projectId, channelId }),
    });
  },
  async cancelOperator(projectId: string) {
    return request<{ success: boolean; message: string }>('/api/operator/cancel', {
      method: 'POST',
      body: JSON.stringify({ projectId }),
    });
  },
  async getOperatorLogs(projectId: string) {
    const res = await request<{ success: boolean; data: any }>(`/api/operator/logs/${projectId}`);
    return res.data;
  },

  // 3. Research
  async getResearchRuns(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: any[] }>(`/api/research${query}`);
    return res.data;
  },
  async runResearch(payload: any) {
    const res = await request<{ success: boolean; data: any }>('/api/research/run', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    return res.data;
  },

  // 4. Content Ideas
  async getContentIdeas(channelId?: string, status?: string) {
    const params = new URLSearchParams();
    if (channelId) params.append('channelId', channelId);
    if (status) params.append('status', status);
    const res = await request<{ success: boolean; data: any[] }>(`/api/ideas?${params.toString()}`);
    return res.data;
  },
  async createIdea(payload: any) {
    const res = await request<{ success: boolean; data: any }>('/api/ideas', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    return res.data;
  },
  async updateIdeaStatus(id: string, status: string) {
    const res = await request<{ success: boolean; data: any }>(`/api/ideas/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
    return res.data;
  },

  // 5. Strategy
  async getStrategies(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: any[] }>(`/api/strategy${query}`);
    return res.data;
  },
  async generateStrategy(payload: any) {
    const res = await request<{ success: boolean; data: any }>('/api/strategy/generate', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    return res.data;
  },

  // 6. Scripts
  async getScripts(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: any[] }>(`/api/scripts${query}`);
    return res.data;
  },
  async getScript(id: string) {
    const res = await request<{ success: boolean; data: any }>(`/api/scripts/${id}`);
    return res.data;
  },
  async generateScript(payload: any) {
    const res = await request<{ success: boolean; data: any }>('/api/scripts/generate', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    return res.data;
  },
  async updateScript(id: string, payload: any) {
    const res = await request<{ success: boolean; data: any; version: number }>(`/api/scripts/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
    return res;
  },

  // 7. Thumbnails
  async getThumbnails(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: any[] }>(`/api/thumbnails${query}`);
    return res.data;
  },
  async generateThumbnail(payload: any) {
    const res = await request<{ success: boolean; data: any }>('/api/thumbnails/generate', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    return res.data;
  },
  async selectThumbnailVariant(thumbnailId: string, variantId: string) {
    const res = await request<{ success: boolean; data: any }>(`/api/thumbnails/${thumbnailId}/select-variant`, {
      method: 'POST',
      body: JSON.stringify({ variantId }),
    });
    return res.data;
  },

  // 8. Production
  async getProductionProjects(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: any[] }>(`/api/production/projects${query}`);
    return res.data;
  },
  async getProductionProject(id: string) {
    const res = await request<{ success: boolean; data: any }>(`/api/production/projects/${id}`);
    return res.data;
  },
  async renderProject(id: string) {
    return request<{ success: boolean; message: string; jobId: string }>(`/api/production/projects/${id}/render`, {
      method: 'POST',
    });
  },
  async regenerateScene(projectId: string, sceneIndex: number, visualDescription?: string) {
    return request<{ success: boolean; message: string; jobId: string }>(
      `/api/production/projects/${projectId}/regenerate-scene`,
      {
        method: 'POST',
        body: JSON.stringify({ sceneIndex, visualDescription }),
      }
    );
  },

  // 9. Review Studio
  async getReviewBundle(projectId: string): Promise<ReviewBundle> {
    const res = await request<{ success: boolean; data: ReviewBundle }>(`/api/review/review/${projectId}`);
    return res.data;
  },
  async getPendingApprovals(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; count: number; data: any[] }>(`/api/review/pending${query}`);
    return res.data;
  },
  async approveProject(projectId: string, approvedBy: string, notes?: string) {
    return request<{ success: boolean; message: string }>(`/api/review/${projectId}/approve`, {
      method: 'POST',
      body: JSON.stringify({ approvedBy, notes }),
    });
  },
  async rejectProject(projectId: string, reviewer: string, reason: string) {
    return request<{ success: boolean; message: string }>(`/api/review/${projectId}/reject`, {
      method: 'POST',
      body: JSON.stringify({ reviewer, reason }),
    });
  },
  async editProject(projectId: string, edits: any, editor: string) {
    return request<{ success: boolean; message: string }>(`/api/review/${projectId}/edit`, {
      method: 'POST',
      body: JSON.stringify({ edits, editor }),
    });
  },
  async regenerateProjectStage(projectId: string, stage: string, requestedBy: string) {
    return request<{ success: boolean; message: string; jobId: string }>(`/api/review/${projectId}/regenerate`, {
      method: 'POST',
      body: JSON.stringify({ stage, requestedBy }),
    });
  },
  async sendBackProject(projectId: string, targetStage: string, notes: string, reviewer: string) {
    return request<{ success: boolean; message: string }>(`/api/review/${projectId}/send-back`, {
      method: 'POST',
      body: JSON.stringify({ targetStage, notes, reviewer }),
    });
  },
  async scheduleProject(projectId: string, scheduledPublishTime: string, privacyStatus: string, scheduledBy: string) {
    return request<{ success: boolean; message: string }>(`/api/review/${projectId}/schedule`, {
      method: 'POST',
      body: JSON.stringify({ scheduledPublishTime, privacyStatus, scheduledBy }),
    });
  },

  // 10. Publishing Queue
  async getPublishingQueue(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: any[] }>(`/api/publishing-queue${query}`);
    return res.data;
  },
  async cancelPublishing(id: string) {
    return request<{ success: boolean; message: string }>(`/api/publishing-queue/${id}/cancel`, {
      method: 'POST',
    });
  },
  async retryPublishing(id: string) {
    return request<{ success: boolean; message: string }>(`/api/publishing-queue/${id}/retry`, {
      method: 'POST',
    });
  },

  // 11. YouTube Channel
  async getYouTubeStatus(channelId: string) {
    const res = await request<{ success: boolean; data: any }>(`/api/youtube/status/${channelId}`);
    return res.data;
  },
  async getYouTubeVideos(channelId: string) {
    const res = await request<{ success: boolean; data: any[] }>(`/api/youtube/videos/${channelId}`);
    return res.data;
  },
  async getYouTubeAuthUrl(state?: string) {
    const query = state ? `?state=${encodeURIComponent(state)}` : '';
    const res = await request<{ success: boolean; url: string; message?: string }>(`/api/youtube/auth-url${query}`);
    return res.url || '';
  },
  async disconnectYouTube(channelId: string) {
    return request<{ success: boolean; message: string }>(`/api/youtube/disconnect/${channelId}`, {
      method: 'POST',
    });
  },
  async uploadVideo(projectId: string, channelId: string, privacyStatus = 'private', scheduledPublishTime?: string) {
    return request<{ success: boolean; result: any }>(`/api/youtube/upload/${projectId}`, {
      method: 'POST',
      body: JSON.stringify({ channelId, privacyStatus, scheduledPublishTime }),
    });
  },

  // 12. Analytics
  async getAnalyticsOverview(channelId: string) {
    const res = await request<{ success: boolean; data: any[] }>(`/api/analytics/overview/${channelId}`);
    return res.data;
  },
  async getAnalyticsSnapshots(videoId: string) {
    const res = await request<{ success: boolean; data: any[] }>(`/api/analytics/snapshots/${videoId}`);
    return res.data;
  },
  async syncAnalytics(channelId: string) {
    return request<{ success: boolean; snapshotsCaptured: number }>(`/api/analytics/sync/${channelId}`, {
      method: 'POST',
    });
  },

  // 13. Experiments
  async getExperiments(channelId: string) {
    const res = await request<{ success: boolean; data: any[] }>(`/api/experiments/channel/${channelId}`);
    return res.data;
  },
  async createExperiment(payload: any) {
    return request<{ success: boolean; experiment: any }>('/api/experiments', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  async concludeExperiment(id: string, payload: any) {
    return request<{ success: boolean; experiment: any }>(`/api/experiments/${id}/conclude`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  async approveExperiment(id: string, approvedBy: string) {
    return request<{ success: boolean; message: string }>(`/api/experiments/${id}/approve`, {
      method: 'POST',
      body: JSON.stringify({ approvedBy }),
    });
  },
  async applyExperiment(id: string) {
    return request<{ success: boolean; message: string }>(`/api/experiments/${id}/apply`, {
      method: 'POST',
    });
  },

  // 14. Learning
  async getLearningInsights(channelId: string) {
    const res = await request<{ success: boolean; data: any[] }>(`/api/learning/insights/${channelId}`);
    return res.data;
  },
  async runLearningAnalysis(channelId: string) {
    return request<{ success: boolean; data: any[] }>(`/api/learning/analyze/${channelId}`, {
      method: 'POST',
    });
  },

  // 15. Scheduler
  async getSchedulerTasks(channelId?: string) {
    const query = channelId ? `?channelId=${encodeURIComponent(channelId)}` : '';
    const res = await request<{ success: boolean; data: any[] }>(`/api/scheduler/tasks${query}`);
    return res.data;
  },
  async createSchedulerTask(payload: any) {
    return request<{ success: boolean; taskId: string }>('/api/scheduler/tasks', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  async deleteSchedulerTask(id: string) {
    return request<{ success: boolean; message: string }>(`/api/scheduler/tasks/${id}`, {
      method: 'DELETE',
    });
  },
  async triggerSchedulerTick() {
    return request<{ success: boolean; processedTasksCount: number }>('/api/scheduler/tick', {
      method: 'POST',
    });
  },
  async getSchedulerConfig(channelId: string): Promise<ChannelSettings> {
    const res = await request<{ success: boolean; data: ChannelSettings }>(`/api/scheduler/config/${channelId}`);
    return res.data;
  },
  async updateSchedulerConfig(channelId: string, payload: Partial<ChannelSettings>) {
    const res = await request<{ success: boolean; data: ChannelSettings }>(`/api/scheduler/config/${channelId}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
    return res.data;
  },

  // 16. Providers
  async getProviders() {
    const res = await request<{ success: boolean; data: any[] }>('/api/providers');
    return res.data;
  },
  async updateProvider(id: string, payload: any) {
    const res = await request<{ success: boolean; data: any }>(`/api/providers/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
    return res.data;
  },

  // 17. Settings & Channels
  async getChannels(): Promise<Channel[]> {
    const res = await request<{ success: boolean; data: Channel[] }>('/api/settings/channels');
    return res.data;
  },
  async createChannel(payload: Partial<Channel>): Promise<Channel> {
    const res = await request<{ success: boolean; data: Channel }>('/api/settings/channels', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    return res.data;
  },
  async getChannelSettings(channelId: string): Promise<Channel> {
    const res = await request<{ success: boolean; data: Channel }>(`/api/settings/${channelId}`);
    return res.data;
  },
  async updateChannelSettings(channelId: string, payload: any): Promise<Channel> {
    const res = await request<{ success: boolean; data: Channel }>(`/api/settings/${channelId}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
    return res.data;
  },

  // 18. Logs
  async getSystemLogs(level?: string, limit = 50) {
    const params = new URLSearchParams({ limit: String(limit) });
    if (level) params.append('level', level);
    const res = await request<{ success: boolean; data: any[] }>(`/api/logs/system?${params.toString()}`);
    return res.data;
  },
  async getAuditLogs(channelId?: string, limit = 50) {
    const params = new URLSearchParams({ limit: String(limit) });
    if (channelId) params.append('channelId', channelId);
    const res = await request<{ success: boolean; data: any[] }>(`/api/logs/audit?${params.toString()}`);
    return res.data;
  },
  async getAutoFixLogs(classification?: string, limit = 50) {
    const params = new URLSearchParams({ limit: String(limit) });
    if (classification) params.append('classification', classification);
    const res = await request<{ success: boolean; data: any[] }>(`/api/logs/autofix?${params.toString()}`);
    return res.data;
  },

  // 19. System Health
  async getSystemHealth(): Promise<HealthReport> {
    return request<HealthReport>('/api/health');
  },

  // Media file stream helper
  getMediaUrl(absolutePath: string): string {
    if (!absolutePath) return '';
    if (absolutePath.startsWith('http://') || absolutePath.startsWith('https://')) return absolutePath;
    return `${BASE_URL}/api/media/file?path=${encodeURIComponent(absolutePath)}`;
  },
};
