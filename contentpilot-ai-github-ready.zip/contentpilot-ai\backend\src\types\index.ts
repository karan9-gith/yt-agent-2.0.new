import { z } from 'zod';

// ==========================================
// PIPELINE STAGES & STATUS
// ==========================================

export const PipelineStage = {
  RESEARCH: 'research',
  STRATEGY: 'strategy',
  SCRIPT: 'script',
  SEO: 'seo',
  THUMBNAIL: 'thumbnail',
  NARRATION: 'narration',
  VISUAL_ASSETS: 'visual_assets',
  VIDEO_PRODUCTION: 'video_production',
  QUALITY_CONTROL: 'quality_control',
  RIGHTS_PROVENANCE: 'rights_provenance',
  HUMAN_APPROVAL: 'human_approval',
  PUBLISHING: 'publishing',
  ANALYTICS: 'analytics',
  LEARNING: 'learning',
} as const;

export type PipelineStageType = typeof PipelineStage[keyof typeof PipelineStage];

export const ProductionStatus = {
  DRAFT: 'draft',
  RESEARCHING: 'researching',
  STRATEGIZING: 'strategizing',
  SCRIPTING: 'scripting',
  PRODUCING: 'producing',
  QC_VERIFYING: 'qc_verifying',
  AWAITING_APPROVAL: 'awaiting_approval',
  APPROVED: 'approved',
  PUBLISHING: 'publishing',
  PUBLISHED: 'published',
  FAILED: 'failed',
} as const;

export type ProductionStatusType = typeof ProductionStatus[keyof typeof ProductionStatus];

// ==========================================
// ZOD SCHEMAS FOR STRUCTURED AGENT I/O
// ==========================================

export const ResearchOpportunitySchema = z.object({
  topic: z.string().min(5),
  angle: z.string().min(5),
  targetAudience: z.string(),
  searchVolumeScore: z.number().min(0).max(100),
  competitionScore: z.number().min(0).max(100),
  opportunityScore: z.number().min(0).max(100),
  rationale: z.string(),
  sources: z.array(z.string().url()).default([]),
});

export type ResearchOpportunity = z.infer<typeof ResearchOpportunitySchema>;

export const SceneBlueprintSchema = z.object({
  position: z.number().int().positive(),
  label: z.string().min(1),
  scriptText: z.string().min(1),
  visualPrompt: z.string().min(10),
  estimatedDurationSec: z.number().positive(),
  claims: z.array(z.string()).default([]),
});

export type SceneBlueprint = z.infer<typeof SceneBlueprintSchema>;

export const ScriptSchema = z.object({
  title: z.string().min(5),
  hook: z.object({
    text: z.string().min(5),
    visualCue: z.string(),
    durationSec: z.number().max(15),
  }),
  scenes: z.array(SceneBlueprintSchema).min(1),
  callToAction: z.object({
    scriptText: z.string(),
    visualCue: z.string(),
  }),
  totalEstimatedDurationSec: z.number().positive(),
});

export type Script = z.infer<typeof ScriptSchema>;

export const SeoMetadataSchema = z.object({
  titles: z.array(z.string().max(100)).length(3),
  description: z.string().min(50),
  tags: z.array(z.string()).max(50),
  chapters: z.array(z.object({
    timestamp: z.string(),
    title: z.string(),
  })),
  searchIntentScore: z.number().min(0).max(100),
});

export type SeoMetadata = z.infer<typeof SeoMetadataSchema>;

export const QualityControlFindingSchema = z.object({
  rule: z.string(),
  severity: z.enum(['INFO', 'WARNING', 'CRITICAL']),
  passed: z.boolean(),
  message: z.string(),
  measuredValue: z.union([z.number(), z.string()]).optional(),
  expectedValue: z.union([z.number(), z.string()]).optional(),
});

export type QualityControlFinding = z.infer<typeof QualityControlFindingSchema>;

export const QualityControlReportSchema = z.object({
  passed: z.boolean(),
  overallScore: z.number().min(0).max(100),
  loudnessLufs: z.number(),
  durationDriftSec: z.number(),
  findings: z.array(QualityControlFindingSchema),
  timestamp: z.string(),
});

export type QualityControlReport = z.infer<typeof QualityControlReportSchema>;
