import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { EmptyState } from '../components/EmptyState';
import {
  Play,
  Pause,
  RotateCcw,
  XCircle,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Clock,
  Sparkles,
} from 'lucide-react';

interface OperatorPageProps {
  channelId: string;
  onNavigate: (page: any) => void;
}

const PIPELINE_STAGES = [
  'Inspect Channel',
  'Inspect Analytics',
  'Research',
  'Strategy',
  'Select Topic',
  'Script Synthesis',
  'SEO Optimization',
  'Thumbnail Generation',
  'Voice Narration',
  'Visual Assets',
  'Video Assembly & Render',
  'MP4 Integrity Check',
  'Quality Control (QC)',
  'Rights & Provenance',
  'Send to Review Studio',
  'Human Approval Gate',
  'YouTube Upload Engine',
  'Capture Telemetry',
  'Channel Learning',
  'Future Strategy',
];

export const AutonomousOperatorPage: React.FC<OperatorPageProps> = ({ channelId, onNavigate }) => {
  const [statusData, setStatusData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadStatus();
    const interval = setInterval(loadStatus, 4000);
    return () => clearInterval(interval);
  }, [channelId]);

  const loadStatus = async () => {
    try {
      const res = await api.getOperatorStatus(channelId);
      setStatusData(res);
      if (res?.project?.status === 'RUNNING') {
        setRunning(true);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleStart = async () => {
    try {
      setRunning(true);
      setError(null);
      await api.runOperator({ channelId });
      await loadStatus();
    } catch (err: any) {
      setError(err.message || 'Operator failed to run');
      setRunning(false);
    }
  };

  const handlePause = async () => {
    if (!statusData?.project?.id) return;
    try {
      await api.pauseOperator(statusData.project.id);
      await loadStatus();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleResume = async () => {
    if (!statusData?.project?.id) return;
    try {
      setRunning(true);
      await api.resumeOperator(statusData.project.id, channelId);
      await loadStatus();
    } catch (err: any) {
      setError(err.message);
      setRunning(false);
    }
  };

  const handleCancel = async () => {
    if (!statusData?.project?.id) return;
    if (!confirm('Are you sure you want to cancel the active pipeline?')) return;
    try {
      await api.cancelOperator(statusData.project.id);
      await loadStatus();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const currentStageIndex = statusData?.project
    ? Math.max(0, PIPELINE_STAGES.findIndex((s) => s.toLowerCase().includes(statusData.project.currentStage?.toLowerCase() || '')))
    : 0;

  return (
    <div style={{ padding: '2rem' }}>
      {/* Page Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Autonomous Channel Operator</h1>
          <p className="page-description">
            20-Stage self-healing production pipeline with strict human editorial safety gates.
          </p>
        </div>

        {/* Action Controls */}
        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button className="btn btn-primary" onClick={handleStart} disabled={running}>
            <Play size={16} /> Start Cycle
          </button>
          <button
            className="btn btn-secondary"
            onClick={handlePause}
            disabled={!statusData?.hasActivePipeline || statusData?.runtimeControlStatus === 'paused'}
          >
            <Pause size={16} /> Pause
          </button>
          <button
            className="btn btn-secondary"
            onClick={handleResume}
            disabled={!statusData?.hasActivePipeline || statusData?.runtimeControlStatus !== 'paused'}
          >
            <RotateCcw size={16} /> Resume
          </button>
          <button
            className="btn btn-danger"
            onClick={handleCancel}
            disabled={!statusData?.hasActivePipeline || statusData?.project?.status === 'CANCELLED'}
          >
            <XCircle size={16} /> Cancel
          </button>
        </div>
      </div>

      {error && (
        <div className="glass-panel" style={{ padding: '1rem', marginBottom: '1.5rem', borderLeft: '4px solid #ef4444' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#f87171', fontWeight: 600 }}>
            <AlertTriangle size={18} /> Operator Message: {error}
          </div>
        </div>
      )}

      {/* Mandatory Human Approval Gate Notice */}
      {statusData?.isAwaitingApproval && (
        <div
          className="glass-panel"
          style={{
            padding: '1.25rem',
            marginBottom: '1.5rem',
            background: 'rgba(245, 158, 11, 0.08)',
            border: '1px solid rgba(245, 158, 11, 0.3)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div
              style={{
                width: '40px',
                height: '40px',
                borderRadius: '50%',
                background: 'rgba(245, 158, 11, 0.2)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#fbbf24',
              }}
            >
              <ShieldCheck size={22} />
            </div>
            <div>
              <div style={{ fontWeight: 700, color: '#fbbf24' }}>Halted at Mandatory Human Approval Gate (Stage 16)</div>
              <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                Production, QC, and rights checks passed. Human sign-off is strictly required before YouTube publishing.
              </div>
            </div>
          </div>
          <button className="btn btn-primary" onClick={() => onNavigate('review')}>
            Open Review Studio <ArrowRight size={14} />
          </button>
        </div>
      )}

      {/* Current Pipeline Status Card */}
      {statusData?.hasActivePipeline ? (
        <div className="glass-panel" style={{ padding: '1.75rem', marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
            <div>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Active Production Pipeline
              </div>
              <h2 style={{ fontSize: '1.25rem', fontWeight: 800 }}>{statusData.project.title}</h2>
            </div>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <span className="badge badge-info">{statusData.project.format}</span>
              <span className="badge badge-warning">{statusData.project.status}</span>
            </div>
          </div>

          {/* Stepper Progress Bar */}
          <div style={{ marginBottom: '1.5rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: '6px' }}>
              <span style={{ color: 'var(--text-secondary)' }}>
                Stage: <strong>{statusData.project.currentStage}</strong>
              </span>
              <span style={{ color: 'var(--text-muted)' }}>
                Checkpoint {currentStageIndex + 1} of 20
              </span>
            </div>
            <div style={{ width: '100%', height: '8px', background: 'var(--bg-main)', borderRadius: '4px', overflow: 'hidden' }}>
              <div
                style={{
                  width: `${Math.min(100, Math.max(5, ((currentStageIndex + 1) / 20) * 100))}%`,
                  height: '100%',
                  background: 'var(--accent-gradient)',
                  transition: 'width 0.4s ease',
                }}
              />
            </div>
          </div>

          {/* Stages List Grid */}
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
              gap: '0.75rem',
            }}
          >
            {PIPELINE_STAGES.map((stage, idx) => {
              const isPast = idx < currentStageIndex;
              const isCurrent = idx === currentStageIndex;
              const isGate = idx === 15;

              return (
                <div
                  key={stage}
                  style={{
                    background: isCurrent
                      ? 'rgba(59, 130, 246, 0.12)'
                      : isPast
                      ? 'rgba(16, 185, 129, 0.08)'
                      : 'var(--bg-surface-elevated)',
                    border: `1px solid ${
                      isCurrent
                        ? '#3b82f6'
                        : isPast
                        ? 'rgba(16, 185, 129, 0.3)'
                        : 'var(--border-subtle)'
                    }`,
                    borderRadius: '8px',
                    padding: '0.75rem',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                  }}
                >
                  <div
                    style={{
                      width: '22px',
                      height: '22px',
                      borderRadius: '50%',
                      background: isPast
                        ? '#10b981'
                        : isCurrent
                        ? '#3b82f6'
                        : 'rgba(255, 255, 255, 0.05)',
                      color: isPast || isCurrent ? '#fff' : 'var(--text-muted)',
                      fontSize: '0.7rem',
                      fontWeight: 700,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    {isPast ? <CheckCircle2 size={14} /> : idx + 1}
                  </div>
                  <div>
                    <div style={{ fontSize: '0.8rem', fontWeight: 600 }}>{stage}</div>
                    <div style={{ fontSize: '0.68rem', color: isGate ? '#fbbf24' : 'var(--text-muted)' }}>
                      {isGate ? 'MANDATORY GATE' : isPast ? 'Completed' : isCurrent ? 'Running' : 'Queued'}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <EmptyState
          title="No active pipeline running."
          message="Click 'Start Cycle' above to trigger autonomous channel operation, from research through production to Review Studio."
          actionText="Start Autonomous Cycle"
          onAction={handleStart}
        />
      )}

      {/* Operator Logs & Auto-Fix History */}
      {statusData?.stateLogs && statusData.stateLogs.length > 0 && (
        <div className="glass-panel" style={{ padding: '1.5rem' }}>
          <h3 style={{ fontSize: '1.05rem', fontWeight: 700, marginBottom: '1rem' }}>
            Pipeline State Transitions & Safety Logs
          </h3>
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th>Timestamp</th>
                  <th>From State</th>
                  <th>To State</th>
                  <th>Trigger</th>
                </tr>
              </thead>
              <tbody>
                {statusData.stateLogs.map((log: any) => (
                  <tr key={log.id}>
                    <td style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </td>
                    <td>
                      <span className="badge badge-info">{log.fromState}</span>
                    </td>
                    <td>
                      <span className="badge badge-success">{log.toState}</span>
                    </td>
                    <td style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{log.trigger}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
