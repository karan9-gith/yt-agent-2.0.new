import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { EmptyState } from '../components/EmptyState';
import { GraduationCap, Sparkles, TrendingUp, AlertCircle, CheckCircle2 } from 'lucide-react';

interface LearningPageProps {
  channelId: string;
  onNavigate: (page: any) => void;
}

export const LearningPage: React.FC<LearningPageProps> = ({ channelId, onNavigate }) => {
  const [insights, setInsights] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    loadInsights();
  }, [channelId]);

  const loadInsights = async () => {
    try {
      setLoading(true);
      const data = await api.getLearningInsights(channelId);
      setInsights(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleAnalyze = async () => {
    try {
      setAnalyzing(true);
      setMessage(null);
      const res = await api.runLearningAnalysis(channelId);
      setMessage(`Channel learning complete. ${res.data?.length || 0} pattern insights generated.`);
      await loadInsights();
    } catch (err: any) {
      setMessage(`Analysis failed: ${err.message}`);
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Channel Learning & Insight Engine</h1>
          <p className="page-description">
            Empirical pattern mining. Enforces strict sample sizes to prevent false claims of causation.
          </p>
        </div>
        <button className="btn btn-primary" onClick={handleAnalyze} disabled={analyzing}>
          <Sparkles size={16} /> {analyzing ? 'Mining Patterns...' : 'Run Learning Analysis'}
        </button>
      </div>

      {message && (
        <div className="badge badge-info" style={{ marginBottom: '1.25rem', padding: '8px 12px' }}>
          {message}
        </div>
      )}

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Loading insights...</p>
      ) : insights.length === 0 ? (
        <EmptyState
          title="No empirical insights yet."
          message="Learning Agent requires at least 2 published video snapshots to infer patterns without fabricating conclusions."
          actionText="Run Analysis"
          onAction={handleAnalyze}
        />
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          {insights.map((item) => (
            <div key={item.id} className="glass-panel" style={{ padding: '1.5rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                <span className="badge badge-info" style={{ textTransform: 'uppercase' }}>
                  {item.category}
                </span>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span style={{ fontSize: '0.78rem', color: 'var(--text-secondary)' }}>Confidence:</span>
                  <span
                    className={`badge ${
                      item.confidence >= 0.7
                        ? 'badge-success'
                        : item.confidence >= 0.4
                        ? 'badge-warning'
                        : 'badge-danger'
                    }`}
                  >
                    {Math.round(item.confidence * 100)}%
                  </span>
                </div>
              </div>

              {/* Distinction: DATA / INFERENCE / RECOMMENDATION */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem' }}>
                {/* 1. DATA / EVIDENCE */}
                <div style={{ background: 'var(--bg-surface-elevated)', borderRadius: '8px', padding: '1rem', borderLeft: '3px solid #3b82f6' }}>
                  <div style={{ fontSize: '0.72rem', color: '#60a5fa', fontWeight: 800, letterSpacing: '0.05em' }}>
                    1. EMPIRICAL DATA (OBSERVATIONS)
                  </div>
                  <div style={{ fontSize: '0.85rem', marginTop: '6px', lineHeight: 1.5 }}>
                    {item.evidence || 'Baseline metrics collected from lifetime snapshots.'}
                  </div>
                </div>

                {/* 2. INFERENCE / INSIGHT */}
                <div style={{ background: 'var(--bg-surface-elevated)', borderRadius: '8px', padding: '1rem', borderLeft: '3px solid #8b5cf6' }}>
                  <div style={{ fontSize: '0.72rem', color: '#c084fc', fontWeight: 800, letterSpacing: '0.05em' }}>
                    2. INFERENCE (HYPOTHESIZED PATTERN)
                  </div>
                  <div style={{ fontSize: '0.85rem', marginTop: '6px', lineHeight: 1.5, fontWeight: 600 }}>
                    {item.finding}
                  </div>
                </div>

                {/* 3. RECOMMENDATION */}
                <div style={{ background: 'var(--bg-surface-elevated)', borderRadius: '8px', padding: '1rem', borderLeft: '3px solid #10b981' }}>
                  <div style={{ fontSize: '0.72rem', color: '#34d399', fontWeight: 800, letterSpacing: '0.05em' }}>
                    3. ACTIONABLE RECOMMENDATION
                  </div>
                  <div style={{ fontSize: '0.85rem', marginTop: '6px', lineHeight: 1.5 }}>
                    {item.recommendation || 'Maintain monitoring until sample size grows.'}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
