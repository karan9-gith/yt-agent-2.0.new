import fs from 'node:fs/promises';
import { prisma } from '../../database/client.js';
import { logger } from '../../utils/logger.js';
import { AppError } from '../../utils/errors.js';

export interface PreUploadSafetyResult {
  passed: boolean;
  checks: {
    approval: { passed: boolean; details: string; approvedBy?: string; approvedAt?: string };
    qc: { passed: boolean; details: string; score?: number };
    video: { passed: boolean; details: string; path?: string; sizeBytes?: number };
    narration: { passed: boolean; details: string; durationSec?: number };
    metadata: { passed: boolean; details: string; title?: string };
  };
  errors: string[];
}

export class PreUploadSafetyError extends AppError {
  public readonly safetyResult: PreUploadSafetyResult;

  constructor(message: string, safetyResult: PreUploadSafetyResult) {
    super(message, 422, 'PRE_UPLOAD_SAFETY_CHECK_FAILED');
    this.safetyResult = safetyResult;
  }
}

export class PreUploadSafetyChecker {
  /**
   * Verify all 5 safety conditions prior to initiating any YouTube upload.
   * If any condition fails, strictly blocks upload and records audit log.
   */
  public async verify(projectId: string): Promise<PreUploadSafetyResult> {
    const project = await prisma.videoProject.findUnique({
      where: { id: projectId },
      include: {
        approvalRequests: {
          orderBy: { createdAt: 'desc' },
          take: 1,
        },
        qualityChecks: {
          orderBy: { createdAt: 'desc' },
          take: 1,
        },
        renders: {
          where: { status: 'completed' },
          orderBy: { createdAt: 'desc' },
          take: 1,
        },
        narration: true,
        seoPackage: true,
        script: {
          include: {
            rightsChecks: {
              orderBy: { createdAt: 'desc' },
              take: 1,
            },
          },
        },
      },
    });

    if (!project) {
      throw new AppError(`Project '${projectId}' not found`, 404, 'PROJECT_NOT_FOUND');
    }

    const errors: string[] = [];
    const result: PreUploadSafetyResult = {
      passed: true,
      checks: {
        approval: { passed: false, details: 'Pending verification' },
        qc: { passed: false, details: 'Pending verification' },
        video: { passed: false, details: 'Pending verification' },
        narration: { passed: false, details: 'Pending verification' },
        metadata: { passed: false, details: 'Pending verification' },
      },
      errors: [],
    };

    // 1. Approval Check
    const latestApproval = project.approvalRequests[0];
    if (
      latestApproval &&
      latestApproval.status === 'APPROVED' &&
      latestApproval.approvedAt &&
      latestApproval.approvedBy
    ) {
      result.checks.approval = {
        passed: true,
        details: `Approved by '${latestApproval.approvedBy}' at ${latestApproval.approvedAt.toISOString()}`,
        approvedBy: latestApproval.approvedBy,
        approvedAt: latestApproval.approvedAt.toISOString(),
      };
    } else {
      const reason = !latestApproval
        ? 'No approval request exists'
        : `Approval status is '${latestApproval.status}' (requires explicit 'APPROVED')`;
      result.checks.approval = { passed: false, details: reason };
      errors.push(`APPROVAL_CHECK_FAILED: ${reason}`);
    }

    // 2. QC Check
    const latestQc = project.qualityChecks[0];
    if (latestQc && (latestQc.passed || latestQc.status === 'PASS') && latestQc.status !== 'BLOCKED') {
      result.checks.qc = {
        passed: true,
        details: `QC passed with score ${latestQc.overallScore}/100 and loudness ${latestQc.loudnessLufs} LUFS`,
        score: latestQc.overallScore,
      };
    } else {
      const reason = !latestQc
        ? 'No Quality Control check found for project'
        : `QC did not pass (status: ${latestQc.status}, passed: ${latestQc.passed})`;
      result.checks.qc = { passed: false, details: reason };
      errors.push(`QC_CHECK_FAILED: ${reason}`);
    }

    // 3. Video MP4 Check
    const render = project.renders[0];
    if (!render || !render.outputPath) {
      const reason = 'No completed video render found';
      result.checks.video = { passed: false, details: reason };
      errors.push(`VIDEO_CHECK_FAILED: ${reason}`);
    } else {
      try {
        const stats = await fs.stat(render.outputPath);
        if (stats.isFile() && stats.size > 0 && render.outputPath.toLowerCase().endsWith('.mp4')) {
          result.checks.video = {
            passed: true,
            details: `Valid MP4 file exists at '${render.outputPath}' (${stats.size} bytes)`,
            path: render.outputPath,
            sizeBytes: stats.size,
          };
        } else {
          const reason = `Render file is empty or not an MP4: size=${stats.size}`;
          result.checks.video = { passed: false, details: reason };
          errors.push(`VIDEO_CHECK_FAILED: ${reason}`);
        }
      } catch (err) {
        const reason = `Rendered MP4 file not found at path: ${render.outputPath}`;
        result.checks.video = { passed: false, details: reason };
        errors.push(`VIDEO_CHECK_FAILED: ${reason}`);
      }
    }

    // 4. Narration Check
    const narration = project.narration;
    if (!narration || !narration.audioPath || narration.durationSec <= 0) {
      const reason = !narration
        ? 'No narration record associated with project'
        : `Narration audio missing or duration invalid (${narration.durationSec}s)`;
      result.checks.narration = { passed: false, details: reason };
      errors.push(`NARRATION_CHECK_FAILED: ${reason}`);
    } else {
      try {
        const stats = await fs.stat(narration.audioPath);
        if (stats.isFile() && stats.size > 0) {
          result.checks.narration = {
            passed: true,
            details: `Valid narration audio exists (${narration.durationSec.toFixed(1)}s, ${stats.size} bytes)`,
            durationSec: narration.durationSec,
          };
        } else {
          const reason = 'Narration audio file is zero bytes';
          result.checks.narration = { passed: false, details: reason };
          errors.push(`NARRATION_CHECK_FAILED: ${reason}`);
        }
      } catch {
        const reason = `Narration audio file missing on disk: ${narration.audioPath}`;
        result.checks.narration = { passed: false, details: reason };
        errors.push(`NARRATION_CHECK_FAILED: ${reason}`);
      }
    }

    // 5. Metadata Check
    const seo = project.seoPackage;
    if (!seo || !seo.recommendedTitle || seo.recommendedTitle.trim().length === 0) {
      const reason = 'SEO package missing or recommended title is empty';
      result.checks.metadata = { passed: false, details: reason };
      errors.push(`METADATA_CHECK_FAILED: ${reason}`);
    } else if (seo.recommendedTitle.length > 100) {
      const reason = `Recommended title exceeds YouTube 100 char limit (${seo.recommendedTitle.length} chars)`;
      result.checks.metadata = { passed: false, details: reason };
      errors.push(`METADATA_CHECK_FAILED: ${reason}`);
    } else if (!seo.description || seo.description.trim().length < 10) {
      const reason = 'Description missing or too short (< 10 chars)';
      result.checks.metadata = { passed: false, details: reason };
      errors.push(`METADATA_CHECK_FAILED: ${reason}`);
    } else {
      result.checks.metadata = {
        passed: true,
        details: `Metadata valid: Title (${seo.recommendedTitle.length} chars), Description (${seo.description.length} chars)`,
        title: seo.recommendedTitle,
      };
    }

    // 6. Rights & Content Safety Check (if rights evaluation is recorded)
    const latestRights = project.script?.rightsChecks[0];
    if (latestRights && (latestRights.status === 'BLOCKED' || latestRights.unsupportedClaimsCount > 0)) {
      const reason = `Rights check not passed: status=${latestRights.status}, unsupportedClaims=${latestRights.unsupportedClaimsCount}`;
      errors.push(`RIGHTS_CHECK_FAILED: ${reason}`);
    }

    result.errors = errors;
    result.passed = errors.length === 0;

    // Log decision and audit trail
    if (!result.passed) {
      await prisma.auditLog.create({
        data: {
          channelId: project.channelId,
          entityType: 'publishing',
          entityId: projectId,
          action: 'PUBLISH_BLOCKED',
          beforeJson: JSON.stringify({ status: project.status }),
          afterJson: JSON.stringify({ blockedReasons: errors }),
          timestamp: new Date(),
        },
      });

      await prisma.systemLog.create({
        data: {
          level: 'warn',
          category: 'pipeline',
          message: `PRE-UPLOAD SAFETY CHECK FAILED for project ${projectId}: ${errors.join('; ')}`,
          metaJson: JSON.stringify(result),
          timestamp: new Date(),
        },
      });

      logger.warn({
        msg: 'Pre-upload safety check BLOCKED upload',
        projectId,
        errors,
      });

      throw new PreUploadSafetyError(
        `Pre-upload safety check failed: upload BLOCKED. Reasons: ${errors.join('; ')}`,
        result
      );
    }

    logger.info({
      msg: 'Pre-upload safety check PASSED',
      projectId,
    });

    return result;
  }
}

export const preUploadSafetyChecker = new PreUploadSafetyChecker();
