import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '../database/client.js';
import { defaultAiProvider } from '../services/ai/defaultAIProvider.js';
import { AppError } from '../utils/errors.js';

const router = Router();
const param = (p: string | string[]): string => (Array.isArray(p) ? p[0] : p);

// GET all thumbnails
router.get('/', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const channelId = req.query.channelId as string | undefined;
    const thumbnails = await prisma.thumbnail.findMany({
      where: channelId ? { channelId } : undefined,
      include: {
        variants: true,
        script: { select: { title: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    res.json({ success: true, count: thumbnails.length, data: thumbnails });
  } catch (err) {
    next(err);
  }
});

// GET single thumbnail with variants
router.get('/:id', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const thumb = await prisma.thumbnail.findUnique({
      where: { id: param(req.params.id) },
      include: { variants: true, script: true },
    });
    if (!thumb) {
      throw new AppError('Thumbnail not found', 404, 'NOT_FOUND');
    }
    res.json({ success: true, data: thumb });
  } catch (err) {
    next(err);
  }
});

// POST generate thumbnail concepts for a script
router.post('/generate', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { scriptId, channelId } = req.body;
    if (!scriptId || !channelId) {
      res.status(400).json({ success: false, error: 'Fields "scriptId" and "channelId" are required' });
      return;
    }

    const [script, channel] = await Promise.all([
      prisma.script.findUnique({ where: { id: scriptId } }),
      prisma.channel.findUnique({ where: { id: channelId } }),
    ]);

    if (!script || !channel) {
      throw new AppError('Script or Channel not found', 404, 'NOT_FOUND');
    }

    const aiResult = await defaultAiProvider.generateThumbnailConcept({
      title: script.title,
      hook: script.hookText,
      visualStyle: channel.visualStyle,
    });

    let thumbnail = await prisma.thumbnail.findUnique({
      where: { scriptId },
    });

    if (!thumbnail) {
      thumbnail = await prisma.thumbnail.create({
        data: {
          scriptId,
          channelId,
          status: 'generated',
        },
      });
    }

    // Create variants
    for (let i = 0; i < aiResult.concepts.length; i++) {
      const c = aiResult.concepts[i];
      const variant = await prisma.thumbnailVariant.create({
        data: {
          thumbnailId: thumbnail.id,
          prompt: c.imagePrompt,
          composition: c.composition,
          subject: c.subject,
          emotion: c.emotion,
          textOverlay: c.textOverlay,
          layout: c.layout,
          visualHierarchy: c.visualHierarchy,
          contrastGuidance: c.contrastGuidance,
          isSelected: i === 0,
          status: 'ready',
        },
      });

      if (i === 0) {
        await prisma.thumbnail.update({
          where: { id: thumbnail.id },
          data: { selectedVariantId: variant.id },
        });
      }
    }

    const updated = await prisma.thumbnail.findUnique({
      where: { id: thumbnail.id },
      include: { variants: true },
    });

    res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
});

// POST select active thumbnail variant
router.post('/:id/select-variant', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const thumbnailId = param(req.params.id);
    const { variantId } = req.body;

    if (!variantId) {
      res.status(400).json({ success: false, error: 'Field "variantId" is required' });
      return;
    }

    // Deselect all
    await prisma.thumbnailVariant.updateMany({
      where: { thumbnailId },
      data: { isSelected: false },
    });

    // Select chosen variant
    await prisma.thumbnailVariant.update({
      where: { id: variantId },
      data: { isSelected: true },
    });

    const updated = await prisma.thumbnail.update({
      where: { id: thumbnailId },
      data: { selectedVariantId: variantId },
      include: { variants: true },
    });

    res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
});

export default router;
