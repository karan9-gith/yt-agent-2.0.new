import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { Terminal, Shield, RefreshCw, Cpu, AlertTriangle } from 'lucide-react';

interface LogsPageProps {
  channelId: string;
}

export const LogsPage: React.FC<LogsPageProps> = ({ channelId }) => {
  const [tab, setTab] = useState<'system' | 'audit' | 'autofix'>('system');
  const [systemLogs, setSystemLogs] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [autoFixLogs, setAutoFixLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLogs();
  }, [tab, channelId]);

  const loadLogs = async () => {
    try {
      setLoading(true);
      if (tab === 'system') {
        const data = await api.getSystemLogs(undefined, 100);
        setSystemLogs(data);
      } else if (tab === 'audit') {
        const data = await api.getAuditLogs(channelId, 100);
        setAuditLogs(data);
      } else {
        const data = await api.getAutoFixLogs(undefined, 100);
        setAutoFixLogs(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">System & Security Audit Trails</h1>
          <p className="page-description">
            Immutable operation logs, editorial approval records, and auto-fix error recovery events.
          </p>
        </div>
        <button className="btn btn-secondary" onClick={loadLogs}>
          <RefreshCw size={14} /> Refresh Logs
        </button>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1.5rem', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '0.75rem' }}>
        <button
          className="btn"
          style={{
            background: tab === 'system' ? 'rgba(59, 130, 246, 0.15)' : 'transparent',
            color: tab === 'system' ? '#60a5fa' : 'var(--text-secondary)',
            border: tab === 'system' ? '1px solid rgba(59, 130, 246, 0.3)' : '1px solid transparent',
          }}
          onClick={() => setTab('system')}
        >
          <Terminal size={14} /> System Logs
        </button>

        <button
          className="btn"
          style={{
            background: tab === 'audit' ? 'rgba(59, 130, 246, 0.15)' : 'transparent',
            color: tab === 'audit' ? '#60a5fa' : 'var(--text-secondary)',
            border: tab === 'audit' ? '1px solid rgba(59, 130, 246, 0.3)' : '1px solid transparent',
          }}
          onClick={() => setTab('audit')}
        >
          <Shield size={14} /> Editorial Audit Trail
        </button>

        <button
          className="btn"
          style={{
            background: tab === 'autofix' ? 'rgba(59, 130, 246, 0.15)' : 'transparent',
            color: tab === 'autofix' ? '#60a5fa' : 'var(--text-secondary)',
            border: tab === 'autofix' ? '1px solid rgba(59, 130, 246, 0.3)' : '1px solid transparent',
          }}
          onClick={() => setTab('autofix')}
        >
          <Cpu size={14} /> Auto-Fix Engine Logs
        </button>
      </div>

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Loading log events...</p>
      ) : tab === 'system' ? (
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Timestamp</th>
                <th>Level</th>
                <th>Category</th>
                <th>Message</th>
              </tr>
            </thead>
            <tbody>
              {systemLogs.length === 0 ? (
                <tr><td colSpan={4} style={{ textAlign: 'center', color: 'var(--text-muted)' }}>No system logs yet.</td></tr>
              ) : (
                systemLogs.map((l) => (
                  <tr key={l.id}>
                    <td style={{ fontSize: '0.78rem', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
                      {new Date(l.timestamp).toLocaleString()}
                    </td>
                    <td>
                      <span className={`badge ${l.level === 'error' ? 'badge-danger' : l.level === 'warn' ? 'badge-warning' : 'badge-info'}`}>
                        {l.level}
                      </span>
                    </td>
                    <td style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{l.category}</td>
                    <td style={{ fontSize: '0.85rem' }}>{l.message}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      ) : tab === 'audit' ? (
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Timestamp</th>
                <th>Action</th>
                <th>Entity Type</th>
                <th>Entity ID</th>
                <th>Reviewer</th>
              </tr>
            </thead>
            <tbody>
              {auditLogs.length === 0 ? (
                <tr><td colSpan={5} style={{ textAlign: 'center', color: 'var(--text-muted)' }}>No audit logs yet.</td></tr>
              ) : (
                auditLogs.map((a) => (
                  <tr key={a.id}>
                    <td style={{ fontSize: '0.78rem', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
                      {new Date(a.timestamp).toLocaleString()}
                    </td>
                    <td>
                      <span className={`badge ${a.action === 'APPROVE' ? 'badge-success' : a.action === 'REJECT' ? 'badge-danger' : 'badge-info'}`}>
                        {a.action}
                      </span>
                    </td>
                    <td style={{ fontSize: '0.825rem' }}>{a.entityType}</td>
                    <td style={{ fontSize: '0.78rem', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>
                      {a.entityId.slice(0, 16)}...
                    </td>
                    <td style={{ fontSize: '0.85rem', fontWeight: 600 }}>{a.user?.email || 'system'}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Timestamp</th>
                <th>Classification</th>
                <th>Diagnosis</th>
                <th>Fix Applied</th>
                <th>Result</th>
              </tr>
            </thead>
            <tbody>
              {autoFixLogs.length === 0 ? (
                <tr><td colSpan={5} style={{ textAlign: 'center', color: 'var(--text-muted)' }}>No auto-fix recovery logs yet.</td></tr>
              ) : (
                autoFixLogs.map((f) => (
                  <tr key={f.id}>
                    <td style={{ fontSize: '0.78rem', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
                      {new Date(f.timestamp).toLocaleString()}
                    </td>
                    <td>
                      <span className="badge badge-warning">{f.classification}</span>
                    </td>
                    <td style={{ fontSize: '0.825rem' }}>{f.diagnosis}</td>
                    <td style={{ fontSize: '0.825rem', color: 'var(--text-secondary)' }}>{f.fixApplied}</td>
                    <td>
                      <span className={`badge ${f.result === 'SUCCESS' ? 'badge-success' : 'badge-danger'}`}>
                        {f.result}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
