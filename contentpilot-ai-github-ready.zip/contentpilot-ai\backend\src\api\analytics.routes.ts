import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '../database/client.js';
import { youtubeAnalyticsService } from '../services/analytics/youtubeAnalyticsService.js';

const router = Router();
const param = (p: string | string[]): string => (Array.isArray(p) ? p[0] : p);

// POST trigger analytics sync for channel
router.post('/sync/:channelId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const synced = await youtubeAnalyticsService.syncChannelVideos(param(req.params.channelId));
    res.json({ success: true, snapshotsCaptured: synced });
  } catch (err) {
    next(err);
  }
});

// GET historical snapshots for video
router.get('/snapshots/:videoId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const snapshots = await youtubeAnalyticsService.getSnapshots(param(req.params.videoId));
    res.json({ success: true, count: snapshots.length, data: snapshots });
  } catch (err) {
    next(err);
  }
});

// GET channel analytics overview
router.get('/overview/:channelId', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const snapshots = await prisma.analyticsSnapshot.findMany({
      where: { channelId: param(req.params.channelId), measurementWindow: 'lifetime' },
      include: { youtubeVideo: { select: { title: true, publishedAt: true } } },
      orderBy: { views: 'desc' },
      take: 20,
    });
    res.json({ success: true, count: snapshots.length, data: snapshots });
  } catch (err) {
    next(err);
  }
});

export default router;
