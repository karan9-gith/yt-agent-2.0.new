import { Router, Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { SecurityGuard } from '../utils/security.js';

const router = Router();

// GET stream media file with strict path traversal validation
router.get('/file', (req: Request, res: Response) => {
  const reqPath = req.query.path as string | undefined;

  if (!reqPath) {
    res.status(400).json({ success: false, error: 'Query parameter "path" is required' });
    return;
  }

  let resolvedPath: string;
  try {
    resolvedPath = SecurityGuard.validatePathWithinStorage(reqPath);
  } catch (secErr) {
    res.status(403).json({ success: false, error: (secErr as Error).message });
    return;
  }

  if (!fs.existsSync(resolvedPath)) {
    res.status(404).json({ success: false, error: 'File not found' });
    return;
  }

  // Determine mime type
  const ext = path.extname(resolvedPath).toLowerCase();
  const mimeTypes: Record<string, string> = {
    '.mp4': 'video/mp4',
    '.webm': 'video/webm',
    '.wav': 'audio/wav',
    '.mp3': 'audio/mpeg',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.webp': 'image/webp',
    '.json': 'application/json',
  };

  const contentType = mimeTypes[ext] || 'application/octet-stream';

  // Support Range requests for smooth video scrubbing
  const stat = fs.statSync(resolvedPath);
  const fileSize = stat.size;
  const range = req.headers.range;

  if (range && (ext === '.mp4' || ext === '.webm' || ext === '.wav' || ext === '.mp3')) {
    const parts = range.replace(/bytes=/, '').split('-');
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
    const chunkSize = end - start + 1;
    const file = fs.createReadStream(resolvedPath, { start, end });

    res.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${fileSize}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunkSize,
      'Content-Type': contentType,
    });
    file.pipe(res);
  } else {
    res.writeHead(200, {
      'Content-Length': fileSize,
      'Content-Type': contentType,
    });
    fs.createReadStream(resolvedPath).pipe(res);
  }
});

export default router;
